`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [128:0] result__query__,
  input push__vld__,
  input [255:0] push_value__,
  input [0:0] push_v__
);

reg [63:0] __vul_pipeline_q_a;
wire [63:0] resetvalue_a__;
wire wen_a__;
wire [63:0] wdata_a__;
reg [63:0] __vul_pipeline_q_b;
wire [63:0] resetvalue_b__;
wire wen_b__;
wire [63:0] wdata_b__;
reg [63:0] __vul_pipeline_q_c;
wire [63:0] resetvalue_c__;
wire wen_c__;
wire [63:0] wdata_c__;
reg [63:0] __vul_pipeline_q_d;
wire [63:0] resetvalue_d__;
wire wen_d__;
wire [63:0] wdata_d__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [128:0] __vul_pipeline_q_y;
wire [128:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_c <= resetvalue_c__;
  end else begin
begin
    if (wen_c__) begin
      __vul_pipeline_q_c <= wdata_c__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_d <= resetvalue_d__;
  end else begin
begin
    if (wen_d__) begin
      __vul_pipeline_q_d <= wdata_d__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 129'h040000000000000350000000000000af9;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [63:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21
    logic [63:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21
    logic [63:0] __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21
    logic [63:0] __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:21
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [128:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [63:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21
    logic [63:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21
    logic [63:0] vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21
    logic [63:0] vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:21
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [127:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:34:27-34:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:43:17-43:50
    logic [127:0] s8_norm_mul_7_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:50
    logic [128:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:38:23-38:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:36:25-36:44
    logic [128:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic [127:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [127:0] arith_original_14; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:34:27-34:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:43:17-43:50
    logic [127:0] arith_original_15; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:50
    logic [15:0] mul_tree_14_16; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_18; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_20; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_21; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_14_22; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_24; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_25; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_26; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_27; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_28; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_29; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_14_30; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_31; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_32; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_33; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_14_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_35; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_36; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_37; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_38; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_39; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_40; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_41; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_14_42; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_43; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_44; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_45; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_14_46; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_47; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_48; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_49; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_50; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_51; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_52; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_53; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_14_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_55; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_56; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_57; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_14_58; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_59; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_60; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_61; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_14_62; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_63; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_64; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_65; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_14_66; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_67; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_68; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_69; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_14_70; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_71; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_72; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_73; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_14_74; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_75; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_76; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_77; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_14_78; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_14_79; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_14_80; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_14_81; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_14_82; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_14_83; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_14_84; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_14_85; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_14_86; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_14_87; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_88; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_89; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_90; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_14_91; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_14_92; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_14_93; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_14_94; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_14_95; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_14_96; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_97; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_98; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_99; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_14_100; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_14_101; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_14_102; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_14_103; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_14_104; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_14_105; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_14_106; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_14_107; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_14_108; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_14_109; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_14_110; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_14_111; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_14_112; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_14_113; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_14_114; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_14_115; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_14_116; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_14_117; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_14_118; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_14_119; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_14_120; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_14_121; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_14_122; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_14_123; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_14_124; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_125; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_126; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_127; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_128; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_129; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_130; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_131; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_132; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_133; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_134; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_135; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_136; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_137; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_138; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_15_139; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_140; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_141; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_142; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_143; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_144; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_145; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_146; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_147; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_148; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_149; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_150; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_15_151; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_152; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_153; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_154; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_155; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_156; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_157; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_158; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_159; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_160; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_161; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_162; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_15_163; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_164; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_165; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_166; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_167; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_168; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_169; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_170; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_15_171; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_172; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_173; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_174; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_15_175; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_176; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_177; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_178; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_179; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_180; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_181; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_182; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_15_183; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_184; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_185; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_186; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_187; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_15_188; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_15_189; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_15_190; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_15_191; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_15_192; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_15_193; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_15_194; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_15_195; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_15_196; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_197; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_198; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_199; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_15_200; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_15_201; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_15_202; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_15_203; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_15_204; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_15_205; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_206; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_207; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_208; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_15_209; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_15_210; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_15_211; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_15_212; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_15_213; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_15_214; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_15_215; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_15_216; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_15_217; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_15_218; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_15_219; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_15_220; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_15_221; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_15_222; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_15_223; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_15_224; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_15_225; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_15_226; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_15_227; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_15_228; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_15_229; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_15_230; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_15_231; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_15_232; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_233; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_34_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_66_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_131_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_135_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_139_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_143_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_147_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_151_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_155_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_159_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_167_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_171_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_175_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_183_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_187_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_c = __vul_pipeline_q_c;
    assign __vul_port_d = __vul_pipeline_q_d;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21
    assign vul_port_c = __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21
    assign vul_port_d = __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:21
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19

    assign s8_norm_mul_6_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_7_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_10_v0 = (s8_norm_mul_6_v0 + s8_norm_mul_7_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:38:23-38:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:36:25-36:44
    assign vul_port_y = s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign __beopt_width_14 = ({64'h0, vul_port_a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({64'h0, vul_port_b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({64'h0, vul_port_c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({64'h0, vul_port_d}); // decl: <none>; prim: <none>
    assign arith_original_14 = mul_tree_14_124; // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_233; // decl: <none>; prim: <none>
    assign mul_tree_14_16 = __beopt_width_14[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_17 = __beopt_width_15[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_18 = 32'(($unsigned(32'($unsigned(mul_tree_14_16))) * $unsigned(32'($unsigned(mul_tree_14_17))))); // decl: <none>; prim: <none>
    assign mul_tree_14_19 = __beopt_width_14[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_20 = __beopt_width_15[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_21 = 32'(($unsigned(32'($unsigned(mul_tree_14_19))) * $unsigned(32'($unsigned(mul_tree_14_20))))); // decl: <none>; prim: <none>
    assign mul_tree_14_22 = {mul_tree_14_21, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_23 = __beopt_width_14[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_24 = __beopt_width_15[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_25 = 32'(($unsigned(32'($unsigned(mul_tree_14_23))) * $unsigned(32'($unsigned(mul_tree_14_24))))); // decl: <none>; prim: <none>
    assign mul_tree_14_26 = {mul_tree_14_25, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_27 = __beopt_width_14[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_28 = __beopt_width_15[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_29 = 32'(($unsigned(32'($unsigned(mul_tree_14_27))) * $unsigned(32'($unsigned(mul_tree_14_28))))); // decl: <none>; prim: <none>
    assign mul_tree_14_30 = {mul_tree_14_29, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_31 = __beopt_width_14[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_32 = __beopt_width_15[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_33 = 32'(($unsigned(32'($unsigned(mul_tree_14_31))) * $unsigned(32'($unsigned(mul_tree_14_32))))); // decl: <none>; prim: <none>
    assign mul_tree_14_34 = {mul_tree_14_33, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_35 = __beopt_width_14[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_36 = __beopt_width_15[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_37 = 32'(($unsigned(32'($unsigned(mul_tree_14_35))) * $unsigned(32'($unsigned(mul_tree_14_36))))); // decl: <none>; prim: <none>
    assign mul_tree_14_38 = {mul_tree_14_37, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_39 = __beopt_width_14[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_40 = __beopt_width_15[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_41 = 32'(($unsigned(32'($unsigned(mul_tree_14_39))) * $unsigned(32'($unsigned(mul_tree_14_40))))); // decl: <none>; prim: <none>
    assign mul_tree_14_42 = {mul_tree_14_41, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_43 = __beopt_width_14[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_44 = __beopt_width_15[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_45 = 32'(($unsigned(32'($unsigned(mul_tree_14_43))) * $unsigned(32'($unsigned(mul_tree_14_44))))); // decl: <none>; prim: <none>
    assign mul_tree_14_46 = {mul_tree_14_45, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_47 = __beopt_width_14[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_48 = __beopt_width_15[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_49 = 32'(($unsigned(32'($unsigned(mul_tree_14_47))) * $unsigned(32'($unsigned(mul_tree_14_48))))); // decl: <none>; prim: <none>
    assign mul_tree_14_50 = {mul_tree_14_49, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_51 = __beopt_width_14[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_52 = __beopt_width_15[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_53 = 32'(($unsigned(32'($unsigned(mul_tree_14_51))) * $unsigned(32'($unsigned(mul_tree_14_52))))); // decl: <none>; prim: <none>
    assign mul_tree_14_54 = {mul_tree_14_53, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_55 = __beopt_width_14[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_56 = __beopt_width_15[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_57 = 32'(($unsigned(32'($unsigned(mul_tree_14_55))) * $unsigned(32'($unsigned(mul_tree_14_56))))); // decl: <none>; prim: <none>
    assign mul_tree_14_58 = {mul_tree_14_57, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_59 = __beopt_width_14[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_60 = __beopt_width_15[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_61 = 32'(($unsigned(32'($unsigned(mul_tree_14_59))) * $unsigned(32'($unsigned(mul_tree_14_60))))); // decl: <none>; prim: <none>
    assign mul_tree_14_62 = {mul_tree_14_61, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_63 = __beopt_width_14[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_64 = __beopt_width_15[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_65 = 32'(($unsigned(32'($unsigned(mul_tree_14_63))) * $unsigned(32'($unsigned(mul_tree_14_64))))); // decl: <none>; prim: <none>
    assign mul_tree_14_66 = {mul_tree_14_65, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_67 = __beopt_width_14[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_68 = __beopt_width_15[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_14_69 = 32'(($unsigned(32'($unsigned(mul_tree_14_67))) * $unsigned(32'($unsigned(mul_tree_14_68))))); // decl: <none>; prim: <none>
    assign mul_tree_14_70 = {mul_tree_14_69, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_71 = __beopt_width_14[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_72 = __beopt_width_15[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_73 = 32'(($unsigned(32'($unsigned(mul_tree_14_71))) * $unsigned(32'($unsigned(mul_tree_14_72))))); // decl: <none>; prim: <none>
    assign mul_tree_14_74 = {mul_tree_14_73, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_75 = __beopt_width_14[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_76 = __beopt_width_15[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_14_77 = 32'(($unsigned(32'($unsigned(mul_tree_14_75))) * $unsigned(32'($unsigned(mul_tree_14_76))))); // decl: <none>; prim: <none>
    assign mul_tree_14_78 = {mul_tree_14_77, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_79 = ({17'h0, rtlzz_pipe_18_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_80 = ({1'h0, rtlzz_pipe_22_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_81 = 49'((mul_tree_14_79 + mul_tree_14_80 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_82 = ({17'h0, rtlzz_pipe_26_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_83 = ({1'h0, rtlzz_pipe_30_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_84 = 81'((mul_tree_14_82 + mul_tree_14_83 + ({80'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_85 = ({17'h0, rtlzz_pipe_34_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_86 = ({1'h0, rtlzz_pipe_38_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_87 = 65'((mul_tree_14_85 + mul_tree_14_86 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_88 = ({17'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_89 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_90 = 97'((mul_tree_14_88 + mul_tree_14_89 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_91 = ({17'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_92 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_93 = 81'((mul_tree_14_91 + mul_tree_14_92 + ({80'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_94 = ({17'h0, rtlzz_pipe_58_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_95 = ({1'h0, rtlzz_pipe_62_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_96 = 113'((mul_tree_14_94 + mul_tree_14_95 + ({112'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_97 = ({17'h0, rtlzz_pipe_66_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_98 = ({1'h0, rtlzz_pipe_70_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_99 = 97'((mul_tree_14_97 + mul_tree_14_98 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_100 = ({17'h0, rtlzz_pipe_74_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_101 = ({1'h0, rtlzz_pipe_78_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_102 = 129'((mul_tree_14_100 + mul_tree_14_101 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_103 = ({33'h0, mul_tree_14_81}); // decl: <none>; prim: <none>
    assign mul_tree_14_104 = ({1'h0, mul_tree_14_84}); // decl: <none>; prim: <none>
    assign mul_tree_14_105 = 82'((mul_tree_14_103 + mul_tree_14_104 + ({81'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_106 = ({33'h0, mul_tree_14_87}); // decl: <none>; prim: <none>
    assign mul_tree_14_107 = ({1'h0, mul_tree_14_90}); // decl: <none>; prim: <none>
    assign mul_tree_14_108 = 98'((mul_tree_14_106 + mul_tree_14_107 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_109 = ({33'h0, mul_tree_14_93}); // decl: <none>; prim: <none>
    assign mul_tree_14_110 = ({1'h0, mul_tree_14_96}); // decl: <none>; prim: <none>
    assign mul_tree_14_111 = 114'((mul_tree_14_109 + mul_tree_14_110 + ({113'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_112 = ({33'h0, mul_tree_14_99}); // decl: <none>; prim: <none>
    assign mul_tree_14_113 = ({1'h0, mul_tree_14_102}); // decl: <none>; prim: <none>
    assign mul_tree_14_114 = 130'((mul_tree_14_112 + mul_tree_14_113 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_115 = ({17'h0, mul_tree_14_105}); // decl: <none>; prim: <none>
    assign mul_tree_14_116 = ({1'h0, mul_tree_14_108}); // decl: <none>; prim: <none>
    assign mul_tree_14_117 = 99'((mul_tree_14_115 + mul_tree_14_116 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_118 = ({17'h0, mul_tree_14_111}); // decl: <none>; prim: <none>
    assign mul_tree_14_119 = ({1'h0, mul_tree_14_114}); // decl: <none>; prim: <none>
    assign mul_tree_14_120 = 131'((mul_tree_14_118 + mul_tree_14_119 + ({130'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_121 = ({33'h0, mul_tree_14_117}); // decl: <none>; prim: <none>
    assign mul_tree_14_122 = ({1'h0, mul_tree_14_120}); // decl: <none>; prim: <none>
    assign mul_tree_14_123 = 132'((mul_tree_14_121 + mul_tree_14_122 + ({131'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_124 = mul_tree_14_123[127:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_125 = __beopt_width_16[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_126 = __beopt_width_17[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_127 = 32'(($unsigned(32'($unsigned(mul_tree_15_125))) * $unsigned(32'($unsigned(mul_tree_15_126))))); // decl: <none>; prim: <none>
    assign mul_tree_15_128 = __beopt_width_16[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_129 = __beopt_width_17[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_130 = 32'(($unsigned(32'($unsigned(mul_tree_15_128))) * $unsigned(32'($unsigned(mul_tree_15_129))))); // decl: <none>; prim: <none>
    assign mul_tree_15_131 = {mul_tree_15_130, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_132 = __beopt_width_16[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_133 = __beopt_width_17[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_134 = 32'(($unsigned(32'($unsigned(mul_tree_15_132))) * $unsigned(32'($unsigned(mul_tree_15_133))))); // decl: <none>; prim: <none>
    assign mul_tree_15_135 = {mul_tree_15_134, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_136 = __beopt_width_16[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_137 = __beopt_width_17[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_138 = 32'(($unsigned(32'($unsigned(mul_tree_15_136))) * $unsigned(32'($unsigned(mul_tree_15_137))))); // decl: <none>; prim: <none>
    assign mul_tree_15_139 = {mul_tree_15_138, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_140 = __beopt_width_16[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_141 = __beopt_width_17[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_142 = 32'(($unsigned(32'($unsigned(mul_tree_15_140))) * $unsigned(32'($unsigned(mul_tree_15_141))))); // decl: <none>; prim: <none>
    assign mul_tree_15_143 = {mul_tree_15_142, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_144 = __beopt_width_16[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_145 = __beopt_width_17[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_146 = 32'(($unsigned(32'($unsigned(mul_tree_15_144))) * $unsigned(32'($unsigned(mul_tree_15_145))))); // decl: <none>; prim: <none>
    assign mul_tree_15_147 = {mul_tree_15_146, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_148 = __beopt_width_16[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_149 = __beopt_width_17[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_150 = 32'(($unsigned(32'($unsigned(mul_tree_15_148))) * $unsigned(32'($unsigned(mul_tree_15_149))))); // decl: <none>; prim: <none>
    assign mul_tree_15_151 = {mul_tree_15_150, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_152 = __beopt_width_16[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_153 = __beopt_width_17[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_154 = 32'(($unsigned(32'($unsigned(mul_tree_15_152))) * $unsigned(32'($unsigned(mul_tree_15_153))))); // decl: <none>; prim: <none>
    assign mul_tree_15_155 = {mul_tree_15_154, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_156 = __beopt_width_16[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_157 = __beopt_width_17[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_158 = 32'(($unsigned(32'($unsigned(mul_tree_15_156))) * $unsigned(32'($unsigned(mul_tree_15_157))))); // decl: <none>; prim: <none>
    assign mul_tree_15_159 = {mul_tree_15_158, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_160 = __beopt_width_16[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_161 = __beopt_width_17[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_162 = 32'(($unsigned(32'($unsigned(mul_tree_15_160))) * $unsigned(32'($unsigned(mul_tree_15_161))))); // decl: <none>; prim: <none>
    assign mul_tree_15_163 = {mul_tree_15_162, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_164 = __beopt_width_16[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_165 = __beopt_width_17[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_166 = 32'(($unsigned(32'($unsigned(mul_tree_15_164))) * $unsigned(32'($unsigned(mul_tree_15_165))))); // decl: <none>; prim: <none>
    assign mul_tree_15_167 = {mul_tree_15_166, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_168 = __beopt_width_16[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_169 = __beopt_width_17[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_170 = 32'(($unsigned(32'($unsigned(mul_tree_15_168))) * $unsigned(32'($unsigned(mul_tree_15_169))))); // decl: <none>; prim: <none>
    assign mul_tree_15_171 = {mul_tree_15_170, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_172 = __beopt_width_16[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_173 = __beopt_width_17[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_174 = 32'(($unsigned(32'($unsigned(mul_tree_15_172))) * $unsigned(32'($unsigned(mul_tree_15_173))))); // decl: <none>; prim: <none>
    assign mul_tree_15_175 = {mul_tree_15_174, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_176 = __beopt_width_16[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_177 = __beopt_width_17[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_15_178 = 32'(($unsigned(32'($unsigned(mul_tree_15_176))) * $unsigned(32'($unsigned(mul_tree_15_177))))); // decl: <none>; prim: <none>
    assign mul_tree_15_179 = {mul_tree_15_178, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_180 = __beopt_width_16[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_181 = __beopt_width_17[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_182 = 32'(($unsigned(32'($unsigned(mul_tree_15_180))) * $unsigned(32'($unsigned(mul_tree_15_181))))); // decl: <none>; prim: <none>
    assign mul_tree_15_183 = {mul_tree_15_182, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_184 = __beopt_width_16[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_185 = __beopt_width_17[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_15_186 = 32'(($unsigned(32'($unsigned(mul_tree_15_184))) * $unsigned(32'($unsigned(mul_tree_15_185))))); // decl: <none>; prim: <none>
    assign mul_tree_15_187 = {mul_tree_15_186, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_188 = ({17'h0, rtlzz_pipe_127_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_189 = ({1'h0, rtlzz_pipe_131_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_190 = 49'((mul_tree_15_188 + mul_tree_15_189 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_191 = ({17'h0, rtlzz_pipe_135_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_192 = ({1'h0, rtlzz_pipe_139_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_193 = 81'((mul_tree_15_191 + mul_tree_15_192 + ({80'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_194 = ({17'h0, rtlzz_pipe_143_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_195 = ({1'h0, rtlzz_pipe_147_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_196 = 65'((mul_tree_15_194 + mul_tree_15_195 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_197 = ({17'h0, rtlzz_pipe_151_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_198 = ({1'h0, rtlzz_pipe_155_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_199 = 97'((mul_tree_15_197 + mul_tree_15_198 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_200 = ({17'h0, rtlzz_pipe_159_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_201 = ({1'h0, rtlzz_pipe_163_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_202 = 81'((mul_tree_15_200 + mul_tree_15_201 + ({80'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_203 = ({17'h0, rtlzz_pipe_167_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_204 = ({1'h0, rtlzz_pipe_171_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_205 = 113'((mul_tree_15_203 + mul_tree_15_204 + ({112'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_206 = ({17'h0, rtlzz_pipe_175_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_207 = ({1'h0, rtlzz_pipe_179_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_208 = 97'((mul_tree_15_206 + mul_tree_15_207 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_209 = ({17'h0, rtlzz_pipe_183_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_210 = ({1'h0, rtlzz_pipe_187_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_211 = 129'((mul_tree_15_209 + mul_tree_15_210 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_212 = ({33'h0, mul_tree_15_190}); // decl: <none>; prim: <none>
    assign mul_tree_15_213 = ({1'h0, mul_tree_15_193}); // decl: <none>; prim: <none>
    assign mul_tree_15_214 = 82'((mul_tree_15_212 + mul_tree_15_213 + ({81'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_215 = ({33'h0, mul_tree_15_196}); // decl: <none>; prim: <none>
    assign mul_tree_15_216 = ({1'h0, mul_tree_15_199}); // decl: <none>; prim: <none>
    assign mul_tree_15_217 = 98'((mul_tree_15_215 + mul_tree_15_216 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_218 = ({33'h0, mul_tree_15_202}); // decl: <none>; prim: <none>
    assign mul_tree_15_219 = ({1'h0, mul_tree_15_205}); // decl: <none>; prim: <none>
    assign mul_tree_15_220 = 114'((mul_tree_15_218 + mul_tree_15_219 + ({113'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_221 = ({33'h0, mul_tree_15_208}); // decl: <none>; prim: <none>
    assign mul_tree_15_222 = ({1'h0, mul_tree_15_211}); // decl: <none>; prim: <none>
    assign mul_tree_15_223 = 130'((mul_tree_15_221 + mul_tree_15_222 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_224 = ({17'h0, mul_tree_15_214}); // decl: <none>; prim: <none>
    assign mul_tree_15_225 = ({1'h0, mul_tree_15_217}); // decl: <none>; prim: <none>
    assign mul_tree_15_226 = 99'((mul_tree_15_224 + mul_tree_15_225 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_227 = ({17'h0, mul_tree_15_220}); // decl: <none>; prim: <none>
    assign mul_tree_15_228 = ({1'h0, mul_tree_15_223}); // decl: <none>; prim: <none>
    assign mul_tree_15_229 = 131'((mul_tree_15_227 + mul_tree_15_228 + ({130'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_230 = ({33'h0, mul_tree_15_226}); // decl: <none>; prim: <none>
    assign mul_tree_15_231 = ({1'h0, mul_tree_15_229}); // decl: <none>; prim: <none>
    assign mul_tree_15_232 = 132'((mul_tree_15_230 + mul_tree_15_231 + ({131'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_233 = mul_tree_15_232[127:0]; // decl: <none>; prim: <none>
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_18_s1 <= 32'haf9;
            rtlzz_pipe_22_s1 <= 48'h0;
            rtlzz_pipe_26_s1 <= 64'h0;
            rtlzz_pipe_30_s1 <= 80'h1a8000000000000000;
            rtlzz_pipe_34_s1 <= 48'h0;
            rtlzz_pipe_38_s1 <= 64'h0;
            rtlzz_pipe_42_s1 <= 80'h0;
            rtlzz_pipe_46_s1 <= 96'h0;
            rtlzz_pipe_50_s1 <= 64'h0;
            rtlzz_pipe_54_s1 <= 80'h0;
            rtlzz_pipe_58_s1 <= 96'h0;
            rtlzz_pipe_62_s1 <= 112'h0;
            rtlzz_pipe_66_s1 <= 80'h1a8000000000000000;
            rtlzz_pipe_70_s1 <= 96'h0;
            rtlzz_pipe_74_s1 <= 112'h0;
            rtlzz_pipe_78_s1 <= 128'h40000000000000000000000000000000;
            rtlzz_pipe_127_s1 <= 32'h0;
            rtlzz_pipe_131_s1 <= 48'h0;
            rtlzz_pipe_135_s1 <= 64'h0;
            rtlzz_pipe_139_s1 <= 80'h0;
            rtlzz_pipe_143_s1 <= 48'h0;
            rtlzz_pipe_147_s1 <= 64'h0;
            rtlzz_pipe_151_s1 <= 80'h0;
            rtlzz_pipe_155_s1 <= 96'h0;
            rtlzz_pipe_159_s1 <= 64'h0;
            rtlzz_pipe_163_s1 <= 80'h0;
            rtlzz_pipe_167_s1 <= 96'h0;
            rtlzz_pipe_171_s1 <= 112'h0;
            rtlzz_pipe_175_s1 <= 80'h0;
            rtlzz_pipe_179_s1 <= 96'h0;
            rtlzz_pipe_183_s1 <= 112'h0;
            rtlzz_pipe_187_s1 <= 128'h0;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_18_s1 <= mul_tree_14_18; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_22_s1 <= mul_tree_14_22; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_26_s1 <= mul_tree_14_26; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_30_s1 <= mul_tree_14_30; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_34_s1 <= mul_tree_14_34; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_38_s1 <= mul_tree_14_38; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_14_42; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_14_46; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_14_50; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_14_54; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_58_s1 <= mul_tree_14_58; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_62_s1 <= mul_tree_14_62; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_66_s1 <= mul_tree_14_66; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_70_s1 <= mul_tree_14_70; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_74_s1 <= mul_tree_14_74; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_78_s1 <= mul_tree_14_78; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_127_s1 <= mul_tree_15_127; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_131_s1 <= mul_tree_15_131; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_135_s1 <= mul_tree_15_135; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_139_s1 <= mul_tree_15_139; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_143_s1 <= mul_tree_15_143; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_147_s1 <= mul_tree_15_147; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_151_s1 <= mul_tree_15_151; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_155_s1 <= mul_tree_15_155; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_159_s1 <= mul_tree_15_159; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_163_s1 <= mul_tree_15_163; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_167_s1 <= mul_tree_15_167; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_171_s1 <= mul_tree_15_171; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_175_s1 <= mul_tree_15_175; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_179_s1 <= mul_tree_15_179; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_183_s1 <= mul_tree_15_183; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_187_s1 <= mul_tree_15_187; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
        end
    end
end

    logic [128:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:71:1-71:19
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:73:1-73:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:35:1-35:17
    logic [255:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:37:1-37:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:37:1-37:22
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:39:1-39:16
    logic [128:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:71:1-71:19
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:73:1-73:18
    logic [63:0] s8_norm_hw_35_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:200:21-200:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:200:21-200:33
    logic [63:0] s8_norm_hw_36_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:201:21-201:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:201:21-201:33
    logic [63:0] s8_norm_hw_37_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:202:21-202:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:202:21-202:33
    logic [63:0] s8_norm_hw_38_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:203:21-203:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:203:21-203:33
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:91:3-91:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:190:3-190:26
    logic [128:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:196:3-196:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:41:1-41:13
    logic [63:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:43:1-43:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:43:1-43:18
    logic [63:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:45:1-45:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:145:3-145:37
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:47:1-47:13
    logic [63:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:49:1-49:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:49:1-49:18
    logic [63:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:51:1-51:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:152:3-152:37
    logic wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:53:1-53:13
    logic [63:0] wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:55:1-55:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:55:1-55:18
    logic [63:0] resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:57:1-57:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:159:3-159:37
    logic wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:59:1-59:13
    logic [63:0] wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:61:1-61:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:61:1-61:18
    logic [63:0] resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:63:1-63:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:166:3-166:37
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:65:1-65:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:172:3-172:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:190:3-190:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:196:3-196:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:35:1-35:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:37:1-37:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:37:1-37:22
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:39:1-39:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:41:1-41:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:43:1-43:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:43:1-43:18
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:45:1-45:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:145:3-145:37
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:47:1-47:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:49:1-49:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:49:1-49:18
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:51:1-51:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:152:3-152:37
    assign wen_c__ = wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:53:1-53:13
    assign wdata_c__ = wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:55:1-55:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:55:1-55:18
    assign resetvalue_c__ = resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:57:1-57:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:159:3-159:37
    assign wen_d__ = wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:59:1-59:13
    assign wdata_d__ = wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:61:1-61:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:61:1-61:18
    assign resetvalue_d__ = resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:63:1-63:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:166:3-166:37
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:172:3-172:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:71:1-71:19
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:73:1-73:18

    assign s8_norm_hw_35_v0 = push_value[63:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:200:21-200:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:200:21-200:33
    assign s8_norm_hw_36_v0 = push_value[127:64]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:201:21-201:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:201:21-201:33
    assign s8_norm_hw_37_v0 = push_value[191:128]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:202:21-202:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:202:21-202:33
    assign s8_norm_hw_38_v0 = push_value[255:192]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:203:21-203:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:203:21-203:33
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:91:3-91:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:190:3-190:26
    assign result__query = rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:196:3-196:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:41:1-41:13
    assign wdata_a = s8_norm_hw_35_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:43:1-43:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:43:1-43:18
    assign resetvalue_a = 64'h8000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:45:1-45:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:145:3-145:37
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:47:1-47:13
    assign wdata_b = s8_norm_hw_36_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:49:1-49:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:49:1-49:18
    assign resetvalue_b = 64'h8000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:51:1-51:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:152:3-152:37
    assign wen_c = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:53:1-53:13
    assign wdata_c = s8_norm_hw_37_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:55:1-55:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:55:1-55:18
    assign resetvalue_c = 64'h8000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:57:1-57:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:159:3-159:37
    assign wen_d = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:59:1-59:13
    assign wdata_d = s8_norm_hw_38_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:61:1-61:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:61:1-61:18
    assign resetvalue_d = 64'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:63:1-63:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:166:3-166:37
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_64/sim/top.logic.cpp:172:3-172:37
endmodule

