`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [15:0] result__query__,
  input push__vld__,
  input [15:0] push_value__,
  input [0:0] push_v__
);

reg [7:0] __vul_pipeline_q_a;
wire [7:0] resetvalue_a__;
wire wen_a__;
wire [7:0] wdata_a__;
reg [7:0] __vul_pipeline_q_b;
wire [7:0] resetvalue_b__;
wire wen_b__;
wire [7:0] wdata_b__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [15:0] __vul_pipeline_q_y;
wire [15:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 16'h7ff9;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [7:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20
    logic [7:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19
    logic [15:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:41:1-41:50
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [7:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20
    logic [7:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19
    logic [15:0] s8_norm_mul_4_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:28:26-28:31; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:33:17-33:48
    logic [15:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:41:1-41:50
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:19
    logic [7:0] __beopt_width_8; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20
    logic [7:0] __beopt_width_9; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    logic [15:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [15:0] arith_original_10; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:28:26-28:31; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:33:17-33:48
    logic [3:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [7:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:41:1-41:50
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:19

    assign s8_norm_mul_4_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign vul_port_y = s8_norm_mul_4_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:41:1-41:50
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign __beopt_width_8 = vul_port_a; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:18:1-18:20
    assign __beopt_width_9 = vul_port_b; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    assign __beopt_width_10 = ({8'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({8'h0, __beopt_width_9}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 8'(($unsigned(8'($unsigned(mul_tree_10_11))) * $unsigned(8'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 8'(($unsigned(8'($unsigned(mul_tree_10_14))) * $unsigned(8'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 8'(($unsigned(8'($unsigned(mul_tree_10_18))) * $unsigned(8'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 8'(($unsigned(8'($unsigned(mul_tree_10_22))) * $unsigned(8'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({5'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 13'((mul_tree_10_26 + mul_tree_10_27 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({5'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 17'((mul_tree_10_29 + mul_tree_10_30 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({5'h0, mul_tree_10_28}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, mul_tree_10_31}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 18'((mul_tree_10_32 + mul_tree_10_33 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_13_s1 <= 8'h19;
            rtlzz_pipe_17_s1 <= 12'h370;
            rtlzz_pipe_21_s1 <= 12'h370;
            rtlzz_pipe_25_s1 <= 16'h7900;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:19
        end
    end
end

    logic [15:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:57:1-57:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:57:1-57:18
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:59:1-59:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:59:1-59:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:33:1-33:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:33:1-33:17
    logic [15:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:35:1-35:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:35:1-35:21
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:37:1-37:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:37:1-37:16
    logic [15:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:57:1-57:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:57:1-57:18
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:59:1-59:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:59:1-59:18
    logic [7:0] s8_norm_hw_27_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:152:20-152:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:152:20-152:32
    logic [7:0] s8_norm_hw_28_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:153:20-153:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:153:20-153:32
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:77:3-77:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:142:3-142:26
    logic [15:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:31:1-31:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:148:3-148:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:39:1-39:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:39:1-39:13
    logic [7:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:41:1-41:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:41:1-41:17
    logic [7:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:43:1-43:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:111:3-111:35
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:45:1-45:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:45:1-45:13
    logic [7:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:47:1-47:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:47:1-47:17
    logic [7:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:49:1-49:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:118:3-118:35
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:51:1-51:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:51:1-51:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:55:1-55:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:124:3-124:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:142:3-142:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:31:1-31:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:148:3-148:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:33:1-33:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:33:1-33:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:35:1-35:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:35:1-35:21
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:37:1-37:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:37:1-37:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:39:1-39:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:39:1-39:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:41:1-41:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:41:1-41:17
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:43:1-43:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:111:3-111:35
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:45:1-45:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:45:1-45:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:47:1-47:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:47:1-47:17
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:49:1-49:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:118:3-118:35
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:51:1-51:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:51:1-51:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:55:1-55:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:124:3-124:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:57:1-57:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:57:1-57:18
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:59:1-59:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:59:1-59:18

    assign s8_norm_hw_27_v0 = push_value[7:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:152:20-152:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:152:20-152:32
    assign s8_norm_hw_28_v0 = push_value[15:8]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:153:20-153:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:153:20-153:32
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:77:3-77:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:142:3-142:26
    assign result__query = rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:31:1-31:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:148:3-148:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:39:1-39:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:39:1-39:13
    assign wdata_a = s8_norm_hw_27_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:41:1-41:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:41:1-41:17
    assign resetvalue_a = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:43:1-43:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:111:3-111:35
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:45:1-45:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:45:1-45:13
    assign wdata_b = s8_norm_hw_28_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:47:1-47:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:47:1-47:17
    assign resetvalue_b = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:49:1-49:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:118:3-118:35
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:51:1-51:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:51:1-51:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:53:1-53:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:55:1-55:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/MUL_8/sim/top.logic.cpp:124:3-124:37
endmodule

