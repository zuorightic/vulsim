`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [16:0] result__query__,
  input push__vld__,
  input [31:0] push_value__,
  input [0:0] push_v__
);

reg [7:0] __vul_pipeline_q_a;
wire [7:0] resetvalue_a__;
wire wen_a__;
wire [7:0] wdata_a__;
reg [7:0] __vul_pipeline_q_b;
wire [7:0] resetvalue_b__;
wire wen_b__;
wire [7:0] wdata_b__;
reg [7:0] __vul_pipeline_q_c;
wire [7:0] resetvalue_c__;
wire wen_c__;
wire [7:0] wdata_c__;
reg [7:0] __vul_pipeline_q_d;
wire [7:0] resetvalue_d__;
wire wen_d__;
wire [7:0] wdata_d__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [16:0] __vul_pipeline_q_y;
wire [16:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_c <= resetvalue_c__;
  end else begin
begin
    if (wen_c__) begin
      __vul_pipeline_q_c <= wdata_c__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_d <= resetvalue_d__;
  end else begin
begin
    if (wen_d__) begin
      __vul_pipeline_q_d <= wdata_d__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 17'h7ff9;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [7:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    logic [7:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:20
    logic [7:0] __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:20
    logic [7:0] __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:20
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [16:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:50
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [7:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    logic [7:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:20
    logic [7:0] vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:20
    logic [7:0] vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:20
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [15:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:34:26-34:31; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:43:17-43:48
    logic [15:0] s8_norm_mul_7_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:35:27-35:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:48
    logic [16:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:38:22-38:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:36:24-36:42
    logic [16:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:50
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic [15:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [15:0] arith_original_14; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:34:26-34:31; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:43:17-43:48
    logic [15:0] arith_original_15; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:35:27-35:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:48
    logic [3:0] mul_tree_14_16; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_14_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_14_18; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_14_19; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_14_20; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_14_21; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_22; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_14_23; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_14_24; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_14_25; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_26; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_14_27; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_14_28; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_14_29; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_30; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_14_31; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_14_32; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_14_33; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_14_34; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_14_35; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_14_36; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_14_37; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_14_38; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_14_39; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_14_40; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_43; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_44; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_46; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_47; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_48; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_50; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_51; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_52; // decl: <none>; prim: <none>
    logic [3:0] mul_tree_15_53; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_15_54; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_55; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_56; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_57; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_15_58; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_59; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_60; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_15_61; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_62; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_63; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_64; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_15_65; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_36_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
    logic [16:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_c = __vul_pipeline_q_c;
    assign __vul_port_d = __vul_pipeline_q_d;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:20
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:20
    assign vul_port_c = __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:20
    assign vul_port_d = __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:20
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:50
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19

    assign s8_norm_mul_6_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_7_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_10_v0 = (s8_norm_mul_6_v0 + s8_norm_mul_7_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:38:22-38:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:36:24-36:42
    assign vul_port_y = s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:50
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign __beopt_width_14 = ({8'h0, vul_port_a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({8'h0, vul_port_b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({8'h0, vul_port_c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({8'h0, vul_port_d}); // decl: <none>; prim: <none>
    assign arith_original_14 = mul_tree_14_40; // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_65; // decl: <none>; prim: <none>
    assign mul_tree_14_16 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_17 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_18 = 8'(($unsigned(8'($unsigned(mul_tree_14_16))) * $unsigned(8'($unsigned(mul_tree_14_17))))); // decl: <none>; prim: <none>
    assign mul_tree_14_19 = __beopt_width_14[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_20 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_14_21 = 8'(($unsigned(8'($unsigned(mul_tree_14_19))) * $unsigned(8'($unsigned(mul_tree_14_20))))); // decl: <none>; prim: <none>
    assign mul_tree_14_22 = {mul_tree_14_21, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_23 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_14_24 = __beopt_width_15[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_25 = 8'(($unsigned(8'($unsigned(mul_tree_14_23))) * $unsigned(8'($unsigned(mul_tree_14_24))))); // decl: <none>; prim: <none>
    assign mul_tree_14_26 = {mul_tree_14_25, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_27 = __beopt_width_14[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_14_28 = __beopt_width_15[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_14_29 = 8'(($unsigned(8'($unsigned(mul_tree_14_27))) * $unsigned(8'($unsigned(mul_tree_14_28))))); // decl: <none>; prim: <none>
    assign mul_tree_14_30 = {mul_tree_14_29, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_31 = ({5'h0, mul_tree_14_18}); // decl: <none>; prim: <none>
    assign mul_tree_14_32 = ({1'h0, mul_tree_14_22}); // decl: <none>; prim: <none>
    assign mul_tree_14_33 = 13'((mul_tree_14_31 + mul_tree_14_32 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_34 = ({5'h0, mul_tree_14_26}); // decl: <none>; prim: <none>
    assign mul_tree_14_35 = ({1'h0, mul_tree_14_30}); // decl: <none>; prim: <none>
    assign mul_tree_14_36 = 17'((mul_tree_14_34 + mul_tree_14_35 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_37 = ({5'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_38 = ({1'h0, rtlzz_pipe_36_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_39 = 18'((mul_tree_14_37 + mul_tree_14_38 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_40 = mul_tree_14_39[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_41 = __beopt_width_16[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_42 = __beopt_width_17[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_43 = 8'(($unsigned(8'($unsigned(mul_tree_15_41))) * $unsigned(8'($unsigned(mul_tree_15_42))))); // decl: <none>; prim: <none>
    assign mul_tree_15_44 = __beopt_width_16[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_45 = __beopt_width_17[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_46 = 8'(($unsigned(8'($unsigned(mul_tree_15_44))) * $unsigned(8'($unsigned(mul_tree_15_45))))); // decl: <none>; prim: <none>
    assign mul_tree_15_47 = {mul_tree_15_46, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_48 = __beopt_width_16[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_49 = __beopt_width_17[3:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_50 = 8'(($unsigned(8'($unsigned(mul_tree_15_48))) * $unsigned(8'($unsigned(mul_tree_15_49))))); // decl: <none>; prim: <none>
    assign mul_tree_15_51 = {mul_tree_15_50, 4'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_52 = __beopt_width_16[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_53 = __beopt_width_17[7:4]; // decl: <none>; prim: <none>
    assign mul_tree_15_54 = 8'(($unsigned(8'($unsigned(mul_tree_15_52))) * $unsigned(8'($unsigned(mul_tree_15_53))))); // decl: <none>; prim: <none>
    assign mul_tree_15_55 = {mul_tree_15_54, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_56 = ({5'h0, mul_tree_15_43}); // decl: <none>; prim: <none>
    assign mul_tree_15_57 = ({1'h0, mul_tree_15_47}); // decl: <none>; prim: <none>
    assign mul_tree_15_58 = 13'((mul_tree_15_56 + mul_tree_15_57 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_59 = ({5'h0, mul_tree_15_51}); // decl: <none>; prim: <none>
    assign mul_tree_15_60 = ({1'h0, mul_tree_15_55}); // decl: <none>; prim: <none>
    assign mul_tree_15_61 = 17'((mul_tree_15_59 + mul_tree_15_60 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_62 = ({5'h0, rtlzz_pipe_58_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_63 = ({1'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_64 = 18'((mul_tree_15_62 + mul_tree_15_63 + ({17'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_65 = mul_tree_15_64[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_33_s1 <= 13'h389;
            rtlzz_pipe_36_s1 <= 17'h7c70;
            rtlzz_pipe_58_s1 <= 13'h0;
            rtlzz_pipe_61_s1 <= 17'h0;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_14_33; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_36_s1 <= mul_tree_14_36; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_58_s1 <= mul_tree_15_58; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_15_61; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
        end
    end
end

    logic [16:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:71:1-71:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:71:1-71:18
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:73:1-73:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:35:1-35:17
    logic [31:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:37:1-37:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:37:1-37:21
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:39:1-39:16
    logic [16:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:71:1-71:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:71:1-71:18
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:73:1-73:18
    logic [7:0] s8_norm_hw_39_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:200:20-200:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:200:20-200:32
    logic [7:0] s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:201:20-201:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:201:20-201:32
    logic [7:0] s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:202:20-202:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:202:20-202:32
    logic [7:0] s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:203:20-203:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:203:20-203:32
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:91:3-91:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:190:3-190:26
    logic [16:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:33:1-33:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:196:3-196:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:41:1-41:13
    logic [7:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:43:1-43:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:43:1-43:17
    logic [7:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:45:1-45:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:145:3-145:35
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:47:1-47:13
    logic [7:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:49:1-49:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:49:1-49:17
    logic [7:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:51:1-51:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:152:3-152:35
    logic wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:53:1-53:13
    logic [7:0] wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:55:1-55:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:55:1-55:17
    logic [7:0] resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:159:3-159:35
    logic wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:59:1-59:13
    logic [7:0] wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:61:1-61:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:61:1-61:17
    logic [7:0] resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:63:1-63:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:166:3-166:35
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:65:1-65:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:172:3-172:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:190:3-190:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:33:1-33:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:196:3-196:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:35:1-35:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:37:1-37:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:37:1-37:21
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:39:1-39:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:41:1-41:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:43:1-43:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:43:1-43:17
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:45:1-45:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:145:3-145:35
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:47:1-47:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:49:1-49:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:49:1-49:17
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:51:1-51:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:152:3-152:35
    assign wen_c__ = wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:53:1-53:13
    assign wdata_c__ = wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:55:1-55:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:55:1-55:17
    assign resetvalue_c__ = resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:159:3-159:35
    assign wen_d__ = wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:59:1-59:13
    assign wdata_d__ = wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:61:1-61:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:61:1-61:17
    assign resetvalue_d__ = resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:63:1-63:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:166:3-166:35
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:172:3-172:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:71:1-71:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:71:1-71:18
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:73:1-73:18

    assign s8_norm_hw_39_v0 = push_value[7:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:200:20-200:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:200:20-200:32
    assign s8_norm_hw_40_v0 = push_value[15:8]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:201:20-201:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:201:20-201:32
    assign s8_norm_hw_41_v0 = push_value[23:16]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:202:20-202:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:202:20-202:32
    assign s8_norm_hw_42_v0 = push_value[31:24]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:203:20-203:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:203:20-203:32
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:91:3-91:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:190:3-190:26
    assign result__query = rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:33:1-33:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:196:3-196:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:41:1-41:13
    assign wdata_a = s8_norm_hw_39_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:43:1-43:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:43:1-43:17
    assign resetvalue_a = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:45:1-45:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:145:3-145:35
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:47:1-47:13
    assign wdata_b = s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:49:1-49:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:49:1-49:17
    assign resetvalue_b = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:51:1-51:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:152:3-152:35
    assign wen_c = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:53:1-53:13
    assign wdata_c = s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:55:1-55:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:55:1-55:17
    assign resetvalue_c = 8'hb5; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:159:3-159:35
    assign wen_d = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:59:1-59:13
    assign wdata_d = s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:61:1-61:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:61:1-61:17
    assign resetvalue_d = 8'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:63:1-63:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:166:3-166:35
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_8/sim/top.logic.cpp:172:3-172:37
endmodule

