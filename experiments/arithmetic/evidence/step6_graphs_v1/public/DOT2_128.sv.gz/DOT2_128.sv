`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [256:0] result__query__,
  input push__vld__,
  input [511:0] push_value__,
  input [0:0] push_v__
);

reg [127:0] __vul_pipeline_q_a;
wire [127:0] resetvalue_a__;
wire wen_a__;
wire [127:0] wdata_a__;
reg [127:0] __vul_pipeline_q_b;
wire [127:0] resetvalue_b__;
wire wen_b__;
wire [127:0] wdata_b__;
reg [127:0] __vul_pipeline_q_c;
wire [127:0] resetvalue_c__;
wire wen_c__;
wire [127:0] wdata_c__;
reg [127:0] __vul_pipeline_q_d;
wire [127:0] resetvalue_d__;
wire wen_d__;
wire [127:0] wdata_d__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [256:0] __vul_pipeline_q_y;
wire [256:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_c <= resetvalue_c__;
  end else begin
begin
    if (wen_c__) begin
      __vul_pipeline_q_c <= wdata_c__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_d <= resetvalue_d__;
  end else begin
begin
    if (wen_d__) begin
      __vul_pipeline_q_d <= wdata_d__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 257'h04000000000000002000000000000003900000000000000d40000000000000af9;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [127:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22
    logic [127:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic [127:0] __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [256:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [127:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22
    logic [127:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic [127:0] vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [255:0] s8_norm_mul_6_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:34:27-34:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:43:17-43:52
    logic [255:0] s8_norm_mul_7_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:52
    logic [256:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:38:23-38:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:36:25-36:44
    logic [256:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic [255:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [255:0] arith_original_14; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:34:27-34:32; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:43:17-43:52
    logic [255:0] arith_original_15; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:47:17-47:52
    logic [31:0] mul_tree_14_16; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_17; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_19; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_20; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_21; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_14_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_23; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_24; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_25; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_14_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_27; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_28; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_29; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_14_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_31; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_32; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_33; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_14_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_35; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_36; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_37; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_14_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_39; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_40; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_41; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_14_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_43; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_44; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_45; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_14_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_47; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_48; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_49; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_14_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_51; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_52; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_53; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_14_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_55; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_56; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_57; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_14_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_59; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_60; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_61; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_14_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_63; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_64; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_65; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_14_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_67; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_68; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_69; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_14_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_71; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_72; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_73; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_14_74; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_75; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_14_76; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_14_77; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_14_78; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_79; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_80; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_81; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_14_82; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_14_83; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_14_84; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_14_85; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_14_86; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_14_87; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_14_88; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_14_89; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_14_90; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_14_91; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_14_92; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_14_93; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_14_94; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_14_95; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_14_96; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_14_97; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_14_98; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_14_99; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_14_100; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_14_101; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_14_102; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_14_103; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_14_104; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_14_105; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_14_106; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_14_107; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_14_108; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_14_109; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_14_110; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_14_111; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_14_112; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_14_113; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_14_114; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_14_115; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_14_116; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_14_117; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_14_118; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_14_119; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_14_120; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_14_121; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_14_122; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_14_123; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_14_124; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_125; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_126; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_127; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_128; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_129; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_130; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_131; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_132; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_133; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_134; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_135; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_136; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_137; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_138; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_15_139; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_140; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_141; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_142; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_143; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_144; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_145; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_146; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_147; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_148; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_149; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_150; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_15_151; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_152; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_153; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_154; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_15_155; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_156; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_157; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_158; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_15_159; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_160; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_161; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_162; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_15_163; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_164; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_165; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_166; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_15_167; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_168; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_169; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_170; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_15_171; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_172; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_173; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_174; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_15_175; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_176; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_177; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_178; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_15_179; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_180; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_181; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_182; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_15_183; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_184; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_15_185; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_15_186; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_15_187; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_188; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_189; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_190; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_15_191; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_15_192; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_15_193; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_15_194; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_15_195; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_15_196; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_197; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_198; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_199; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_15_200; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_15_201; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_15_202; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_15_203; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_15_204; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_15_205; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_206; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_207; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_15_208; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_15_209; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_15_210; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_15_211; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_15_212; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_15_213; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_15_214; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_15_215; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_15_216; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_15_217; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_15_218; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_15_219; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_15_220; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_15_221; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_15_222; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_15_223; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_15_224; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_15_225; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_15_226; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_15_227; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_15_228; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_15_229; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_15_230; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_15_231; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_15_232; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_15_233; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_34_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_66_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_131_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_135_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_139_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_143_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_147_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_151_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_155_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_159_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_167_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_171_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_175_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_183_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_187_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_c = __vul_pipeline_q_c;
    assign __vul_port_d = __vul_pipeline_q_d;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    assign vul_port_c = __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    assign vul_port_d = __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19

    assign s8_norm_mul_6_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_7_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_10_v0 = (s8_norm_mul_6_v0 + s8_norm_mul_7_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:38:23-38:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:36:25-36:44
    assign vul_port_y = s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:55:1-55:52
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign __beopt_width_14 = ({128'h0, vul_port_a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({128'h0, vul_port_b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({128'h0, vul_port_c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({128'h0, vul_port_d}); // decl: <none>; prim: <none>
    assign arith_original_14 = mul_tree_14_124; // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_233; // decl: <none>; prim: <none>
    assign mul_tree_14_16 = __beopt_width_14[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_17 = __beopt_width_15[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_18 = 64'(($unsigned(64'($unsigned(mul_tree_14_16))) * $unsigned(64'($unsigned(mul_tree_14_17))))); // decl: <none>; prim: <none>
    assign mul_tree_14_19 = __beopt_width_14[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_20 = __beopt_width_15[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_21 = 64'(($unsigned(64'($unsigned(mul_tree_14_19))) * $unsigned(64'($unsigned(mul_tree_14_20))))); // decl: <none>; prim: <none>
    assign mul_tree_14_22 = {mul_tree_14_21, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_23 = __beopt_width_14[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_24 = __beopt_width_15[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_25 = 64'(($unsigned(64'($unsigned(mul_tree_14_23))) * $unsigned(64'($unsigned(mul_tree_14_24))))); // decl: <none>; prim: <none>
    assign mul_tree_14_26 = {mul_tree_14_25, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_27 = __beopt_width_14[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_28 = __beopt_width_15[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_29 = 64'(($unsigned(64'($unsigned(mul_tree_14_27))) * $unsigned(64'($unsigned(mul_tree_14_28))))); // decl: <none>; prim: <none>
    assign mul_tree_14_30 = {mul_tree_14_29, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_31 = __beopt_width_14[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_32 = __beopt_width_15[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_33 = 64'(($unsigned(64'($unsigned(mul_tree_14_31))) * $unsigned(64'($unsigned(mul_tree_14_32))))); // decl: <none>; prim: <none>
    assign mul_tree_14_34 = {mul_tree_14_33, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_35 = __beopt_width_14[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_36 = __beopt_width_15[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_37 = 64'(($unsigned(64'($unsigned(mul_tree_14_35))) * $unsigned(64'($unsigned(mul_tree_14_36))))); // decl: <none>; prim: <none>
    assign mul_tree_14_38 = {mul_tree_14_37, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_39 = __beopt_width_14[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_40 = __beopt_width_15[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_41 = 64'(($unsigned(64'($unsigned(mul_tree_14_39))) * $unsigned(64'($unsigned(mul_tree_14_40))))); // decl: <none>; prim: <none>
    assign mul_tree_14_42 = {mul_tree_14_41, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_43 = __beopt_width_14[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_44 = __beopt_width_15[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_45 = 64'(($unsigned(64'($unsigned(mul_tree_14_43))) * $unsigned(64'($unsigned(mul_tree_14_44))))); // decl: <none>; prim: <none>
    assign mul_tree_14_46 = {mul_tree_14_45, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_47 = __beopt_width_14[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_48 = __beopt_width_15[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_49 = 64'(($unsigned(64'($unsigned(mul_tree_14_47))) * $unsigned(64'($unsigned(mul_tree_14_48))))); // decl: <none>; prim: <none>
    assign mul_tree_14_50 = {mul_tree_14_49, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_51 = __beopt_width_14[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_52 = __beopt_width_15[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_53 = 64'(($unsigned(64'($unsigned(mul_tree_14_51))) * $unsigned(64'($unsigned(mul_tree_14_52))))); // decl: <none>; prim: <none>
    assign mul_tree_14_54 = {mul_tree_14_53, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_55 = __beopt_width_14[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_56 = __beopt_width_15[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_57 = 64'(($unsigned(64'($unsigned(mul_tree_14_55))) * $unsigned(64'($unsigned(mul_tree_14_56))))); // decl: <none>; prim: <none>
    assign mul_tree_14_58 = {mul_tree_14_57, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_59 = __beopt_width_14[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_60 = __beopt_width_15[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_61 = 64'(($unsigned(64'($unsigned(mul_tree_14_59))) * $unsigned(64'($unsigned(mul_tree_14_60))))); // decl: <none>; prim: <none>
    assign mul_tree_14_62 = {mul_tree_14_61, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_63 = __beopt_width_14[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_64 = __beopt_width_15[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_65 = 64'(($unsigned(64'($unsigned(mul_tree_14_63))) * $unsigned(64'($unsigned(mul_tree_14_64))))); // decl: <none>; prim: <none>
    assign mul_tree_14_66 = {mul_tree_14_65, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_67 = __beopt_width_14[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_68 = __beopt_width_15[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_14_69 = 64'(($unsigned(64'($unsigned(mul_tree_14_67))) * $unsigned(64'($unsigned(mul_tree_14_68))))); // decl: <none>; prim: <none>
    assign mul_tree_14_70 = {mul_tree_14_69, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_71 = __beopt_width_14[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_72 = __beopt_width_15[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_14_73 = 64'(($unsigned(64'($unsigned(mul_tree_14_71))) * $unsigned(64'($unsigned(mul_tree_14_72))))); // decl: <none>; prim: <none>
    assign mul_tree_14_74 = {mul_tree_14_73, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_75 = __beopt_width_14[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_76 = __beopt_width_15[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_14_77 = 64'(($unsigned(64'($unsigned(mul_tree_14_75))) * $unsigned(64'($unsigned(mul_tree_14_76))))); // decl: <none>; prim: <none>
    assign mul_tree_14_78 = {mul_tree_14_77, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_79 = ({33'h0, rtlzz_pipe_18_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_80 = ({1'h0, rtlzz_pipe_22_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_81 = 97'((mul_tree_14_79 + mul_tree_14_80 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_82 = ({33'h0, rtlzz_pipe_26_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_83 = ({1'h0, rtlzz_pipe_30_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_84 = 161'((mul_tree_14_82 + mul_tree_14_83 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_85 = ({33'h0, rtlzz_pipe_34_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_86 = ({1'h0, rtlzz_pipe_38_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_87 = 129'((mul_tree_14_85 + mul_tree_14_86 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_88 = ({33'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_89 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_90 = 193'((mul_tree_14_88 + mul_tree_14_89 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_91 = ({33'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_92 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_93 = 161'((mul_tree_14_91 + mul_tree_14_92 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_94 = ({33'h0, rtlzz_pipe_58_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_95 = ({1'h0, rtlzz_pipe_62_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_96 = 225'((mul_tree_14_94 + mul_tree_14_95 + ({224'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_97 = ({33'h0, rtlzz_pipe_66_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_98 = ({1'h0, rtlzz_pipe_70_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_99 = 193'((mul_tree_14_97 + mul_tree_14_98 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_100 = ({33'h0, rtlzz_pipe_74_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_101 = ({1'h0, rtlzz_pipe_78_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_102 = 257'((mul_tree_14_100 + mul_tree_14_101 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_103 = ({65'h0, mul_tree_14_81}); // decl: <none>; prim: <none>
    assign mul_tree_14_104 = ({1'h0, mul_tree_14_84}); // decl: <none>; prim: <none>
    assign mul_tree_14_105 = 162'((mul_tree_14_103 + mul_tree_14_104 + ({161'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_106 = ({65'h0, mul_tree_14_87}); // decl: <none>; prim: <none>
    assign mul_tree_14_107 = ({1'h0, mul_tree_14_90}); // decl: <none>; prim: <none>
    assign mul_tree_14_108 = 194'((mul_tree_14_106 + mul_tree_14_107 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_109 = ({65'h0, mul_tree_14_93}); // decl: <none>; prim: <none>
    assign mul_tree_14_110 = ({1'h0, mul_tree_14_96}); // decl: <none>; prim: <none>
    assign mul_tree_14_111 = 226'((mul_tree_14_109 + mul_tree_14_110 + ({225'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_112 = ({65'h0, mul_tree_14_99}); // decl: <none>; prim: <none>
    assign mul_tree_14_113 = ({1'h0, mul_tree_14_102}); // decl: <none>; prim: <none>
    assign mul_tree_14_114 = 258'((mul_tree_14_112 + mul_tree_14_113 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_115 = ({33'h0, mul_tree_14_105}); // decl: <none>; prim: <none>
    assign mul_tree_14_116 = ({1'h0, mul_tree_14_108}); // decl: <none>; prim: <none>
    assign mul_tree_14_117 = 195'((mul_tree_14_115 + mul_tree_14_116 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_118 = ({33'h0, mul_tree_14_111}); // decl: <none>; prim: <none>
    assign mul_tree_14_119 = ({1'h0, mul_tree_14_114}); // decl: <none>; prim: <none>
    assign mul_tree_14_120 = 259'((mul_tree_14_118 + mul_tree_14_119 + ({258'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_121 = ({65'h0, mul_tree_14_117}); // decl: <none>; prim: <none>
    assign mul_tree_14_122 = ({1'h0, mul_tree_14_120}); // decl: <none>; prim: <none>
    assign mul_tree_14_123 = 260'((mul_tree_14_121 + mul_tree_14_122 + ({259'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_124 = mul_tree_14_123[255:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_125 = __beopt_width_16[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_126 = __beopt_width_17[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_127 = 64'(($unsigned(64'($unsigned(mul_tree_15_125))) * $unsigned(64'($unsigned(mul_tree_15_126))))); // decl: <none>; prim: <none>
    assign mul_tree_15_128 = __beopt_width_16[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_129 = __beopt_width_17[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_130 = 64'(($unsigned(64'($unsigned(mul_tree_15_128))) * $unsigned(64'($unsigned(mul_tree_15_129))))); // decl: <none>; prim: <none>
    assign mul_tree_15_131 = {mul_tree_15_130, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_132 = __beopt_width_16[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_133 = __beopt_width_17[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_134 = 64'(($unsigned(64'($unsigned(mul_tree_15_132))) * $unsigned(64'($unsigned(mul_tree_15_133))))); // decl: <none>; prim: <none>
    assign mul_tree_15_135 = {mul_tree_15_134, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_136 = __beopt_width_16[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_137 = __beopt_width_17[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_138 = 64'(($unsigned(64'($unsigned(mul_tree_15_136))) * $unsigned(64'($unsigned(mul_tree_15_137))))); // decl: <none>; prim: <none>
    assign mul_tree_15_139 = {mul_tree_15_138, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_140 = __beopt_width_16[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_141 = __beopt_width_17[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_142 = 64'(($unsigned(64'($unsigned(mul_tree_15_140))) * $unsigned(64'($unsigned(mul_tree_15_141))))); // decl: <none>; prim: <none>
    assign mul_tree_15_143 = {mul_tree_15_142, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_144 = __beopt_width_16[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_145 = __beopt_width_17[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_146 = 64'(($unsigned(64'($unsigned(mul_tree_15_144))) * $unsigned(64'($unsigned(mul_tree_15_145))))); // decl: <none>; prim: <none>
    assign mul_tree_15_147 = {mul_tree_15_146, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_148 = __beopt_width_16[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_149 = __beopt_width_17[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_150 = 64'(($unsigned(64'($unsigned(mul_tree_15_148))) * $unsigned(64'($unsigned(mul_tree_15_149))))); // decl: <none>; prim: <none>
    assign mul_tree_15_151 = {mul_tree_15_150, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_152 = __beopt_width_16[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_153 = __beopt_width_17[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_154 = 64'(($unsigned(64'($unsigned(mul_tree_15_152))) * $unsigned(64'($unsigned(mul_tree_15_153))))); // decl: <none>; prim: <none>
    assign mul_tree_15_155 = {mul_tree_15_154, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_156 = __beopt_width_16[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_157 = __beopt_width_17[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_158 = 64'(($unsigned(64'($unsigned(mul_tree_15_156))) * $unsigned(64'($unsigned(mul_tree_15_157))))); // decl: <none>; prim: <none>
    assign mul_tree_15_159 = {mul_tree_15_158, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_160 = __beopt_width_16[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_161 = __beopt_width_17[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_162 = 64'(($unsigned(64'($unsigned(mul_tree_15_160))) * $unsigned(64'($unsigned(mul_tree_15_161))))); // decl: <none>; prim: <none>
    assign mul_tree_15_163 = {mul_tree_15_162, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_164 = __beopt_width_16[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_165 = __beopt_width_17[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_166 = 64'(($unsigned(64'($unsigned(mul_tree_15_164))) * $unsigned(64'($unsigned(mul_tree_15_165))))); // decl: <none>; prim: <none>
    assign mul_tree_15_167 = {mul_tree_15_166, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_168 = __beopt_width_16[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_169 = __beopt_width_17[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_170 = 64'(($unsigned(64'($unsigned(mul_tree_15_168))) * $unsigned(64'($unsigned(mul_tree_15_169))))); // decl: <none>; prim: <none>
    assign mul_tree_15_171 = {mul_tree_15_170, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_172 = __beopt_width_16[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_173 = __beopt_width_17[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_174 = 64'(($unsigned(64'($unsigned(mul_tree_15_172))) * $unsigned(64'($unsigned(mul_tree_15_173))))); // decl: <none>; prim: <none>
    assign mul_tree_15_175 = {mul_tree_15_174, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_176 = __beopt_width_16[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_177 = __beopt_width_17[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_15_178 = 64'(($unsigned(64'($unsigned(mul_tree_15_176))) * $unsigned(64'($unsigned(mul_tree_15_177))))); // decl: <none>; prim: <none>
    assign mul_tree_15_179 = {mul_tree_15_178, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_180 = __beopt_width_16[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_181 = __beopt_width_17[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_15_182 = 64'(($unsigned(64'($unsigned(mul_tree_15_180))) * $unsigned(64'($unsigned(mul_tree_15_181))))); // decl: <none>; prim: <none>
    assign mul_tree_15_183 = {mul_tree_15_182, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_184 = __beopt_width_16[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_185 = __beopt_width_17[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_15_186 = 64'(($unsigned(64'($unsigned(mul_tree_15_184))) * $unsigned(64'($unsigned(mul_tree_15_185))))); // decl: <none>; prim: <none>
    assign mul_tree_15_187 = {mul_tree_15_186, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_188 = ({33'h0, rtlzz_pipe_127_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_189 = ({1'h0, rtlzz_pipe_131_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_190 = 97'((mul_tree_15_188 + mul_tree_15_189 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_191 = ({33'h0, rtlzz_pipe_135_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_192 = ({1'h0, rtlzz_pipe_139_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_193 = 161'((mul_tree_15_191 + mul_tree_15_192 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_194 = ({33'h0, rtlzz_pipe_143_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_195 = ({1'h0, rtlzz_pipe_147_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_196 = 129'((mul_tree_15_194 + mul_tree_15_195 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_197 = ({33'h0, rtlzz_pipe_151_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_198 = ({1'h0, rtlzz_pipe_155_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_199 = 193'((mul_tree_15_197 + mul_tree_15_198 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_200 = ({33'h0, rtlzz_pipe_159_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_201 = ({1'h0, rtlzz_pipe_163_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_202 = 161'((mul_tree_15_200 + mul_tree_15_201 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_203 = ({33'h0, rtlzz_pipe_167_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_204 = ({1'h0, rtlzz_pipe_171_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_205 = 225'((mul_tree_15_203 + mul_tree_15_204 + ({224'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_206 = ({33'h0, rtlzz_pipe_175_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_207 = ({1'h0, rtlzz_pipe_179_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_208 = 193'((mul_tree_15_206 + mul_tree_15_207 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_209 = ({33'h0, rtlzz_pipe_183_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_210 = ({1'h0, rtlzz_pipe_187_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_211 = 257'((mul_tree_15_209 + mul_tree_15_210 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_212 = ({65'h0, mul_tree_15_190}); // decl: <none>; prim: <none>
    assign mul_tree_15_213 = ({1'h0, mul_tree_15_193}); // decl: <none>; prim: <none>
    assign mul_tree_15_214 = 162'((mul_tree_15_212 + mul_tree_15_213 + ({161'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_215 = ({65'h0, mul_tree_15_196}); // decl: <none>; prim: <none>
    assign mul_tree_15_216 = ({1'h0, mul_tree_15_199}); // decl: <none>; prim: <none>
    assign mul_tree_15_217 = 194'((mul_tree_15_215 + mul_tree_15_216 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_218 = ({65'h0, mul_tree_15_202}); // decl: <none>; prim: <none>
    assign mul_tree_15_219 = ({1'h0, mul_tree_15_205}); // decl: <none>; prim: <none>
    assign mul_tree_15_220 = 226'((mul_tree_15_218 + mul_tree_15_219 + ({225'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_221 = ({65'h0, mul_tree_15_208}); // decl: <none>; prim: <none>
    assign mul_tree_15_222 = ({1'h0, mul_tree_15_211}); // decl: <none>; prim: <none>
    assign mul_tree_15_223 = 258'((mul_tree_15_221 + mul_tree_15_222 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_224 = ({33'h0, mul_tree_15_214}); // decl: <none>; prim: <none>
    assign mul_tree_15_225 = ({1'h0, mul_tree_15_217}); // decl: <none>; prim: <none>
    assign mul_tree_15_226 = 195'((mul_tree_15_224 + mul_tree_15_225 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_227 = ({33'h0, mul_tree_15_220}); // decl: <none>; prim: <none>
    assign mul_tree_15_228 = ({1'h0, mul_tree_15_223}); // decl: <none>; prim: <none>
    assign mul_tree_15_229 = 259'((mul_tree_15_227 + mul_tree_15_228 + ({258'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_230 = ({65'h0, mul_tree_15_226}); // decl: <none>; prim: <none>
    assign mul_tree_15_231 = ({1'h0, mul_tree_15_229}); // decl: <none>; prim: <none>
    assign mul_tree_15_232 = 260'((mul_tree_15_230 + mul_tree_15_231 + ({259'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_233 = mul_tree_15_232[255:0]; // decl: <none>; prim: <none>
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_18_s1 <= 64'haf9;
            rtlzz_pipe_22_s1 <= 96'h0;
            rtlzz_pipe_26_s1 <= 128'h6a0000000000000000;
            rtlzz_pipe_30_s1 <= 160'h1a80000000000000000000000000000000;
            rtlzz_pipe_34_s1 <= 96'h0;
            rtlzz_pipe_38_s1 <= 128'h0;
            rtlzz_pipe_42_s1 <= 160'h0;
            rtlzz_pipe_46_s1 <= 192'h0;
            rtlzz_pipe_50_s1 <= 128'h6a0000000000000000;
            rtlzz_pipe_54_s1 <= 160'h0;
            rtlzz_pipe_58_s1 <= 192'h400000000000000000000000000000000;
            rtlzz_pipe_62_s1 <= 224'h1000000000000000000000000000000000000000000000000;
            rtlzz_pipe_66_s1 <= 160'h1a80000000000000000000000000000000;
            rtlzz_pipe_70_s1 <= 192'h0;
            rtlzz_pipe_74_s1 <= 224'h1000000000000000000000000000000000000000000000000;
            rtlzz_pipe_78_s1 <= 256'h4000000000000000000000000000000000000000000000000000000000000000;
            rtlzz_pipe_127_s1 <= 64'h0;
            rtlzz_pipe_131_s1 <= 96'h0;
            rtlzz_pipe_135_s1 <= 128'h0;
            rtlzz_pipe_139_s1 <= 160'h0;
            rtlzz_pipe_143_s1 <= 96'h0;
            rtlzz_pipe_147_s1 <= 128'h0;
            rtlzz_pipe_151_s1 <= 160'h0;
            rtlzz_pipe_155_s1 <= 192'h0;
            rtlzz_pipe_159_s1 <= 128'h0;
            rtlzz_pipe_163_s1 <= 160'h0;
            rtlzz_pipe_167_s1 <= 192'h0;
            rtlzz_pipe_171_s1 <= 224'h0;
            rtlzz_pipe_175_s1 <= 160'h0;
            rtlzz_pipe_179_s1 <= 192'h0;
            rtlzz_pipe_183_s1 <= 224'h0;
            rtlzz_pipe_187_s1 <= 256'h0;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_18_s1 <= mul_tree_14_18; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_22_s1 <= mul_tree_14_22; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_26_s1 <= mul_tree_14_26; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_30_s1 <= mul_tree_14_30; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_34_s1 <= mul_tree_14_34; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_38_s1 <= mul_tree_14_38; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_14_42; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_14_46; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_14_50; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_14_54; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_58_s1 <= mul_tree_14_58; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_62_s1 <= mul_tree_14_62; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_66_s1 <= mul_tree_14_66; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_70_s1 <= mul_tree_14_70; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_74_s1 <= mul_tree_14_74; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_78_s1 <= mul_tree_14_78; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_127_s1 <= mul_tree_15_127; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_131_s1 <= mul_tree_15_131; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_135_s1 <= mul_tree_15_135; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_139_s1 <= mul_tree_15_139; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_143_s1 <= mul_tree_15_143; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_147_s1 <= mul_tree_15_147; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_151_s1 <= mul_tree_15_151; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_155_s1 <= mul_tree_15_155; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_159_s1 <= mul_tree_15_159; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_163_s1 <= mul_tree_15_163; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_167_s1 <= mul_tree_15_167; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_171_s1 <= mul_tree_15_171; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_175_s1 <= mul_tree_15_175; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_179_s1 <= mul_tree_15_179; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_183_s1 <= mul_tree_15_183; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_187_s1 <= mul_tree_15_187; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
        end
    end
end

    logic [256:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:71:1-71:19
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:73:1-73:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:35:1-35:17
    logic [511:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:37:1-37:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:37:1-37:22
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:39:1-39:16
    logic [256:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:71:1-71:19
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:73:1-73:18
    logic [127:0] s8_norm_hw_39_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:200:22-200:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:200:22-200:34
    logic [127:0] s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:201:22-201:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:201:22-201:34
    logic [127:0] s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:202:22-202:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:202:22-202:34
    logic [127:0] s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:203:22-203:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:203:22-203:34
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:91:3-91:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:190:3-190:26
    logic [256:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:196:3-196:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:41:1-41:13
    logic [127:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:43:1-43:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:43:1-43:19
    logic [127:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:45:1-45:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:145:3-145:39
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:47:1-47:13
    logic [127:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:49:1-49:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:49:1-49:19
    logic [127:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:51:1-51:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:152:3-152:39
    logic wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:53:1-53:13
    logic [127:0] wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:55:1-55:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:55:1-55:19
    logic [127:0] resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:57:1-57:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:159:3-159:39
    logic wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:59:1-59:13
    logic [127:0] wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:61:1-61:19
    logic [127:0] resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:166:3-166:39
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:65:1-65:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:172:3-172:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:190:3-190:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:196:3-196:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:35:1-35:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:37:1-37:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:37:1-37:22
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:39:1-39:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:41:1-41:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:43:1-43:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:43:1-43:19
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:45:1-45:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:145:3-145:39
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:47:1-47:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:49:1-49:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:49:1-49:19
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:51:1-51:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:152:3-152:39
    assign wen_c__ = wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:53:1-53:13
    assign wdata_c__ = wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:55:1-55:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:55:1-55:19
    assign resetvalue_c__ = resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:57:1-57:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:159:3-159:39
    assign wen_d__ = wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:59:1-59:13
    assign wdata_d__ = wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:61:1-61:19
    assign resetvalue_d__ = resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:166:3-166:39
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:172:3-172:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:71:1-71:19
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:73:1-73:18

    assign s8_norm_hw_39_v0 = push_value[127:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:200:22-200:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:200:22-200:34
    assign s8_norm_hw_40_v0 = push_value[255:128]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:201:22-201:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:201:22-201:34
    assign s8_norm_hw_41_v0 = push_value[383:256]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:202:22-202:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:202:22-202:34
    assign s8_norm_hw_42_v0 = push_value[511:384]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:203:22-203:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:203:22-203:34
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:91:3-91:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:190:3-190:26
    assign result__query = rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:196:3-196:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:41:1-41:13
    assign wdata_a = s8_norm_hw_39_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:43:1-43:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:43:1-43:19
    assign resetvalue_a = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:45:1-45:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:145:3-145:39
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:47:1-47:13
    assign wdata_b = s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:49:1-49:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:49:1-49:19
    assign resetvalue_b = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:51:1-51:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:152:3-152:39
    assign wen_c = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:53:1-53:13
    assign wdata_c = s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:55:1-55:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:55:1-55:19
    assign resetvalue_c = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:57:1-57:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:159:3-159:39
    assign wen_d = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:59:1-59:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:59:1-59:13
    assign wdata_d = s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:61:1-61:19
    assign resetvalue_d = 128'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:166:3-166:39
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-final/DOT2_128/sim/top.logic.cpp:172:3-172:37
endmodule

