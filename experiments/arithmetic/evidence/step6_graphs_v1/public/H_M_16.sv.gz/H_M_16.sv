`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [15:0] result__query__,
  input push__vld__,
  input [48:0] push_value__,
  input [0:0] push_v__
);

reg [15:0] __vul_pipeline_q_a;
wire [15:0] resetvalue_a__;
wire wen_a__;
wire [15:0] wdata_a__;
reg [15:0] __vul_pipeline_q_b;
wire [15:0] resetvalue_b__;
wire wen_b__;
wire [15:0] wdata_b__;
reg [15:0] __vul_pipeline_q_c;
wire [15:0] resetvalue_c__;
wire wen_c__;
wire [15:0] wdata_c__;
reg [0:0] __vul_pipeline_q_sel;
wire [0:0] resetvalue_sel__;
wire wen_sel__;
wire [0:0] wdata_sel__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [15:0] __vul_pipeline_q_y;
wire [15:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_c <= resetvalue_c__;
  end else begin
begin
    if (wen_c__) begin
      __vul_pipeline_q_c <= wdata_c__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_sel <= resetvalue_sel__;
  end else begin
begin
    if (wen_sel__) begin
      __vul_pipeline_q_sel <= wdata_sel__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 16'h8b2e;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [15:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21
    logic [15:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21
    logic [15:0] __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21
    logic __vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [15:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:50
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [15:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21
    logic [15:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21
    logic [15:0] vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21
    logic vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [15:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:35:27-35:43; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
    logic [15:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:42:17-42:50
    logic [15:0] s8_norm_add_12_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:37:22-37:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:37:22-37:62
    logic [15:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:50
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic [15:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:42:17-42:50
    logic [7:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:35:27-35:43; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
    logic [15:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_c = __vul_pipeline_q_c;
    assign __vul_port_sel = __vul_pipeline_q_sel;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:21
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:21
    assign vul_port_c = __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:21
    assign vul_port_sel = __vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:50
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19

    assign s8_norm_mux_9_v0 = (vul_port_sel ? vul_port_c : 16'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:35:27-35:43; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
    assign s8_norm_mul_10_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_12_v0 = (s8_norm_mul_10_v0 + rtlzz_pipe_5_s1); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:37:22-37:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:37:22-37:62
    assign vul_port_y = s8_norm_add_12_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:50
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = vul_port_a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = vul_port_b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 16'(($unsigned(16'($unsigned(mul_tree_10_11))) * $unsigned(16'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = vul_port_a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = vul_port_b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 16'(($unsigned(16'($unsigned(mul_tree_10_14))) * $unsigned(16'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = vul_port_a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = vul_port_b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 16'(($unsigned(16'($unsigned(mul_tree_10_18))) * $unsigned(16'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = vul_port_a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = vul_port_b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 16'(($unsigned(16'($unsigned(mul_tree_10_22))) * $unsigned(16'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({9'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 25'((mul_tree_10_26 + mul_tree_10_27 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({9'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 33'((mul_tree_10_29 + mul_tree_10_30 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({9'h0, mul_tree_10_28}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, mul_tree_10_31}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 34'((mul_tree_10_32 + mul_tree_10_33 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_5_s1 <= 16'h8035;
            rtlzz_pipe_13_s1 <= 16'haf9;
            rtlzz_pipe_17_s1 <= 24'h1a8000;
            rtlzz_pipe_21_s1 <= 24'h1a8000;
            rtlzz_pipe_25_s1 <= 32'h40000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:35:27-35:43; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
        end
        if (vul_port_iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
        end
    end
end

    logic [15:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:71:1-71:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:71:1-71:18
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:73:1-73:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:35:1-35:17
    logic [48:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:37:1-37:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:37:1-37:21
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:39:1-39:16
    logic [15:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:71:1-71:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:71:1-71:18
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:73:1-73:18
    logic [15:0] s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:200:21-200:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:200:21-200:33
    logic [15:0] s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:201:21-201:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:201:21-201:33
    logic [15:0] s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:202:21-202:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:202:21-202:33
    logic s8_norm_hw_43_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:203:27-203:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:203:27-203:39
    logic wdata_sel___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:99:3-99:30
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:91:3-91:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:190:3-190:26
    logic [15:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:33:1-33:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:196:3-196:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:41:1-41:13
    logic [15:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:43:1-43:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:43:1-43:18
    logic [15:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:45:1-45:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:145:3-145:37
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:47:1-47:13
    logic [15:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:49:1-49:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:49:1-49:18
    logic [15:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:51:1-51:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:152:3-152:37
    logic wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:53:1-53:13
    logic [15:0] wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:55:1-55:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:55:1-55:18
    logic [15:0] resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:57:1-57:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:159:3-159:37
    logic wen_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:59:1-59:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:59:1-59:15
    logic wdata_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19
    logic resetvalue_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:166:3-166:39
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:65:1-65:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:172:3-172:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:190:3-190:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:33:1-33:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:196:3-196:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:35:1-35:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:37:1-37:21; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:37:1-37:21
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:39:1-39:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:41:1-41:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:43:1-43:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:43:1-43:18
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:45:1-45:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:145:3-145:37
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:47:1-47:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:49:1-49:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:49:1-49:18
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:51:1-51:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:152:3-152:37
    assign wen_c__ = wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:53:1-53:13
    assign wdata_c__ = wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:55:1-55:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:55:1-55:18
    assign resetvalue_c__ = resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:57:1-57:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:159:3-159:37
    assign wen_sel__ = wen_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:59:1-59:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:59:1-59:15
    assign wdata_sel__ = wdata_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19
    assign resetvalue_sel__ = resetvalue_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:166:3-166:39
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:172:3-172:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:71:1-71:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:71:1-71:18
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:73:1-73:18

    assign s8_norm_hw_40_v0 = push_value[15:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:200:21-200:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:200:21-200:33
    assign s8_norm_hw_41_v0 = push_value[31:16]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:201:21-201:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:201:21-201:33
    assign s8_norm_hw_42_v0 = push_value[47:32]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:202:21-202:33; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:202:21-202:33
    assign s8_norm_hw_43_v0 = push_value[48]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:203:27-203:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:203:27-203:39
    assign wdata_sel___v3 = (push__vld & s8_norm_hw_43_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:99:3-99:30
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:91:3-91:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:190:3-190:26
    assign result__query = rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:33:1-33:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:196:3-196:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:41:1-41:13
    assign wdata_a = s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:43:1-43:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:43:1-43:18
    assign resetvalue_a = 16'h8035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:45:1-45:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:145:3-145:37
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:47:1-47:13
    assign wdata_b = s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:49:1-49:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:49:1-49:18
    assign resetvalue_b = 16'h8035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:51:1-51:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:152:3-152:37
    assign wen_c = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:53:1-53:13
    assign wdata_c = s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:55:1-55:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:55:1-55:18
    assign resetvalue_c = 16'h8035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:57:1-57:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:159:3-159:37
    assign wen_sel = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:59:1-59:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:59:1-59:15
    assign wdata_sel = wdata_sel___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:61:1-61:19
    assign resetvalue_sel = 1'h1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:166:3-166:39
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_16/sim/top.logic.cpp:172:3-172:37
endmodule

