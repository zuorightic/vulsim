`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [255:0] result__query__,
  input push__vld__,
  input [512:0] push_value__,
  input [0:0] push_v__
);

reg [127:0] __vul_pipeline_q_a;
wire [127:0] resetvalue_a__;
wire wen_a__;
wire [127:0] wdata_a__;
reg [127:0] __vul_pipeline_q_d;
wire [127:0] resetvalue_d__;
wire wen_d__;
wire [127:0] wdata_d__;
reg [127:0] __vul_pipeline_q_bias;
wire [127:0] resetvalue_bias__;
wire wen_bias__;
wire [127:0] wdata_bias__;
reg [127:0] __vul_pipeline_q_bypass;
wire [127:0] resetvalue_bypass__;
wire wen_bypass__;
wire [127:0] wdata_bypass__;
reg [0:0] __vul_pipeline_q_sel;
wire [0:0] resetvalue_sel__;
wire wen_sel__;
wire [0:0] wdata_sel__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [127:0] __vul_pipeline_q_y;
wire [127:0] __vul_pipeline_d_y;
reg [127:0] __vul_pipeline_q_r;
wire [127:0] __vul_pipeline_d_r;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_d <= resetvalue_d__;
  end else begin
begin
    if (wen_d__) begin
      __vul_pipeline_q_d <= wdata_d__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_bias <= resetvalue_bias__;
  end else begin
begin
    if (wen_bias__) begin
      __vul_pipeline_q_bias <= wdata_bias__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_bypass <= resetvalue_bypass__;
  end else begin
begin
    if (wen_bypass__) begin
      __vul_pipeline_q_bypass <= wdata_bypass__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_sel <= resetvalue_sel__;
  end else begin
begin
    if (wen_sel__) begin
      __vul_pipeline_q_sel <= wdata_sel__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 128'h80000000000000020000000000000034;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_r <= 128'h80000000000000020000000000000035;
  end else begin
  __vul_pipeline_q_r <= __vul_pipeline_d_r;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [127:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic [127:0] __vul_port_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25
    logic [127:0] __vul_port_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:27
    logic __vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic [127:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:71:1-71:52
    logic [127:0] __vul_port_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [127:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic [127:0] vul_port_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25
    logic [127:0] vul_port_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:27
    logic vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic s8_norm_cmp_15_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:43:29-43:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:58:17-58:52
    logic [127:0] s8_norm_mux_16_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:44:32-44:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:57:1-57:26
    logic [127:0] s8_norm_udivmod_17_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:45:31-45:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:45:31-45:49
    logic [127:0] s8_norm_udivmod_18_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:46:31-46:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:46:31-46:49
    logic [127:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:47:27-47:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:57:1-57:26
    logic [127:0] s8_norm_mux_20_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62
    logic [127:0] s8_norm_add_21_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:49:28-49:64; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:49:28-49:64
    logic [127:0] s8_norm_mux_22_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51
    logic [127:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:71:1-71:52
    logic [127:0] vul_port_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19
    logic [127:0] arith_original_17; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:45:31-45:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:45:31-45:49
    logic [127:0] arith_original_18; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:46:31-46:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:46:31-46:49
    logic [127:0] rtlzz_pipe_13_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51
    logic [127:0] rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_d = __vul_pipeline_q_d;
    assign __vul_port_bias = __vul_pipeline_q_bias;
    assign __vul_port_bypass = __vul_pipeline_q_bypass;
    assign __vul_port_sel = __vul_pipeline_q_sel;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_r = __vul_port_r;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    assign vul_port_d = __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    assign vul_port_bias = __vul_port_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:25
    assign vul_port_bypass = __vul_port_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:27
    assign vul_port_sel = __vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:71:1-71:52
    assign __vul_port_r = vul_port_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:38:1-38:19

    assign s8_norm_cmp_15_v0 = (vul_port_d == 128'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:43:29-43:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:58:17-58:52
    assign s8_norm_mux_16_v0 = (s8_norm_cmp_15_v0 ? 128'h1 : vul_port_d); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:44:32-44:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:57:1-57:26
    assign s8_norm_udivmod_17_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_18_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_mux_19_v0 = (s8_norm_cmp_15_v0 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_17_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:47:27-47:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:57:1-57:26
    assign s8_norm_mux_20_v0 = (s8_norm_cmp_15_v0 ? vul_port_a : s8_norm_udivmod_18_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62
    assign s8_norm_add_21_v0 = (s8_norm_mux_19_v0 + vul_port_bias); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:49:28-49:64; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:49:28-49:64
    assign s8_norm_mux_22_v0 = (vul_port_sel ? s8_norm_add_21_v0 : vul_port_bypass); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51
    assign vul_port_y = rtlzz_pipe_13_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:34:1-34:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:71:1-71:52
    assign vul_port_r = rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:36:1-36:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign arith_original_17 = (vul_port_a / s8_norm_mux_16_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:45:31-45:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:45:31-45:49
    assign arith_original_18 = (vul_port_a % s8_norm_mux_16_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:46:31-46:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:46:31-46:49
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_13_s1 <= 128'h80000000000000020000000000000034;
            rtlzz_pipe_11_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_13_s1 <= s8_norm_mux_22_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:50:26-50:51
        end
        if (vul_port_iv) begin
        rtlzz_pipe_11_s1 <= s8_norm_mux_20_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:48:27-48:62
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
        end
    end
end

    logic [127:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:79:1-79:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:79:1-79:19
    logic [127:0] rdata_r__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:81:1-81:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:81:1-81:19
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:83:1-83:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:83:1-83:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:37:1-37:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:37:1-37:17
    logic [512:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:39:1-39:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:39:1-39:22
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:41:1-41:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:41:1-41:16
    logic [127:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:79:1-79:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:79:1-79:19
    logic [127:0] rdata_r; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:81:1-81:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:81:1-81:19
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:83:1-83:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:83:1-83:18
    logic [255:0] s8_norm_hw_46_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:230:3-230:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:230:3-230:9
    logic [127:0] s8_norm_hw_47_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:235:22-235:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:235:22-235:34
    logic [127:0] s8_norm_hw_48_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:236:22-236:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:236:22-236:34
    logic [127:0] s8_norm_hw_49_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:237:25-237:37; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:237:25-237:37
    logic [127:0] s8_norm_hw_50_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:238:27-238:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:238:27-238:39
    logic s8_norm_hw_51_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:239:27-239:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:239:27-239:39
    logic wdata_sel___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:116:3-116:30
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:108:3-108:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:33:1-33:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:224:3-224:26
    logic [255:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:35:1-35:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:231:3-231:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:43:1-43:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:43:1-43:13
    logic [127:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:45:1-45:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:45:1-45:19
    logic [127:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:47:1-47:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:172:3-172:39
    logic wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:49:1-49:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:49:1-49:13
    logic [127:0] wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:51:1-51:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:51:1-51:19
    logic [127:0] resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:53:1-53:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:179:3-179:39
    logic wen_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:55:1-55:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:55:1-55:16
    logic [127:0] wdata_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:57:1-57:22
    logic [127:0] resetvalue_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:59:1-59:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:186:3-186:45
    logic wen_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:61:1-61:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:61:1-61:18
    logic [127:0] wdata_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:63:1-63:24
    logic [127:0] resetvalue_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:65:1-65:29; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:193:3-193:49
    logic wen_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:67:1-67:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:67:1-67:15
    logic wdata_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19
    logic resetvalue_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:71:1-71:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:200:3-200:39
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:73:1-73:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:73:1-73:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:77:1-77:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:206:3-206:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_r__ = __vul_pipeline_q_r;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:33:1-33:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:224:3-224:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:35:1-35:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:231:3-231:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:37:1-37:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:37:1-37:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:39:1-39:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:39:1-39:22
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:41:1-41:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:41:1-41:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:43:1-43:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:43:1-43:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:45:1-45:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:45:1-45:19
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:47:1-47:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:172:3-172:39
    assign wen_d__ = wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:49:1-49:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:49:1-49:13
    assign wdata_d__ = wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:51:1-51:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:51:1-51:19
    assign resetvalue_d__ = resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:53:1-53:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:179:3-179:39
    assign wen_bias__ = wen_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:55:1-55:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:55:1-55:16
    assign wdata_bias__ = wdata_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:57:1-57:22
    assign resetvalue_bias__ = resetvalue_bias; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:59:1-59:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:186:3-186:45
    assign wen_bypass__ = wen_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:61:1-61:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:61:1-61:18
    assign wdata_bypass__ = wdata_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:63:1-63:24
    assign resetvalue_bypass__ = resetvalue_bypass; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:65:1-65:29; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:193:3-193:49
    assign wen_sel__ = wen_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:67:1-67:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:67:1-67:15
    assign wdata_sel__ = wdata_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19
    assign resetvalue_sel__ = resetvalue_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:71:1-71:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:200:3-200:39
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:73:1-73:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:73:1-73:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:77:1-77:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:206:3-206:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:79:1-79:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:79:1-79:19
    assign rdata_r = rdata_r__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:81:1-81:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:81:1-81:19
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:83:1-83:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:83:1-83:18

    assign s8_norm_hw_46_v0 = {rdata_r, rdata_y}; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:230:3-230:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:230:3-230:9
    assign s8_norm_hw_47_v0 = push_value[127:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:235:22-235:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:235:22-235:34
    assign s8_norm_hw_48_v0 = push_value[255:128]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:236:22-236:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:236:22-236:34
    assign s8_norm_hw_49_v0 = push_value[383:256]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:237:25-237:37; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:237:25-237:37
    assign s8_norm_hw_50_v0 = push_value[511:384]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:238:27-238:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:238:27-238:39
    assign s8_norm_hw_51_v0 = push_value[512]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:239:27-239:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:239:27-239:39
    assign wdata_sel___v3 = (push__vld & s8_norm_hw_51_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:116:3-116:30
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:108:3-108:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:33:1-33:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:224:3-224:26
    assign result__query = s8_norm_hw_46_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:35:1-35:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:231:3-231:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:43:1-43:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:43:1-43:13
    assign wdata_a = s8_norm_hw_47_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:45:1-45:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:45:1-45:19
    assign resetvalue_a = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:47:1-47:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:172:3-172:39
    assign wen_d = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:49:1-49:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:49:1-49:13
    assign wdata_d = s8_norm_hw_48_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:51:1-51:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:51:1-51:19
    assign resetvalue_d = 128'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:53:1-53:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:179:3-179:39
    assign wen_bias = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:55:1-55:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:55:1-55:16
    assign wdata_bias = s8_norm_hw_49_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:57:1-57:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:57:1-57:22
    assign resetvalue_bias = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:59:1-59:27; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:186:3-186:45
    assign wen_bypass = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:61:1-61:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:61:1-61:18
    assign wdata_bypass = s8_norm_hw_50_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:63:1-63:24
    assign resetvalue_bypass = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:65:1-65:29; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:193:3-193:49
    assign wen_sel = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:67:1-67:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:67:1-67:15
    assign wdata_sel = wdata_sel___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:69:1-69:19
    assign resetvalue_sel = 1'h1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:71:1-71:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:200:3-200:39
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:73:1-73:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:73:1-73:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:75:1-75:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:77:1-77:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/DIVSEL_128/sim/top.logic.cpp:206:3-206:37
endmodule

