`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [127:0] result__query__,
  input push__vld__,
  input [384:0] push_value__,
  input [0:0] push_v__
);

reg [127:0] __vul_pipeline_q_a;
wire [127:0] resetvalue_a__;
wire wen_a__;
wire [127:0] wdata_a__;
reg [127:0] __vul_pipeline_q_b;
wire [127:0] resetvalue_b__;
wire wen_b__;
wire [127:0] wdata_b__;
reg [127:0] __vul_pipeline_q_c;
wire [127:0] resetvalue_c__;
wire wen_c__;
wire [127:0] wdata_c__;
reg [0:0] __vul_pipeline_q_sel;
wire [0:0] resetvalue_sel__;
wire wen_sel__;
wire [0:0] wdata_sel__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [127:0] __vul_pipeline_q_y;
wire [127:0] __vul_pipeline_d_y;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_b <= resetvalue_b__;
  end else begin
begin
    if (wen_b__) begin
      __vul_pipeline_q_b <= wdata_b__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_c <= resetvalue_c__;
  end else begin
begin
    if (wen_c__) begin
      __vul_pipeline_q_c <= wdata_c__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_sel <= resetvalue_sel__;
  end else begin
begin
    if (wen_sel__) begin
      __vul_pipeline_q_sel <= wdata_sel__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_y <= 128'h80000000000000d60000000000000b2e;
  end else begin
  __vul_pipeline_q_y <= __vul_pipeline_d_y;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [127:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22
    logic [127:0] __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic __vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [127:0] __vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:52
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [127:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22
    logic [127:0] vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    logic [127:0] vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    logic vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    logic [127:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
    logic [127:0] s8_norm_mul_10_v0; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:42:17-42:52
    logic [127:0] s8_norm_add_12_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:37:23-37:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:37:23-37:65
    logic [127:0] vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:52
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19
    logic [127:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:42:17-42:52
    logic [31:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [159:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [223:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [255:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [160:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [224:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [256:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [161:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [225:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [257:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [258:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [259:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
    logic [63:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [159:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [223:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [255:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_b = __vul_pipeline_q_b;
    assign __vul_port_c = __vul_pipeline_q_c;
    assign __vul_port_sel = __vul_pipeline_q_sel;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_y = __vul_port_y;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:20:1-20:22
    assign vul_port_b = __vul_port_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:22:1-22:22
    assign vul_port_c = __vul_port_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:24:1-24:22
    assign vul_port_sel = __vul_port_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:26:1-26:22
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
    assign __vul_port_y = vul_port_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:52
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:32:1-32:19

    assign s8_norm_mux_9_v0 = (vul_port_sel ? vul_port_c : 128'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
    assign s8_norm_mul_10_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_12_v0 = (s8_norm_mul_10_v0 + rtlzz_pipe_5_s1); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:37:23-37:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:37:23-37:65
    assign vul_port_y = s8_norm_add_12_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:30:1-30:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:54:1-54:52
    assign vul_port_ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = vul_port_a[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = vul_port_b[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 64'(($unsigned(64'($unsigned(mul_tree_10_11))) * $unsigned(64'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = vul_port_a[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = vul_port_b[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 64'(($unsigned(64'($unsigned(mul_tree_10_14))) * $unsigned(64'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = vul_port_a[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = vul_port_b[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 64'(($unsigned(64'($unsigned(mul_tree_10_18))) * $unsigned(64'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = vul_port_a[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = vul_port_b[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 64'(($unsigned(64'($unsigned(mul_tree_10_22))) * $unsigned(64'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = vul_port_a[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = vul_port_b[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 64'(($unsigned(64'($unsigned(mul_tree_10_26))) * $unsigned(64'($unsigned(mul_tree_10_27))))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = {mul_tree_10_28, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = vul_port_a[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = vul_port_b[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_32 = 64'(($unsigned(64'($unsigned(mul_tree_10_30))) * $unsigned(64'($unsigned(mul_tree_10_31))))); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = {mul_tree_10_32, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = vul_port_a[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = vul_port_b[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = 64'(($unsigned(64'($unsigned(mul_tree_10_34))) * $unsigned(64'($unsigned(mul_tree_10_35))))); // decl: <none>; prim: <none>
    assign mul_tree_10_37 = {mul_tree_10_36, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = vul_port_a[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = vul_port_b[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = 64'(($unsigned(64'($unsigned(mul_tree_10_38))) * $unsigned(64'($unsigned(mul_tree_10_39))))); // decl: <none>; prim: <none>
    assign mul_tree_10_41 = {mul_tree_10_40, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = vul_port_a[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = vul_port_b[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = 64'(($unsigned(64'($unsigned(mul_tree_10_42))) * $unsigned(64'($unsigned(mul_tree_10_43))))); // decl: <none>; prim: <none>
    assign mul_tree_10_45 = {mul_tree_10_44, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = vul_port_a[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = vul_port_b[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = 64'(($unsigned(64'($unsigned(mul_tree_10_46))) * $unsigned(64'($unsigned(mul_tree_10_47))))); // decl: <none>; prim: <none>
    assign mul_tree_10_49 = {mul_tree_10_48, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = vul_port_a[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = vul_port_b[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_52 = 64'(($unsigned(64'($unsigned(mul_tree_10_50))) * $unsigned(64'($unsigned(mul_tree_10_51))))); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = {mul_tree_10_52, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = vul_port_a[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = vul_port_b[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 64'(($unsigned(64'($unsigned(mul_tree_10_54))) * $unsigned(64'($unsigned(mul_tree_10_55))))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = {mul_tree_10_56, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = vul_port_a[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = vul_port_b[31:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_60 = 64'(($unsigned(64'($unsigned(mul_tree_10_58))) * $unsigned(64'($unsigned(mul_tree_10_59))))); // decl: <none>; prim: <none>
    assign mul_tree_10_61 = {mul_tree_10_60, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = vul_port_a[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = vul_port_b[63:32]; // decl: <none>; prim: <none>
    assign mul_tree_10_64 = 64'(($unsigned(64'($unsigned(mul_tree_10_62))) * $unsigned(64'($unsigned(mul_tree_10_63))))); // decl: <none>; prim: <none>
    assign mul_tree_10_65 = {mul_tree_10_64, 128'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = vul_port_a[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = vul_port_b[95:64]; // decl: <none>; prim: <none>
    assign mul_tree_10_68 = 64'(($unsigned(64'($unsigned(mul_tree_10_66))) * $unsigned(64'($unsigned(mul_tree_10_67))))); // decl: <none>; prim: <none>
    assign mul_tree_10_69 = {mul_tree_10_68, 160'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = vul_port_a[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = vul_port_b[127:96]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = 64'(($unsigned(64'($unsigned(mul_tree_10_70))) * $unsigned(64'($unsigned(mul_tree_10_71))))); // decl: <none>; prim: <none>
    assign mul_tree_10_73 = {mul_tree_10_72, 192'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({33'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 97'((mul_tree_10_74 + mul_tree_10_75 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = ({33'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_79 = 161'((mul_tree_10_77 + mul_tree_10_78 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_80 = ({33'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_82 = 129'((mul_tree_10_80 + mul_tree_10_81 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_83 = ({33'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = 193'((mul_tree_10_83 + mul_tree_10_84 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_86 = ({33'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 161'((mul_tree_10_86 + mul_tree_10_87 + ({160'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = ({33'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_91 = 225'((mul_tree_10_89 + mul_tree_10_90 + ({224'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_92 = ({33'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_94 = 193'((mul_tree_10_92 + mul_tree_10_93 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_95 = ({33'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = 257'((mul_tree_10_95 + mul_tree_10_96 + ({256'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_98 = ({65'h0, mul_tree_10_76}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, mul_tree_10_79}); // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 162'((mul_tree_10_98 + mul_tree_10_99 + ({161'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({65'h0, mul_tree_10_82}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, mul_tree_10_85}); // decl: <none>; prim: <none>
    assign mul_tree_10_103 = 194'((mul_tree_10_101 + mul_tree_10_102 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({65'h0, mul_tree_10_88}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, mul_tree_10_91}); // decl: <none>; prim: <none>
    assign mul_tree_10_106 = 226'((mul_tree_10_104 + mul_tree_10_105 + ({225'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({65'h0, mul_tree_10_94}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, mul_tree_10_97}); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = 258'((mul_tree_10_107 + mul_tree_10_108 + ({257'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({33'h0, mul_tree_10_100}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, mul_tree_10_103}); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = 195'((mul_tree_10_110 + mul_tree_10_111 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({33'h0, mul_tree_10_106}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = 259'((mul_tree_10_113 + mul_tree_10_114 + ({258'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({65'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = 260'((mul_tree_10_116 + mul_tree_10_117 + ({259'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_tree_10_118[127:0]; // decl: <none>; prim: <none>
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_5_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_pipe_13_s1 <= 64'haf9;
            rtlzz_pipe_17_s1 <= 96'h0;
            rtlzz_pipe_21_s1 <= 128'h6a0000000000000000;
            rtlzz_pipe_25_s1 <= 160'h1a80000000000000000000000000000000;
            rtlzz_pipe_29_s1 <= 96'h0;
            rtlzz_pipe_33_s1 <= 128'h0;
            rtlzz_pipe_37_s1 <= 160'h0;
            rtlzz_pipe_41_s1 <= 192'h0;
            rtlzz_pipe_45_s1 <= 128'h6a0000000000000000;
            rtlzz_pipe_49_s1 <= 160'h0;
            rtlzz_pipe_53_s1 <= 192'h400000000000000000000000000000000;
            rtlzz_pipe_57_s1 <= 224'h1000000000000000000000000000000000000000000000000;
            rtlzz_pipe_61_s1 <= 160'h1a80000000000000000000000000000000;
            rtlzz_pipe_65_s1 <= 192'h0;
            rtlzz_pipe_69_s1 <= 224'h1000000000000000000000000000000000000000000000000;
            rtlzz_pipe_73_s1 <= 256'h4000000000000000000000000000000000000000000000000000000000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:35:28-35:44; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:48:28-48:42
        end
        if (vul_port_iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (vul_port_iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp.pipeline_core.cpp:28:1-28:19
        end
    end
end

    logic [127:0] rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:71:1-71:19
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:73:1-73:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:35:1-35:17
    logic [384:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:37:1-37:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:37:1-37:22
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:39:1-39:16
    logic [127:0] rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:71:1-71:19
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:73:1-73:18
    logic [127:0] s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:200:22-200:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:200:22-200:34
    logic [127:0] s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:201:22-201:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:201:22-201:34
    logic [127:0] s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:202:22-202:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:202:22-202:34
    logic s8_norm_hw_43_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:203:27-203:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:203:27-203:39
    logic wdata_sel___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:99:3-99:30
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:91:3-91:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:190:3-190:26
    logic [127:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:196:3-196:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:41:1-41:13
    logic [127:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:43:1-43:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:43:1-43:19
    logic [127:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:45:1-45:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:145:3-145:39
    logic wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:47:1-47:13
    logic [127:0] wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:49:1-49:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:49:1-49:19
    logic [127:0] resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:51:1-51:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:152:3-152:39
    logic wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:53:1-53:13
    logic [127:0] wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:55:1-55:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:55:1-55:19
    logic [127:0] resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:57:1-57:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:159:3-159:39
    logic wen_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:59:1-59:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:59:1-59:15
    logic wdata_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19
    logic resetvalue_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:166:3-166:39
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:65:1-65:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:172:3-172:37

    assign rdata_y__ = __vul_pipeline_q_y;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:190:3-190:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:196:3-196:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:35:1-35:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:35:1-35:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:37:1-37:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:37:1-37:22
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:39:1-39:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:39:1-39:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:41:1-41:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:43:1-43:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:43:1-43:19
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:45:1-45:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:145:3-145:39
    assign wen_b__ = wen_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:47:1-47:13
    assign wdata_b__ = wdata_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:49:1-49:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:49:1-49:19
    assign resetvalue_b__ = resetvalue_b; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:51:1-51:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:152:3-152:39
    assign wen_c__ = wen_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:53:1-53:13
    assign wdata_c__ = wdata_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:55:1-55:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:55:1-55:19
    assign resetvalue_c__ = resetvalue_c; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:57:1-57:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:159:3-159:39
    assign wen_sel__ = wen_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:59:1-59:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:59:1-59:15
    assign wdata_sel__ = wdata_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19
    assign resetvalue_sel__ = resetvalue_sel; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:166:3-166:39
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:172:3-172:37
    assign rdata_y = rdata_y__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:71:1-71:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:71:1-71:19
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:73:1-73:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:73:1-73:18

    assign s8_norm_hw_40_v0 = push_value[127:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:200:22-200:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:200:22-200:34
    assign s8_norm_hw_41_v0 = push_value[255:128]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:201:22-201:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:201:22-201:34
    assign s8_norm_hw_42_v0 = push_value[383:256]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:202:22-202:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:202:22-202:34
    assign s8_norm_hw_43_v0 = push_value[384]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:203:27-203:39; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:203:27-203:39
    assign wdata_sel___v3 = (push__vld & s8_norm_hw_43_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:99:3-99:30
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:91:3-91:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:31:1-31:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:190:3-190:26
    assign result__query = rdata_y; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:33:1-33:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:196:3-196:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:41:1-41:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:41:1-41:13
    assign wdata_a = s8_norm_hw_40_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:43:1-43:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:43:1-43:19
    assign resetvalue_a = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:45:1-45:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:145:3-145:39
    assign wen_b = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:47:1-47:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:47:1-47:13
    assign wdata_b = s8_norm_hw_41_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:49:1-49:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:49:1-49:19
    assign resetvalue_b = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:51:1-51:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:152:3-152:39
    assign wen_c = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:53:1-53:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:53:1-53:13
    assign wdata_c = s8_norm_hw_42_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:55:1-55:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:55:1-55:19
    assign resetvalue_c = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:57:1-57:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:159:3-159:39
    assign wen_sel = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:59:1-59:15; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:59:1-59:15
    assign wdata_sel = wdata_sel___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:61:1-61:19
    assign resetvalue_sel = 1'h1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:63:1-63:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:166:3-166:39
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:65:1-65:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:65:1-65:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:67:1-67:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:69:1-69:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_M_128/sim/top.logic.cpp:172:3-172:37
endmodule

