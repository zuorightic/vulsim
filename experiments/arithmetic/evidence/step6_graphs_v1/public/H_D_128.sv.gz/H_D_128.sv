`timescale 1ns/1ps

module Top_sim_top(
  input clk,
  input rstn,
  output [0:0] valid__query__,
  output [383:0] result__query__,
  input push__vld__,
  input [383:0] push_value__,
  input [0:0] push_v__
);

reg [127:0] __vul_pipeline_q_a;
wire [127:0] resetvalue_a__;
wire wen_a__;
wire [127:0] wdata_a__;
reg [127:0] __vul_pipeline_q_d;
wire [127:0] resetvalue_d__;
wire wen_d__;
wire [127:0] wdata_d__;
reg [127:0] __vul_pipeline_q_e;
wire [127:0] resetvalue_e__;
wire wen_e__;
wire [127:0] wdata_e__;
reg [0:0] __vul_pipeline_q_iv = 1'b0;
wire [0:0] resetvalue_iv__;
wire wen_iv__;
wire [0:0] wdata_iv__;
reg [127:0] __vul_pipeline_q_q;
wire [127:0] __vul_pipeline_d_q;
reg [127:0] __vul_pipeline_q_r1;
wire [127:0] __vul_pipeline_d_r1;
reg [127:0] __vul_pipeline_q_r2;
wire [127:0] __vul_pipeline_d_r2;
reg [0:0] __vul_pipeline_q_ov = 1'b0;
wire [0:0] __vul_pipeline_d_ov;

always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_a <= resetvalue_a__;
  end else begin
begin
    if (wen_a__) begin
      __vul_pipeline_q_a <= wdata_a__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_d <= resetvalue_d__;
  end else begin
begin
    if (wen_d__) begin
      __vul_pipeline_q_d <= wdata_d__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_e <= resetvalue_e__;
  end else begin
begin
    if (wen_e__) begin
      __vul_pipeline_q_e <= wdata_e__;
    end
    end
  end
end
always @(posedge clk) begin
  if (rstn == 0) begin
    __vul_pipeline_q_iv <= resetvalue_iv__;
  end else begin
begin
    if (wen_iv__) begin
      __vul_pipeline_q_iv <= wdata_iv__;
    end
    end
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_q <= 128'hffffffffffffffffffffffffffffffff;
  end else begin
  __vul_pipeline_q_q <= __vul_pipeline_d_q;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_r1 <= 128'h80000000000000020000000000000035;
  end else begin
  __vul_pipeline_q_r1 <= __vul_pipeline_d_r1;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_r2 <= 128'hffffffffffffffffffffffffffffffff;
  end else begin
  __vul_pipeline_q_r2 <= __vul_pipeline_d_r2;
  end
end
always @(posedge clk) begin
  if (!rstn) begin
    __vul_pipeline_q_ov <= 1'h0;
  end else begin
  __vul_pipeline_q_ov <= __vul_pipeline_d_ov;
  end
end

if (1) begin : __vul_pipeline_core
    logic [127:0] __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22
    logic [127:0] __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:22
    logic [127:0] __vul_port_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:22
    logic __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19
    logic [127:0] __vul_port_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    logic [127:0] __vul_port_r1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:31:1-31:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:75:1-75:54
    logic [127:0] __vul_port_r2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:33:1-33:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:77:1-77:54
    logic __vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:35:1-35:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:35:1-35:19
    logic __vul_pipeline_rstn; // decl: <none>; prim: <none>
    logic __vul_pipeline_clk; // decl: <none>; prim: <none>

    logic [127:0] vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22
    logic [127:0] vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:22
    logic [127:0] vul_port_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:22
    logic vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19
    logic s8_norm_cmp_17_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:43:29-43:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:63:17-63:52
    logic s8_norm_cmp_18_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:44:30-44:48; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:65:17-65:52
    logic [127:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:45:32-45:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
    logic [127:0] s8_norm_mux_20_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:46:33-46:68; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
    logic [127:0] s8_norm_udivmod_21_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:49
    logic [127:0] s8_norm_udivmod_22_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:48:31-48:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:48:31-48:49
    logic [127:0] s8_norm_mux_23_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:49:27-49:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
    logic [127:0] s8_norm_mux_24_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62
    logic [127:0] s8_norm_udivmod_25_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:51:32-51:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:51:32-51:59
    logic [127:0] s8_norm_udivmod_26_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:52:32-52:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:52:32-52:59
    logic [127:0] s8_norm_mux_27_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:53:28-53:77; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
    logic [127:0] s8_norm_mux_28_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:54:28-54:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:54:28-54:73
    logic [127:0] vul_port_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    logic [127:0] vul_port_r1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:31:1-31:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:75:1-75:54
    logic [127:0] vul_port_r2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:33:1-33:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:77:1-77:54
    logic vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:35:1-35:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:35:1-35:19
    logic [127:0] arith_original_20; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:49
    logic [127:0] arith_original_21; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:48:31-48:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:48:31-48:49
    logic [127:0] arith_original_22; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:51:32-51:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:51:32-51:59
    logic [127:0] arith_original_23; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:52:32-52:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:52:32-52:59
    logic [127:0] rtlzz_pipe_0_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22
    logic rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:43:29-43:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:63:17-63:52
    logic rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:44:30-44:48; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:65:17-65:52
    logic rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:44:30-44:48; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:65:17-65:52
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:45:32-45:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:46:33-46:68; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:46:33-46:68; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
    logic [127:0] rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:49:27-49:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
    logic [127:0] rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19

    assign __vul_port_a = __vul_pipeline_q_a;
    assign __vul_port_d = __vul_pipeline_q_d;
    assign __vul_port_e = __vul_pipeline_q_e;
    assign __vul_port_iv = __vul_pipeline_q_iv;
    assign __vul_pipeline_d_q = __vul_port_q;
    assign __vul_pipeline_d_r1 = __vul_port_r1;
    assign __vul_pipeline_d_r2 = __vul_port_r2;
    assign __vul_pipeline_d_ov = __vul_port_ov;
    assign __vul_pipeline_rstn = rstn;
    assign __vul_pipeline_clk = clk;

    assign vul_port_a = __vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22
    assign vul_port_d = __vul_port_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:23:1-23:22
    assign vul_port_e = __vul_port_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:25:1-25:22
    assign vul_port_iv = __vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19
    assign __vul_port_q = vul_port_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    assign __vul_port_r1 = vul_port_r1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:31:1-31:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:75:1-75:54
    assign __vul_port_r2 = vul_port_r2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:33:1-33:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:77:1-77:54
    assign __vul_port_ov = vul_port_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:35:1-35:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:35:1-35:19

    assign s8_norm_cmp_17_v0 = (vul_port_d == 128'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:43:29-43:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:63:17-63:52
    assign s8_norm_cmp_18_v0 = (vul_port_e == 128'h0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:44:30-44:48; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:65:17-65:52
    assign s8_norm_mux_19_v0 = (s8_norm_cmp_17_v0 ? 128'h1 : vul_port_d); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:45:32-45:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
    assign s8_norm_mux_20_v0 = (s8_norm_cmp_18_v0 ? 128'h1 : vul_port_e); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:46:33-46:68; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
    assign s8_norm_udivmod_21_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_22_v0 = arith_original_21; // decl: <none>; prim: <none>
    assign s8_norm_mux_23_v0 = (rtlzz_pipe_4_s1 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_21_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:49:27-49:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
    assign s8_norm_mux_24_v0 = (rtlzz_pipe_4_s1 ? rtlzz_pipe_0_s1 : s8_norm_udivmod_22_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62
    assign s8_norm_udivmod_25_v0 = arith_original_22; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_26_v0 = arith_original_23; // decl: <none>; prim: <none>
    assign s8_norm_mux_27_v0 = (rtlzz_pipe_5_s2 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_25_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:53:28-53:77; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
    assign s8_norm_mux_28_v0 = (rtlzz_pipe_5_s2 ? rtlzz_pipe_10_s2 : s8_norm_udivmod_26_v0); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:54:28-54:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:54:28-54:73
    assign vul_port_q = s8_norm_mux_27_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:29:1-29:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:73:1-73:52
    assign vul_port_r1 = rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:31:1-31:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:75:1-75:54
    assign vul_port_r2 = s8_norm_mux_28_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:33:1-33:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:77:1-77:54
    assign vul_port_ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign arith_original_20 = (rtlzz_pipe_0_s1 / rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:47:31-47:49
    assign arith_original_21 = (rtlzz_pipe_0_s1 % rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:48:31-48:49; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:48:31-48:49
    assign arith_original_22 = (rtlzz_pipe_10_s2 / rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:51:32-51:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:51:32-51:59
    assign arith_original_23 = (rtlzz_pipe_10_s2 % rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:52:32-52:59; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:52:32-52:59
    always_ff @(posedge __vul_pipeline_clk) begin
        if (!__vul_pipeline_rstn) begin
            rtlzz_pipe_0_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_pipe_4_s1 <= 1'h1;
            rtlzz_pipe_5_s1 <= 1'h1;
            rtlzz_pipe_5_s2 <= 1'h1;
            rtlzz_pipe_6_s1 <= 128'h1;
            rtlzz_pipe_7_s1 <= 128'h1;
            rtlzz_pipe_7_s2 <= 128'h1;
            rtlzz_pipe_10_s2 <= 128'hffffffffffffffffffffffffffffffff;
            rtlzz_pipe_11_s2 <= 128'h80000000000000020000000000000035;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (vul_port_iv) begin
        rtlzz_pipe_0_s1 <= vul_port_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:21:1-21:22
        end
        if (vul_port_iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_cmp_17_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:43:29-43:46; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:63:17-63:52
        end
        if (vul_port_iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_cmp_18_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:44:30-44:48; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:65:17-65:52
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:44:30-44:48; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:65:17-65:52
        end
        if (vul_port_iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:45:32-45:65; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
        end
        if (vul_port_iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_mux_20_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:46:33-46:68; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:46:33-46:68; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:64:1-64:26
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= s8_norm_mux_23_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:49:27-49:73; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:62:1-62:26
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= s8_norm_mux_24_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:50:27-50:62
        end
        rtlzz_valid_s1 <= vul_port_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp.pipeline_core.cpp:27:1-27:19
        end
    end
end

    logic [127:0] rdata_q__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:66:1-66:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:66:1-66:19
    logic [127:0] rdata_r1__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:68:1-68:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:68:1-68:20
    logic [127:0] rdata_r2__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:70:1-70:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:70:1-70:20
    logic rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:72:1-72:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:72:1-72:18

    logic push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:36:1-36:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:36:1-36:17
    logic [383:0] push_value; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:38:1-38:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:38:1-38:22
    logic push_v; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:40:1-40:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:40:1-40:16
    logic [127:0] rdata_q; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:66:1-66:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:66:1-66:19
    logic [127:0] rdata_r1; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:68:1-68:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:68:1-68:20
    logic [127:0] rdata_r2; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:70:1-70:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:70:1-70:20
    logic rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:72:1-72:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:72:1-72:18
    logic [383:0] s8_norm_hw_34_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:193:3-193:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:193:3-193:9
    logic [127:0] s8_norm_hw_35_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:198:22-198:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:198:22-198:34
    logic [127:0] s8_norm_hw_36_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:199:22-199:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:199:22-199:34
    logic [127:0] s8_norm_hw_37_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:200:22-200:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:200:22-200:34
    logic wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:104:3-104:30
    logic valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:32:1-32:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:186:3-186:26
    logic [383:0] result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:34:1-34:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:194:3-194:27
    logic wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:42:1-42:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:42:1-42:13
    logic [127:0] wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:44:1-44:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:44:1-44:19
    logic [127:0] resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:46:1-46:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:148:3-148:39
    logic wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:48:1-48:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:48:1-48:13
    logic [127:0] wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:50:1-50:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:50:1-50:19
    logic [127:0] resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:52:1-52:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:155:3-155:39
    logic wen_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:54:1-54:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:54:1-54:13
    logic [127:0] wdata_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:56:1-56:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:56:1-56:19
    logic [127:0] resetvalue_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:58:1-58:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:162:3-162:39
    logic wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:60:1-60:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:60:1-60:14
    logic wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18
    logic resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:64:1-64:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:168:3-168:37

    assign rdata_q__ = __vul_pipeline_q_q;
    assign rdata_r1__ = __vul_pipeline_q_r1;
    assign rdata_r2__ = __vul_pipeline_q_r2;
    assign rdata_ov__ = __vul_pipeline_q_ov;

    assign valid__query__ = valid__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:32:1-32:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:186:3-186:26
    assign result__query__ = result__query; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:34:1-34:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:194:3-194:27
    assign push__vld = push__vld__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:36:1-36:17; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:36:1-36:17
    assign push_value = push_value__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:38:1-38:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:38:1-38:22
    assign push_v = push_v__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:40:1-40:16; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:40:1-40:16
    assign wen_a__ = wen_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:42:1-42:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:42:1-42:13
    assign wdata_a__ = wdata_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:44:1-44:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:44:1-44:19
    assign resetvalue_a__ = resetvalue_a; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:46:1-46:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:148:3-148:39
    assign wen_d__ = wen_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:48:1-48:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:48:1-48:13
    assign wdata_d__ = wdata_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:50:1-50:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:50:1-50:19
    assign resetvalue_d__ = resetvalue_d; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:52:1-52:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:155:3-155:39
    assign wen_e__ = wen_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:54:1-54:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:54:1-54:13
    assign wdata_e__ = wdata_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:56:1-56:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:56:1-56:19
    assign resetvalue_e__ = resetvalue_e; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:58:1-58:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:162:3-162:39
    assign wen_iv__ = wen_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:60:1-60:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:60:1-60:14
    assign wdata_iv__ = wdata_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18
    assign resetvalue_iv__ = resetvalue_iv; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:64:1-64:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:168:3-168:37
    assign rdata_q = rdata_q__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:66:1-66:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:66:1-66:19
    assign rdata_r1 = rdata_r1__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:68:1-68:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:68:1-68:20
    assign rdata_r2 = rdata_r2__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:70:1-70:20; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:70:1-70:20
    assign rdata_ov = rdata_ov__; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:72:1-72:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:72:1-72:18

    assign s8_norm_hw_34_v0 = {rdata_r2, rdata_r1, rdata_q}; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:193:3-193:9; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:193:3-193:9
    assign s8_norm_hw_35_v0 = push_value[127:0]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:198:22-198:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:198:22-198:34
    assign s8_norm_hw_36_v0 = push_value[255:128]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:199:22-199:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:199:22-199:34
    assign s8_norm_hw_37_v0 = push_value[383:256]; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:200:22-200:34; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:200:22-200:34
    assign wdata_iv___v3 = (push__vld & push_v); // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:104:3-104:30
    assign valid__query = rdata_ov; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:32:1-32:22; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:186:3-186:26
    assign result__query = s8_norm_hw_34_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:34:1-34:25; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:194:3-194:27
    assign wen_a = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:42:1-42:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:42:1-42:13
    assign wdata_a = s8_norm_hw_35_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:44:1-44:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:44:1-44:19
    assign resetvalue_a = 128'h80000000000000020000000000000035; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:46:1-46:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:148:3-148:39
    assign wen_d = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:48:1-48:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:48:1-48:13
    assign wdata_d = s8_norm_hw_36_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:50:1-50:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:50:1-50:19
    assign resetvalue_d = 128'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:52:1-52:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:155:3-155:39
    assign wen_e = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:54:1-54:13; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:54:1-54:13
    assign wdata_e = s8_norm_hw_37_v0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:56:1-56:19; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:56:1-56:19
    assign resetvalue_e = 128'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:58:1-58:24; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:162:3-162:39
    assign wen_iv = push__vld; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:60:1-60:14; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:60:1-60:14
    assign wdata_iv = wdata_iv___v3; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:62:1-62:18
    assign resetvalue_iv = 1'h0; // decl: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:64:1-64:23; prim: /home/zyrv/vulsim/build/step6-integration-20261031/public-remaining/H_D_128/sim/top.logic.cpp:168:3-168:37
endmodule

