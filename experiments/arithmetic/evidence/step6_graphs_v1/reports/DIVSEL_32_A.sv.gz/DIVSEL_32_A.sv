`timescale 1ns/1ps

module DIVSEL_32_A(
    input logic iv, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:4:1-4:11
    input logic [31:0] a, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:7:1-7:10
    input logic [31:0] d, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:9:1-9:10
    input logic [31:0] bias, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:11:1-11:13; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:11:1-11:13
    input logic [31:0] bypass, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:13:1-13:15; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:13:1-13:15
    input logic sel, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:15:1-15:9
    output logic [31:0] y, // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:33:5-33:17
    output logic [31:0] r // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:34:5-34:18
);

    logic s8_norm_cmp_3_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:24:28-24:41
    logic [31:0] s8_norm_mux_4_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:26:31-26:64; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:24:5-24:42
    logic [31:0] s8_norm_udivmod_5_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:27:30-27:48
    logic [31:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:28:30-28:48; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:28:30-28:48
    logic [31:0] s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:29:26-29:72; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:24:5-24:42
    logic [31:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:30:26-30:61; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:30:26-30:61
    logic [31:0] s8_norm_add_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:31:27-31:61; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:31:27-31:61
    logic [31:0] s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:32:25-32:50; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:32:25-32:50
    logic [31:0] arith_original_17; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:27:30-27:48
    logic [31:0] arith_original_18; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:28:30-28:48; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:28:30-28:48


    assign s8_norm_cmp_3_v0 = (d == 32'h0); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:24:28-24:41
    assign s8_norm_mux_4_v0 = (s8_norm_cmp_3_v0 ? 32'h1 : d); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:26:31-26:64; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:24:5-24:42
    assign s8_norm_udivmod_5_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_6_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_mux_7_v0 = (s8_norm_cmp_3_v0 ? 32'hffffffff : s8_norm_udivmod_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:29:26-29:72; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:24:5-24:42
    assign s8_norm_mux_8_v0 = (s8_norm_cmp_3_v0 ? a : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:30:26-30:61; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:30:26-30:61
    assign s8_norm_add_9_v0 = (s8_norm_mux_7_v0 + bias); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:31:27-31:61; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:31:27-31:61
    assign s8_norm_mux_10_v0 = (sel ? s8_norm_add_9_v0 : bypass); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:32:25-32:50; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:32:25-32:50
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:33:5-33:17
    assign r = s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:34:5-34:18
    assign arith_original_17 = (a / s8_norm_mux_4_v0); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:27:30-27:48
    assign arith_original_18 = (a % s8_norm_mux_4_v0); // decl: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:28:30-28:48; prim: /home/zyrv/vulsim/DIVSEL_32_A.logic.cpp:28:30-28:48
endmodule
