`timescale 1ns/1ps

module DIVSEL_8_B(
    input logic iv, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:7:1-7:9
    input logic [7:0] d, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:9:1-9:9
    input logic [7:0] bias, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:11:1-11:12; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:11:1-11:12
    input logic [7:0] bypass, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:13:1-13:14; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:13:1-13:14
    input logic sel, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:15:1-15:9
    output logic [7:0] y, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:17:1-17:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:33:5-33:17
    output logic [7:0] r, // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:19:1-19:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:34:5-34:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:27-24:39
    logic [7:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:26:30-26:63; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:5-24:40
    logic [7:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47
    logic [7:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47
    logic [7:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:29:25-29:71; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:5-24:40
    logic [7:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:30:25-30:60; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:30:25-30:60
    logic [7:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:31:26-31:58; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:31:26-31:58
    logic [7:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:32:24-32:49; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:32:24-32:49
    logic [7:0] arith_original_17; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47
    logic [7:0] arith_original_18; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47
    logic [7:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:7:1-7:9
    logic [7:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:11:1-11:12; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:11:1-11:12
    logic [7:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:13:1-13:14; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:13:1-13:14
    logic rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:15:1-15:9
    logic rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:27-24:39
    logic [7:0] rtlzz_pipe_8_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47
    logic [7:0] rtlzz_pipe_9_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:8


    assign s8_norm_cmp_4_v0 = (d == 8'h0); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:27-24:39
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 8'h1 : d); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:26:30-26:63; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:5-24:40
    assign s8_norm_udivmod_6_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (rtlzz_pipe_6_s1 ? 8'hff : rtlzz_pipe_8_s1); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:29:25-29:71; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:5-24:40
    assign s8_norm_mux_9_v0 = (rtlzz_pipe_6_s1 ? rtlzz_pipe_1_s1 : rtlzz_pipe_9_s1); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:30:25-30:60; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:30:25-30:60
    assign s8_norm_add_10_v0 = (s8_norm_mux_8_v0 + rtlzz_pipe_3_s1); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:31:26-31:58; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:31:26-31:58
    assign s8_norm_mux_11_v0 = (rtlzz_pipe_5_s1 ? s8_norm_add_10_v0 : rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:32:24-32:49; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:32:24-32:49
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:17:1-17:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:33:5-33:17
    assign r = s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:19:1-19:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:34:5-34:18
    assign arith_original_17 = (a / s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47
    assign arith_original_18 = (a % s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 8'hb5;
            rtlzz_pipe_3_s1 <= 8'hb5;
            rtlzz_pipe_4_s1 <= 8'hb5;
            rtlzz_pipe_5_s1 <= 1'h1;
            rtlzz_pipe_6_s1 <= 1'h1;
            rtlzz_pipe_8_s1 <= 8'hb5;
            rtlzz_pipe_9_s1 <= 8'h0;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:7:1-7:9
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= bias; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:11:1-11:12; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:11:1-11:12
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= bypass; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:13:1-13:14; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:13:1-13:14
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= sel; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:15:1-15:9
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:24:27-24:39
        end
        if (iv) begin
        rtlzz_pipe_8_s1 <= s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:27:29-27:47
        end
        if (iv) begin
        rtlzz_pipe_9_s1 <= s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:28:29-28:47
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_8_B.logic.cpp:4:1-4:8
        end
    end
endmodule
