`timescale 1ns/1ps

module MIX_8_A(
    input logic iv, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:7:1-7:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:9:1-9:9
    input logic [7:0] mask, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:11:1-11:12; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:11:1-11:12
    input logic [7:0] d, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:13:1-13:9
    input logic [4:0] s, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:15:1-15:9
    output logic [7:0] y, // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:17:1-17:9; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:46:5-46:17
    output logic less // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:47:5-47:18
);

    logic s8_norm_cmp_7_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:22:22-22:34
    logic [7:0] s8_norm_bitnot_8_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:29:29-29:34; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:29:29-29:34
    logic s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:30:20-30:25
    logic s8_norm_cmp_10_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:25:25-25:37
    logic [7:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:32:19-32:40; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:32:19-32:40
    logic [7:0] s8_norm_sub_12_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:33:19-33:40; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:33:19-33:40
    logic [7:0] s8_norm_mux_13_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:34:28-34:57; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:25:5-25:38
    logic [7:0] s8_norm_udivmod_15_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:36:27-36:43; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:36:27-36:43
    logic [7:0] s8_norm_shift_17_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:37:23-37:53; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:32:19-32:28
    logic [7:0] s8_norm_shift_19_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:38:23-38:53; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:33:19-33:28
    logic [7:0] s8_norm_mux_20_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:39:22-39:51; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:22:5-22:35
    logic [7:0] s8_norm_mux_21_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:40:23-40:54; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:40:23-40:54
    logic [7:0] s8_norm_mux_22_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:41:23-41:52; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:22:5-22:35
    logic [7:0] s8_norm_bitop_23_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:42:26-42:39; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:42:26-42:39
    logic [7:0] s8_norm_bitop_24_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:43:26-43:50; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:43:26-43:50
    logic [7:0] s8_norm_bitop_25_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:44:24-44:47; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:44:24-44:47
    logic [7:0] s8_norm_bitop_26_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:45:24-45:42; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:45:24-45:42
    logic [7:0] arith_original_26; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:36:27-36:43; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:36:27-36:43


    assign s8_norm_cmp_7_v0 = (s < 5'h8); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:22:22-22:34
    assign s8_norm_bitnot_8_v0 = (~mask); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:29:29-29:34; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:29:29-29:34
    assign s8_norm_cmp_9_v0 = (a < b); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:30:20-30:25
    assign s8_norm_cmp_10_v0 = (d == 8'h0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:25:25-25:37
    assign s8_norm_add_11_v0 = (a + b); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:32:19-32:40; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:32:19-32:40
    assign s8_norm_sub_12_v0 = (a - b); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:33:19-33:40; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:33:19-33:40
    assign s8_norm_mux_13_v0 = (s8_norm_cmp_10_v0 ? 8'h1 : d); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:34:28-34:57; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:25:5-25:38
    assign s8_norm_udivmod_15_v0 = arith_original_26; // decl: <none>; prim: <none>
    assign s8_norm_shift_17_v0 = (s >= 5'd8 ? 8'h0 : (s8_norm_add_11_v0 << s)); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:37:23-37:53; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:32:19-32:28
    assign s8_norm_shift_19_v0 = (s >= 5'd8 ? 8'h0 : (s8_norm_sub_12_v0 >> s)); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:38:23-38:53; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:33:19-33:28
    assign s8_norm_mux_20_v0 = (s8_norm_cmp_7_v0 ? s8_norm_shift_17_v0 : 8'h0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:39:22-39:51; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:22:5-22:35
    assign s8_norm_mux_21_v0 = (s8_norm_cmp_10_v0 ? a : s8_norm_udivmod_15_v0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:40:23-40:54; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:40:23-40:54
    assign s8_norm_mux_22_v0 = (s8_norm_cmp_7_v0 ? s8_norm_shift_19_v0 : 8'h0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:41:23-41:52; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:22:5-22:35
    assign s8_norm_bitop_23_v0 = (s8_norm_mux_20_v0 & mask); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:42:26-42:39; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:42:26-42:39
    assign s8_norm_bitop_24_v0 = (s8_norm_mux_22_v0 & s8_norm_bitnot_8_v0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:43:26-43:50; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:43:26-43:50
    assign s8_norm_bitop_25_v0 = (s8_norm_bitop_23_v0 | s8_norm_bitop_24_v0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:44:24-44:47; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:44:24-44:47
    assign s8_norm_bitop_26_v0 = (s8_norm_bitop_25_v0 ^ s8_norm_mux_21_v0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:45:24-45:42; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:45:24-45:42
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_bitop_26_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:17:1-17:9; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:46:5-46:17
    assign less = s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:47:5-47:18
    assign arith_original_26 = (a % s8_norm_mux_13_v0); // decl: /home/zyrv/vulsim/MIX_8_A.logic.cpp:36:27-36:43; prim: /home/zyrv/vulsim/MIX_8_A.logic.cpp:36:27-36:43
endmodule
