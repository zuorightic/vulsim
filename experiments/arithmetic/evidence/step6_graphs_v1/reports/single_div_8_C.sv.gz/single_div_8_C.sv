`timescale 1ns/1ps

module single_div_8_C(
    input logic iv, // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:7:1-7:9
    input logic [7:0] d, // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:9:1-9:9
    output logic [7:0] q, // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:53-14:85
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_1_v0; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:11-14:23; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    logic [7:0] s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:36-14:52; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    logic [7:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:78-14:84; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:78-14:84
    logic [7:0] s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:55-14:85; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    logic [7:0] arith_original_9; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:78-14:84; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:78-14:84
    logic [7:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:7:1-7:9
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:11-14:23; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    logic [7:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:36-14:52; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_1_v0 = (d == 8'h0); // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:11-14:23; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    assign s8_norm_mux_3_v0 = (s8_norm_cmp_1_v0 ? 8'h1 : d); // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:36-14:52; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    assign s8_norm_udivmod_6_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mux_7_v0 = (rtlzz_pipe_3_s1 ? 8'hff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:55-14:85; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:53-14:85
    assign arith_original_9 = (rtlzz_pipe_1_s1 / rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:78-14:84; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:78-14:84
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 8'hb5;
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_4_s1 <= 8'h1;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:7:1-7:9
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_1_v0; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:11-14:23; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:36-14:52; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:14:14-14:23
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_8_C.logic.cpp:4:1-4:8
        end
    end
endmodule
