`timescale 1ns/1ps

module H_M_24_C(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:11
    input logic [23:0] a, // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:7:1-7:10
    input logic [23:0] b, // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:9:1-9:10
    input logic [23:0] c, // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:11:1-11:10
    input logic sel, // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:13:1-13:9
    output logic [23:0] y, // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:22:5-22:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [23:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:18:22-18:35
    logic [23:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:20:26-20:31
    logic [23:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:21:22-21:62
    logic [23:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:20:26-20:31
    logic [5:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:18:22-18:35
    logic [18:0] rtlzz_pipe_76_s1; // decl: <none>; prim: <none>
    logic [30:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [30:0] rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic [42:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:8


    assign s8_norm_mux_1_v0 = (sel ? c : 24'h0); // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:18:22-18:35
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + rtlzz_pipe_5_s1); // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:21:22-21:62
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:22:5-22:14
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = b[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 12'(($unsigned(12'($unsigned(mul_tree_10_11))) * $unsigned(12'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = b[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 12'(($unsigned(12'($unsigned(mul_tree_10_14))) * $unsigned(12'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = b[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 12'(($unsigned(12'($unsigned(mul_tree_10_18))) * $unsigned(12'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = a[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = b[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 12'(($unsigned(12'($unsigned(mul_tree_10_22))) * $unsigned(12'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = b[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 12'(($unsigned(12'($unsigned(mul_tree_10_26))) * $unsigned(12'($unsigned(mul_tree_10_27))))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = {mul_tree_10_28, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = b[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_32 = 12'(($unsigned(12'($unsigned(mul_tree_10_30))) * $unsigned(12'($unsigned(mul_tree_10_31))))); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = {mul_tree_10_32, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = b[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = 12'(($unsigned(12'($unsigned(mul_tree_10_34))) * $unsigned(12'($unsigned(mul_tree_10_35))))); // decl: <none>; prim: <none>
    assign mul_tree_10_37 = {mul_tree_10_36, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = a[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = b[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = 12'(($unsigned(12'($unsigned(mul_tree_10_38))) * $unsigned(12'($unsigned(mul_tree_10_39))))); // decl: <none>; prim: <none>
    assign mul_tree_10_41 = {mul_tree_10_40, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = a[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = b[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = 12'(($unsigned(12'($unsigned(mul_tree_10_42))) * $unsigned(12'($unsigned(mul_tree_10_43))))); // decl: <none>; prim: <none>
    assign mul_tree_10_45 = {mul_tree_10_44, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = a[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = b[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = 12'(($unsigned(12'($unsigned(mul_tree_10_46))) * $unsigned(12'($unsigned(mul_tree_10_47))))); // decl: <none>; prim: <none>
    assign mul_tree_10_49 = {mul_tree_10_48, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = a[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = b[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_52 = 12'(($unsigned(12'($unsigned(mul_tree_10_50))) * $unsigned(12'($unsigned(mul_tree_10_51))))); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = {mul_tree_10_52, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = a[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = b[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 12'(($unsigned(12'($unsigned(mul_tree_10_54))) * $unsigned(12'($unsigned(mul_tree_10_55))))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = {mul_tree_10_56, 30'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = a[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = b[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_60 = 12'(($unsigned(12'($unsigned(mul_tree_10_58))) * $unsigned(12'($unsigned(mul_tree_10_59))))); // decl: <none>; prim: <none>
    assign mul_tree_10_61 = {mul_tree_10_60, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = a[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = b[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_64 = 12'(($unsigned(12'($unsigned(mul_tree_10_62))) * $unsigned(12'($unsigned(mul_tree_10_63))))); // decl: <none>; prim: <none>
    assign mul_tree_10_65 = {mul_tree_10_64, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = a[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = b[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_68 = 12'(($unsigned(12'($unsigned(mul_tree_10_66))) * $unsigned(12'($unsigned(mul_tree_10_67))))); // decl: <none>; prim: <none>
    assign mul_tree_10_69 = {mul_tree_10_68, 30'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = a[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = b[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = 12'(($unsigned(12'($unsigned(mul_tree_10_70))) * $unsigned(12'($unsigned(mul_tree_10_71))))); // decl: <none>; prim: <none>
    assign mul_tree_10_73 = {mul_tree_10_72, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({7'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 19'((mul_tree_10_74 + mul_tree_10_75 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = ({7'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    assign mul_tree_10_79 = 31'((mul_tree_10_77 + mul_tree_10_78 + ({30'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_80 = ({7'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    assign mul_tree_10_82 = 25'((mul_tree_10_80 + mul_tree_10_81 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_83 = ({7'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = 37'((mul_tree_10_83 + mul_tree_10_84 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_86 = ({7'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 31'((mul_tree_10_86 + mul_tree_10_87 + ({30'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = ({7'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    assign mul_tree_10_91 = 43'((mul_tree_10_89 + mul_tree_10_90 + ({42'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_92 = ({7'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    assign mul_tree_10_94 = 37'((mul_tree_10_92 + mul_tree_10_93 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_95 = ({7'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = 49'((mul_tree_10_95 + mul_tree_10_96 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_98 = ({13'h0, rtlzz_pipe_76_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 32'((mul_tree_10_98 + mul_tree_10_99 + ({31'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({13'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_103 = 38'((mul_tree_10_101 + mul_tree_10_102 + ({37'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({13'h0, rtlzz_pipe_88_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_106 = 44'((mul_tree_10_104 + mul_tree_10_105 + ({43'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({13'h0, rtlzz_pipe_94_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = 50'((mul_tree_10_107 + mul_tree_10_108 + ({49'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({7'h0, mul_tree_10_100}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, mul_tree_10_103}); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = 39'((mul_tree_10_110 + mul_tree_10_111 + ({38'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({7'h0, mul_tree_10_106}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = 51'((mul_tree_10_113 + mul_tree_10_114 + ({50'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({13'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = 52'((mul_tree_10_116 + mul_tree_10_117 + ({51'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_tree_10_118[23:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 24'h800035;
            rtlzz_pipe_76_s1 <= 19'haf9;
            rtlzz_pipe_79_s1 <= 31'h1a800000;
            rtlzz_pipe_82_s1 <= 25'h0;
            rtlzz_pipe_85_s1 <= 37'h0;
            rtlzz_pipe_88_s1 <= 31'h0;
            rtlzz_pipe_91_s1 <= 43'h0;
            rtlzz_pipe_94_s1 <= 37'h1a800000;
            rtlzz_pipe_97_s1 <= 49'h400000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:18:22-18:35
        end
        if (iv) begin
        rtlzz_pipe_76_s1 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_24_C.logic.cpp:4:1-4:8
        end
    end
endmodule
