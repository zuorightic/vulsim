`timescale 1ns/1ps

module MAC_16_A(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:4:1-4:11
    input logic [15:0] a, // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:7:1-7:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:9:1-9:10
    input logic [31:0] c, // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:11:1-11:10
    output logic [31:0] y // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:18:5-18:14
);

    logic [31:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:9:1-9:10
    logic [31:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:17:22-17:53
    logic [15:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:7:1-7:10
    logic [15:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:9:1-9:10
    logic [31:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [31:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:9:1-9:10


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + c); // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:17:22-17:53
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({16'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({16'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = 32'(($unsigned(32'($unsigned(__beopt_width_12))) * $unsigned(32'($unsigned(__beopt_width_13))))); // decl: /home/zyrv/vulsim/MAC_16_A.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_16_A.logic.cpp:9:1-9:10
endmodule
