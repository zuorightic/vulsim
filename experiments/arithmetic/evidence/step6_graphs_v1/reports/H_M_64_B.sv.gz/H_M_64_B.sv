`timescale 1ns/1ps

module H_M_64_B(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:7:1-7:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:9:1-9:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:11:1-11:10
    input logic sel, // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:13:1-13:9
    output logic [63:0] y, // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:22:5-22:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mux_0_v0; // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:19:27-19:43
    logic [63:0] s8_norm_mul_1_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:20:26-20:31
    logic [63:0] s8_norm_add_3_v0; // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62
    logic [63:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:20:26-20:31
    logic [63:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:8


    assign s8_norm_mux_0_v0 = (sel ? c : 64'h0); // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:19:27-19:43
    assign s8_norm_mul_1_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_3_v0 = (s8_norm_mul_1_v0 + s8_norm_mux_0_v0); // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:22:5-22:14
    assign arith_original_10 = 64'(($unsigned(64'($unsigned(a))) * $unsigned(64'($unsigned(b))))); // decl: <none>; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:20:26-20:31
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_7_s1 <= 64'h8000000000000b2e;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_add_3_v0; // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:21:22-21:62
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_64_B.logic.cpp:4:1-4:8
        end
    end
endmodule
