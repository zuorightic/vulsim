`timescale 1ns/1ps

module DOT2_128_A(
    input logic iv, // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:7:1-7:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:9:1-9:11
    input logic [127:0] c, // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:11:1-11:11
    input logic [127:0] d, // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:13:1-13:11
    output logic [256:0] y // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:23:5-23:14
);

    logic [255:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:18:27-18:32; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:9:1-9:11
    logic [255:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:19:28-19:33; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:13:1-13:11
    logic [256:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:22:23-22:62; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:20:25-20:44
    logic [255:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [255:0] arith_original_14; // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:18:27-18:32; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:9:1-9:11
    logic [255:0] arith_original_15; // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:19:28-19:33; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:13:1-13:11


    assign s8_norm_mul_0_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_0_v0 + s8_norm_mul_1_v0); // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:22:23-22:62; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:20:25-20:44
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:23:5-23:14
    assign __beopt_width_14 = ({128'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({128'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({128'h0, c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({128'h0, d}); // decl: <none>; prim: <none>
    assign arith_original_14 = 256'(($unsigned(256'($unsigned(__beopt_width_14))) * $unsigned(256'($unsigned(__beopt_width_15))))); // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:18:27-18:32; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:9:1-9:11
    assign arith_original_15 = 256'(($unsigned(256'($unsigned(__beopt_width_16))) * $unsigned(256'($unsigned(__beopt_width_17))))); // decl: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:19:28-19:33; prim: /home/zyrv/vulsim/DOT2_128_A.logic.cpp:13:1-13:11
endmodule
