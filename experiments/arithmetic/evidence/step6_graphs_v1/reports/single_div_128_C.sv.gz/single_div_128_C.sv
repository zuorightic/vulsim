`timescale 1ns/1ps

module single_div_128_C(
    input logic iv, // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:7:1-7:11
    input logic [127:0] d, // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:9:1-9:11
    output logic [127:0] q, // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:59-14:95
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_1_v0; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:11-14:25; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
    logic [127:0] s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:40-14:58; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
    logic [127:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94
    logic [127:0] s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:61-14:95; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
    logic [127:0] arith_original_9; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:11-14:25; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
    logic [127:0] rtlzz_pipe_9_s1; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_1_v0 = (d == 128'h0); // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:11-14:25; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
    assign s8_norm_mux_3_v0 = (s8_norm_cmp_1_v0 ? 128'h1 : d); // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:40-14:58; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
    assign s8_norm_udivmod_6_v0 = rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
    assign s8_norm_mux_7_v0 = (rtlzz_pipe_3_s1 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:61-14:95; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:59-14:95
    assign arith_original_9 = (a / s8_norm_mux_3_v0); // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_9_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_1_v0; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:11-14:25; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:14-14:25
        end
        if (iv) begin
        rtlzz_pipe_9_s1 <= arith_original_9; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:14:88-14:94
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_128_C.logic.cpp:4:1-4:8
        end
    end
endmodule
