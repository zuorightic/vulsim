`timescale 1ns/1ps

module MUL_96_C(
    input logic iv, // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:11
    input logic [95:0] a, // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:7:1-7:10
    input logic [95:0] b, // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:9:1-9:10
    output logic [191:0] y, // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:15:5-15:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [191:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:14:27-14:32; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:9:1-9:10
    logic [95:0] __beopt_width_8; // decl: <none>; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:7:1-7:10
    logic [95:0] __beopt_width_9; // decl: <none>; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:9:1-9:10
    logic [191:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [191:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [191:0] arith_original_10; // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:14:27-14:32; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:9:1-9:10
    logic [23:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:15:5-15:18
    assign __beopt_width_8 = a; // decl: <none>; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:7:1-7:10
    assign __beopt_width_9 = b; // decl: <none>; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:9:1-9:10
    assign __beopt_width_10 = ({96'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({96'h0, __beopt_width_9}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 48'(($unsigned(48'($unsigned(mul_tree_10_11))) * $unsigned(48'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 48'(($unsigned(48'($unsigned(mul_tree_10_14))) * $unsigned(48'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 48'(($unsigned(48'($unsigned(mul_tree_10_18))) * $unsigned(48'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 48'(($unsigned(48'($unsigned(mul_tree_10_22))) * $unsigned(48'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = __beopt_width_10[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = __beopt_width_11[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 48'(($unsigned(48'($unsigned(mul_tree_10_26))) * $unsigned(48'($unsigned(mul_tree_10_27))))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = {mul_tree_10_28, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = __beopt_width_10[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = __beopt_width_11[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_32 = 48'(($unsigned(48'($unsigned(mul_tree_10_30))) * $unsigned(48'($unsigned(mul_tree_10_31))))); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = {mul_tree_10_32, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = __beopt_width_10[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = __beopt_width_11[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = 48'(($unsigned(48'($unsigned(mul_tree_10_34))) * $unsigned(48'($unsigned(mul_tree_10_35))))); // decl: <none>; prim: <none>
    assign mul_tree_10_37 = {mul_tree_10_36, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = __beopt_width_10[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = __beopt_width_11[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = 48'(($unsigned(48'($unsigned(mul_tree_10_38))) * $unsigned(48'($unsigned(mul_tree_10_39))))); // decl: <none>; prim: <none>
    assign mul_tree_10_41 = {mul_tree_10_40, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = __beopt_width_10[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = __beopt_width_11[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = 48'(($unsigned(48'($unsigned(mul_tree_10_42))) * $unsigned(48'($unsigned(mul_tree_10_43))))); // decl: <none>; prim: <none>
    assign mul_tree_10_45 = {mul_tree_10_44, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = __beopt_width_10[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = __beopt_width_11[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = 48'(($unsigned(48'($unsigned(mul_tree_10_46))) * $unsigned(48'($unsigned(mul_tree_10_47))))); // decl: <none>; prim: <none>
    assign mul_tree_10_49 = {mul_tree_10_48, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = __beopt_width_10[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = __beopt_width_11[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_52 = 48'(($unsigned(48'($unsigned(mul_tree_10_50))) * $unsigned(48'($unsigned(mul_tree_10_51))))); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = {mul_tree_10_52, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = __beopt_width_10[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = __beopt_width_11[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 48'(($unsigned(48'($unsigned(mul_tree_10_54))) * $unsigned(48'($unsigned(mul_tree_10_55))))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = {mul_tree_10_56, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = __beopt_width_10[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = __beopt_width_11[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_60 = 48'(($unsigned(48'($unsigned(mul_tree_10_58))) * $unsigned(48'($unsigned(mul_tree_10_59))))); // decl: <none>; prim: <none>
    assign mul_tree_10_61 = {mul_tree_10_60, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = __beopt_width_10[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = __beopt_width_11[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_64 = 48'(($unsigned(48'($unsigned(mul_tree_10_62))) * $unsigned(48'($unsigned(mul_tree_10_63))))); // decl: <none>; prim: <none>
    assign mul_tree_10_65 = {mul_tree_10_64, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = __beopt_width_10[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = __beopt_width_11[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_10_68 = 48'(($unsigned(48'($unsigned(mul_tree_10_66))) * $unsigned(48'($unsigned(mul_tree_10_67))))); // decl: <none>; prim: <none>
    assign mul_tree_10_69 = {mul_tree_10_68, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = __beopt_width_10[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = __beopt_width_11[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = 48'(($unsigned(48'($unsigned(mul_tree_10_70))) * $unsigned(48'($unsigned(mul_tree_10_71))))); // decl: <none>; prim: <none>
    assign mul_tree_10_73 = {mul_tree_10_72, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({25'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 73'((mul_tree_10_74 + mul_tree_10_75 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = ({25'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_79 = 121'((mul_tree_10_77 + mul_tree_10_78 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_80 = ({25'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_82 = 97'((mul_tree_10_80 + mul_tree_10_81 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_83 = ({25'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = 145'((mul_tree_10_83 + mul_tree_10_84 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_86 = ({25'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 121'((mul_tree_10_86 + mul_tree_10_87 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = ({25'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_91 = 169'((mul_tree_10_89 + mul_tree_10_90 + ({168'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_92 = ({25'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_94 = 145'((mul_tree_10_92 + mul_tree_10_93 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_95 = ({25'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = 193'((mul_tree_10_95 + mul_tree_10_96 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_98 = ({49'h0, mul_tree_10_76}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, mul_tree_10_79}); // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 122'((mul_tree_10_98 + mul_tree_10_99 + ({121'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({49'h0, mul_tree_10_82}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, mul_tree_10_85}); // decl: <none>; prim: <none>
    assign mul_tree_10_103 = 146'((mul_tree_10_101 + mul_tree_10_102 + ({145'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({49'h0, mul_tree_10_88}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, mul_tree_10_91}); // decl: <none>; prim: <none>
    assign mul_tree_10_106 = 170'((mul_tree_10_104 + mul_tree_10_105 + ({169'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({49'h0, mul_tree_10_94}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, mul_tree_10_97}); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = 194'((mul_tree_10_107 + mul_tree_10_108 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({25'h0, mul_tree_10_100}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, mul_tree_10_103}); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = 147'((mul_tree_10_110 + mul_tree_10_111 + ({146'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({25'h0, mul_tree_10_106}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = 195'((mul_tree_10_113 + mul_tree_10_114 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({49'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = 196'((mul_tree_10_116 + mul_tree_10_117 + ({195'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_tree_10_118[191:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 48'haf9;
            rtlzz_pipe_17_s1 <= 72'h0;
            rtlzz_pipe_21_s1 <= 96'h6a0000000000000000;
            rtlzz_pipe_25_s1 <= 120'h1a800000000000000000000000;
            rtlzz_pipe_29_s1 <= 72'h0;
            rtlzz_pipe_33_s1 <= 96'h0;
            rtlzz_pipe_37_s1 <= 120'h0;
            rtlzz_pipe_41_s1 <= 144'h0;
            rtlzz_pipe_45_s1 <= 96'h6a0000000000000000;
            rtlzz_pipe_49_s1 <= 120'h0;
            rtlzz_pipe_53_s1 <= 144'h400000000000000000000000000000000;
            rtlzz_pipe_57_s1 <= 168'h10000000000000000000000000000000000000000;
            rtlzz_pipe_61_s1 <= 120'h1a800000000000000000000000;
            rtlzz_pipe_65_s1 <= 144'h0;
            rtlzz_pipe_69_s1 <= 168'h10000000000000000000000000000000000000000;
            rtlzz_pipe_73_s1 <= 192'h400000000000000000000000000000000000000000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_96_C.logic.cpp:4:1-4:8
        end
    end
endmodule
