`timescale 1ns/1ps

module DOT2_8_B(
    input logic iv, // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:7:1-7:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:9:1-9:9
    input logic [7:0] c, // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:11:1-11:9
    input logic [7:0] d, // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:13:1-13:9
    output logic [16:0] y, // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:23:5-23:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:9:1-9:9
    logic [15:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:13:1-13:9
    logic [16:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:20:24-20:42
    logic [15:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [15:0] arith_original_14; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:9:1-9:9
    logic [15:0] arith_original_15; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:13:1-13:9
    logic [15:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:9:1-9:9
    logic [15:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:13:1-13:9
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (rtlzz_pipe_5_s1 + rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:20:24-20:42
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:23:5-23:14
    assign __beopt_width_14 = ({8'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({8'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({8'h0, c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({8'h0, d}); // decl: <none>; prim: <none>
    assign arith_original_14 = 16'(($unsigned(16'($unsigned(__beopt_width_14))) * $unsigned(16'($unsigned(__beopt_width_15))))); // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:9:1-9:9
    assign arith_original_15 = 16'(($unsigned(16'($unsigned(__beopt_width_16))) * $unsigned(16'($unsigned(__beopt_width_17))))); // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:13:1-13:9
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 16'h7ff9;
            rtlzz_pipe_6_s1 <= 16'h0;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:9:1-9:9
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:13:1-13:9
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_8_B.logic.cpp:4:1-4:8
        end
    end
endmodule
