`timescale 1ns/1ps

module MIX_64_A(
    input logic iv, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:7:1-7:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:9:1-9:10
    input logic [63:0] mask, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:11:1-11:13; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:11:1-11:13
    input logic [63:0] d, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:13:1-13:10
    input logic [7:0] s, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:15:1-15:9
    output logic [63:0] y, // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:46:5-46:17
    output logic less // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:47:5-47:18
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:22:22-22:35
    logic [63:0] s8_norm_bitnot_5_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:29:30-29:35; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:29:30-29:35
    logic s8_norm_cmp_6_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:30:20-30:25
    logic s8_norm_cmp_7_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:31:27-31:42
    logic [63:0] s8_norm_add_8_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:32:20-32:43; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:32:20-32:43
    logic [63:0] s8_norm_sub_9_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:33:20-33:43; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:33:20-33:43
    logic [63:0] s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:34:29-34:58; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:34:29-34:58
    logic [63:0] s8_norm_udivmod_12_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:36:28-36:44; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:36:28-36:44
    logic [63:0] s8_norm_shift_14_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:37:24-37:54; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:32:20-32:30
    logic [63:0] s8_norm_shift_16_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:38:24-38:54; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:33:20-33:30
    logic [63:0] s8_norm_mux_17_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:39:23-39:52; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:39:23-39:52
    logic [63:0] s8_norm_mux_18_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:40:24-40:55; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:40:24-40:55
    logic [63:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:41:24-41:53; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:41:24-41:53
    logic [63:0] s8_norm_bitop_20_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:42:27-42:40; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:42:27-42:40
    logic [63:0] s8_norm_bitop_21_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:43:27-43:51; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:43:27-43:51
    logic [63:0] s8_norm_bitop_22_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:44:25-44:48; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:44:25-44:48
    logic [63:0] s8_norm_bitop_23_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:45:25-45:43; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:45:25-45:43
    logic [63:0] arith_original_26; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:36:28-36:44; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:36:28-36:44


    assign s8_norm_cmp_4_v0 = (s < 8'h40); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:22:22-22:35
    assign s8_norm_bitnot_5_v0 = (~mask); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:29:30-29:35; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:29:30-29:35
    assign s8_norm_cmp_6_v0 = (a < b); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:30:20-30:25
    assign s8_norm_cmp_7_v0 = (d == 64'h0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:31:27-31:42
    assign s8_norm_add_8_v0 = (a + b); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:32:20-32:43; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:32:20-32:43
    assign s8_norm_sub_9_v0 = (a - b); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:33:20-33:43; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:33:20-33:43
    assign s8_norm_mux_10_v0 = (s8_norm_cmp_7_v0 ? 64'h1 : d); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:34:29-34:58; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:34:29-34:58
    assign s8_norm_udivmod_12_v0 = arith_original_26; // decl: <none>; prim: <none>
    assign s8_norm_shift_14_v0 = (s >= 8'd64 ? 64'h0 : (s8_norm_add_8_v0 << s)); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:37:24-37:54; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:32:20-32:30
    assign s8_norm_shift_16_v0 = (s >= 8'd64 ? 64'h0 : (s8_norm_sub_9_v0 >> s)); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:38:24-38:54; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:33:20-33:30
    assign s8_norm_mux_17_v0 = (s8_norm_cmp_4_v0 ? s8_norm_shift_14_v0 : 64'h0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:39:23-39:52; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:39:23-39:52
    assign s8_norm_mux_18_v0 = (s8_norm_cmp_7_v0 ? a : s8_norm_udivmod_12_v0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:40:24-40:55; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:40:24-40:55
    assign s8_norm_mux_19_v0 = (s8_norm_cmp_4_v0 ? s8_norm_shift_16_v0 : 64'h0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:41:24-41:53; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:41:24-41:53
    assign s8_norm_bitop_20_v0 = (s8_norm_mux_17_v0 & mask); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:42:27-42:40; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:42:27-42:40
    assign s8_norm_bitop_21_v0 = (s8_norm_mux_19_v0 & s8_norm_bitnot_5_v0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:43:27-43:51; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:43:27-43:51
    assign s8_norm_bitop_22_v0 = (s8_norm_bitop_20_v0 | s8_norm_bitop_21_v0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:44:25-44:48; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:44:25-44:48
    assign s8_norm_bitop_23_v0 = (s8_norm_bitop_22_v0 ^ s8_norm_mux_18_v0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:45:25-45:43; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:45:25-45:43
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_bitop_23_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:46:5-46:17
    assign less = s8_norm_cmp_6_v0; // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:47:5-47:18
    assign arith_original_26 = (a % s8_norm_mux_10_v0); // decl: /home/zyrv/vulsim/MIX_64_A.logic.cpp:36:28-36:44; prim: /home/zyrv/vulsim/MIX_64_A.logic.cpp:36:28-36:44
endmodule
