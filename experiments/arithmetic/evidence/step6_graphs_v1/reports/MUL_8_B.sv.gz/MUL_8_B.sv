`timescale 1ns/1ps

module MUL_8_B(
    input logic iv, // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:7:1-7:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
    output logic [15:0] y, // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:15:5-15:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
    logic [7:0] __beopt_width_8; // decl: <none>; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:7:1-7:9
    logic [7:0] __beopt_width_9; // decl: <none>; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
    logic [15:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [15:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [15:0] arith_original_10; // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
    logic [15:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:15:5-15:18
    assign __beopt_width_8 = a; // decl: <none>; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:7:1-7:9
    assign __beopt_width_9 = b; // decl: <none>; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
    assign __beopt_width_10 = ({8'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({8'h0, __beopt_width_9}); // decl: <none>; prim: <none>
    assign arith_original_10 = 16'(($unsigned(16'($unsigned(__beopt_width_10))) * $unsigned(16'($unsigned(__beopt_width_11))))); // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 16'h7ff9;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:9:1-9:9
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_8_B.logic.cpp:4:1-4:8
        end
    end
endmodule
