`timescale 1ns/1ps

module H_D_8_A(
    input logic iv, // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:7:1-7:9
    input logic [7:0] d, // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:9:1-9:9
    input logic [7:0] e, // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:11:1-11:9
    output logic [7:0] q, // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:38:5-38:19
    output logic [7:0] r1, // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:39:5-39:19
    output logic [7:0] r2 // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:40:5-40:20
);

    logic s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:22:27-22:39
    logic s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:25:28-25:40
    logic [7:0] s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:28:30-28:63; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:22:5-22:40
    logic [7:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:25:5-25:41
    logic [7:0] s8_norm_udivmod_12_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:30:29-30:47; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:30:29-30:47
    logic [7:0] s8_norm_udivmod_13_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:31:29-31:47; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:31:29-31:47
    logic [7:0] s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:32:25-32:71; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:22:5-22:40
    logic [7:0] s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:33:25-33:60; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:33:25-33:60
    logic [7:0] s8_norm_udivmod_16_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:34:30-34:57; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:34:30-34:57
    logic [7:0] s8_norm_udivmod_17_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:35:30-35:57; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:35:30-35:57
    logic [7:0] s8_norm_mux_18_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:36:26-36:75; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:25:5-25:41
    logic [7:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:37:26-37:71; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:37:26-37:71
    logic [7:0] arith_original_20; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:30:29-30:47; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:30:29-30:47
    logic [7:0] arith_original_21; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:31:29-31:47; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:31:29-31:47
    logic [7:0] arith_original_22; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:34:30-34:57; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:34:30-34:57
    logic [7:0] arith_original_23; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:35:30-35:57; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:35:30-35:57


    assign s8_norm_cmp_8_v0 = (d == 8'h0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:22:27-22:39
    assign s8_norm_cmp_9_v0 = (e == 8'h0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:25:28-25:40
    assign s8_norm_mux_10_v0 = (s8_norm_cmp_8_v0 ? 8'h1 : d); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:28:30-28:63; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:22:5-22:40
    assign s8_norm_mux_11_v0 = (s8_norm_cmp_9_v0 ? 8'h1 : e); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:25:5-25:41
    assign s8_norm_udivmod_12_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_13_v0 = arith_original_21; // decl: <none>; prim: <none>
    assign s8_norm_mux_14_v0 = (s8_norm_cmp_8_v0 ? 8'hff : s8_norm_udivmod_12_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:32:25-32:71; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:22:5-22:40
    assign s8_norm_mux_15_v0 = (s8_norm_cmp_8_v0 ? a : s8_norm_udivmod_13_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:33:25-33:60; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:33:25-33:60
    assign s8_norm_udivmod_16_v0 = arith_original_22; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_17_v0 = arith_original_23; // decl: <none>; prim: <none>
    assign s8_norm_mux_18_v0 = (s8_norm_cmp_9_v0 ? 8'hff : s8_norm_udivmod_16_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:36:26-36:75; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:25:5-25:41
    assign s8_norm_mux_19_v0 = (s8_norm_cmp_9_v0 ? s8_norm_mux_14_v0 : s8_norm_udivmod_17_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:37:26-37:71; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:37:26-37:71
    assign ov = iv; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_18_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:38:5-38:19
    assign r1 = s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:39:5-39:19
    assign r2 = s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:40:5-40:20
    assign arith_original_20 = (a / s8_norm_mux_10_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:30:29-30:47; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:30:29-30:47
    assign arith_original_21 = (a % s8_norm_mux_10_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:31:29-31:47; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:31:29-31:47
    assign arith_original_22 = (s8_norm_mux_14_v0 / s8_norm_mux_11_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:34:30-34:57; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:34:30-34:57
    assign arith_original_23 = (s8_norm_mux_14_v0 % s8_norm_mux_11_v0); // decl: /home/zyrv/vulsim/H_D_8_A.logic.cpp:35:30-35:57; prim: /home/zyrv/vulsim/H_D_8_A.logic.cpp:35:30-35:57
endmodule
