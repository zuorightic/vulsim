`timescale 1ns/1ps

module MUL_12_C(
    input logic iv, // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:11
    input logic [11:0] a, // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:7:1-7:10
    input logic [11:0] b, // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:9:1-9:10
    output logic [23:0] y, // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:15:5-15:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [23:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:9:1-9:10
    logic [11:0] __beopt_width_8; // decl: <none>; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:7:1-7:10
    logic [11:0] __beopt_width_9; // decl: <none>; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:9:1-9:10
    logic [23:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [23:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [23:0] arith_original_10; // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:9:1-9:10
    logic [2:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [8:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [14:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [2:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [9:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [12:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [21:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [16:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [19:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [22:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [20:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [26:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [27:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [9:0] rtlzz_pipe_76_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [12:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic [21:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [18:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:15:5-15:18
    assign __beopt_width_8 = a; // decl: <none>; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:7:1-7:10
    assign __beopt_width_9 = b; // decl: <none>; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:9:1-9:10
    assign __beopt_width_10 = ({12'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({12'h0, __beopt_width_9}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 6'(($unsigned(6'($unsigned(mul_tree_10_11))) * $unsigned(6'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 6'(($unsigned(6'($unsigned(mul_tree_10_14))) * $unsigned(6'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 3'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 6'(($unsigned(6'($unsigned(mul_tree_10_18))) * $unsigned(6'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 6'(($unsigned(6'($unsigned(mul_tree_10_22))) * $unsigned(6'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 9'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = __beopt_width_10[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = __beopt_width_11[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 6'(($unsigned(6'($unsigned(mul_tree_10_26))) * $unsigned(6'($unsigned(mul_tree_10_27))))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = {mul_tree_10_28, 3'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = __beopt_width_10[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = __beopt_width_11[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_32 = 6'(($unsigned(6'($unsigned(mul_tree_10_30))) * $unsigned(6'($unsigned(mul_tree_10_31))))); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = {mul_tree_10_32, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = __beopt_width_10[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = __beopt_width_11[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = 6'(($unsigned(6'($unsigned(mul_tree_10_34))) * $unsigned(6'($unsigned(mul_tree_10_35))))); // decl: <none>; prim: <none>
    assign mul_tree_10_37 = {mul_tree_10_36, 9'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = __beopt_width_10[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = __beopt_width_11[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = 6'(($unsigned(6'($unsigned(mul_tree_10_38))) * $unsigned(6'($unsigned(mul_tree_10_39))))); // decl: <none>; prim: <none>
    assign mul_tree_10_41 = {mul_tree_10_40, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = __beopt_width_10[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = __beopt_width_11[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = 6'(($unsigned(6'($unsigned(mul_tree_10_42))) * $unsigned(6'($unsigned(mul_tree_10_43))))); // decl: <none>; prim: <none>
    assign mul_tree_10_45 = {mul_tree_10_44, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = __beopt_width_10[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = __beopt_width_11[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = 6'(($unsigned(6'($unsigned(mul_tree_10_46))) * $unsigned(6'($unsigned(mul_tree_10_47))))); // decl: <none>; prim: <none>
    assign mul_tree_10_49 = {mul_tree_10_48, 9'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = __beopt_width_10[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = __beopt_width_11[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_52 = 6'(($unsigned(6'($unsigned(mul_tree_10_50))) * $unsigned(6'($unsigned(mul_tree_10_51))))); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = {mul_tree_10_52, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = __beopt_width_10[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = __beopt_width_11[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 6'(($unsigned(6'($unsigned(mul_tree_10_54))) * $unsigned(6'($unsigned(mul_tree_10_55))))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = {mul_tree_10_56, 15'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = __beopt_width_10[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = __beopt_width_11[2:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_60 = 6'(($unsigned(6'($unsigned(mul_tree_10_58))) * $unsigned(6'($unsigned(mul_tree_10_59))))); // decl: <none>; prim: <none>
    assign mul_tree_10_61 = {mul_tree_10_60, 9'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = __beopt_width_10[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = __beopt_width_11[5:3]; // decl: <none>; prim: <none>
    assign mul_tree_10_64 = 6'(($unsigned(6'($unsigned(mul_tree_10_62))) * $unsigned(6'($unsigned(mul_tree_10_63))))); // decl: <none>; prim: <none>
    assign mul_tree_10_65 = {mul_tree_10_64, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = __beopt_width_10[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = __beopt_width_11[8:6]; // decl: <none>; prim: <none>
    assign mul_tree_10_68 = 6'(($unsigned(6'($unsigned(mul_tree_10_66))) * $unsigned(6'($unsigned(mul_tree_10_67))))); // decl: <none>; prim: <none>
    assign mul_tree_10_69 = {mul_tree_10_68, 15'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = __beopt_width_10[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = __beopt_width_11[11:9]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = 6'(($unsigned(6'($unsigned(mul_tree_10_70))) * $unsigned(6'($unsigned(mul_tree_10_71))))); // decl: <none>; prim: <none>
    assign mul_tree_10_73 = {mul_tree_10_72, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({4'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 10'((mul_tree_10_74 + mul_tree_10_75 + ({9'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = ({4'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    assign mul_tree_10_79 = 16'((mul_tree_10_77 + mul_tree_10_78 + ({15'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_80 = ({4'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    assign mul_tree_10_82 = 13'((mul_tree_10_80 + mul_tree_10_81 + ({12'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_83 = ({4'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = 19'((mul_tree_10_83 + mul_tree_10_84 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_86 = ({4'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 16'((mul_tree_10_86 + mul_tree_10_87 + ({15'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = ({4'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    assign mul_tree_10_91 = 22'((mul_tree_10_89 + mul_tree_10_90 + ({21'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_92 = ({4'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    assign mul_tree_10_94 = 19'((mul_tree_10_92 + mul_tree_10_93 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_95 = ({4'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = 25'((mul_tree_10_95 + mul_tree_10_96 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_98 = ({7'h0, rtlzz_pipe_76_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 17'((mul_tree_10_98 + mul_tree_10_99 + ({16'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({7'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_103 = 20'((mul_tree_10_101 + mul_tree_10_102 + ({19'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({7'h0, rtlzz_pipe_88_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_106 = 23'((mul_tree_10_104 + mul_tree_10_105 + ({22'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({7'h0, rtlzz_pipe_94_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = 26'((mul_tree_10_107 + mul_tree_10_108 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({4'h0, mul_tree_10_100}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, mul_tree_10_103}); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = 21'((mul_tree_10_110 + mul_tree_10_111 + ({20'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({4'h0, mul_tree_10_106}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = 27'((mul_tree_10_113 + mul_tree_10_114 + ({26'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({7'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = 28'((mul_tree_10_116 + mul_tree_10_117 + ({27'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_tree_10_118[23:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_76_s1 <= 10'h109;
            rtlzz_pipe_79_s1 <= 16'h2800;
            rtlzz_pipe_82_s1 <= 13'h9f0;
            rtlzz_pipe_85_s1 <= 19'h18000;
            rtlzz_pipe_88_s1 <= 16'h0;
            rtlzz_pipe_91_s1 <= 22'h0;
            rtlzz_pipe_94_s1 <= 19'h1a800;
            rtlzz_pipe_97_s1 <= 25'h400000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_76_s1 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_12_C.logic.cpp:4:1-4:8
        end
    end
endmodule
