`timescale 1ns/1ps

module H_M_128_B(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:7:1-7:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:9:1-9:11
    input logic [127:0] c, // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:11:1-11:11
    input logic sel, // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:13:1-13:9
    output logic [127:0] y, // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:22:5-22:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:19:28-19:44; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:18:23-18:37
    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:20:27-20:32
    logic [127:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65
    logic [127:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:20:27-20:32
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:8


    assign s8_norm_mux_1_v0 = (sel ? c : 128'h0); // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:19:28-19:44; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:18:23-18:37
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + s8_norm_mux_1_v0); // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:22:5-22:14
    assign arith_original_10 = 128'(($unsigned(128'($unsigned(a))) * $unsigned(128'($unsigned(b))))); // decl: <none>; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:20:27-20:32
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_7_s1 <= 128'h80000000000000d60000000000000b2e;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:21:23-21:65
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_128_B.logic.cpp:4:1-4:8
        end
    end
endmodule
