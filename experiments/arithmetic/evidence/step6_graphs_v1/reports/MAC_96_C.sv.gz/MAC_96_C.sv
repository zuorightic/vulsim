`timescale 1ns/1ps

module MAC_96_C(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:11
    input logic [95:0] a, // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:7:1-7:10
    input logic [95:0] b, // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:9:1-9:10
    input logic [191:0] c, // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:11:1-11:11
    output logic [191:0] y, // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:18:5-18:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [191:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:9:1-9:10
    logic [191:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:17:23-17:56
    logic [95:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:7:1-7:10
    logic [95:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:9:1-9:10
    logic [191:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [191:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [191:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:9:1-9:10
    logic [23:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [119:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [143:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [167:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [120:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [168:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [144:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [192:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [121:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [145:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [169:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [193:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [146:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [194:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [195:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [191:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:11:1-11:11
    logic [47:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [119:0] rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
    logic [143:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [167:0] rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
    logic [191:0] rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + rtlzz_pipe_3_s1); // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:17:23-17:56
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({96'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({96'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_121; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = __beopt_width_12[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = __beopt_width_13[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 48'(($unsigned(48'($unsigned(mul_tree_12_13))) * $unsigned(48'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = __beopt_width_12[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = __beopt_width_13[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 48'(($unsigned(48'($unsigned(mul_tree_12_16))) * $unsigned(48'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = __beopt_width_12[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = __beopt_width_13[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 48'(($unsigned(48'($unsigned(mul_tree_12_20))) * $unsigned(48'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = __beopt_width_12[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = __beopt_width_13[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 48'(($unsigned(48'($unsigned(mul_tree_12_24))) * $unsigned(48'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = __beopt_width_12[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = __beopt_width_13[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 48'(($unsigned(48'($unsigned(mul_tree_12_28))) * $unsigned(48'($unsigned(mul_tree_12_29))))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = {mul_tree_12_30, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = __beopt_width_12[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = __beopt_width_13[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_34 = 48'(($unsigned(48'($unsigned(mul_tree_12_32))) * $unsigned(48'($unsigned(mul_tree_12_33))))); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = {mul_tree_12_34, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = __beopt_width_12[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = __beopt_width_13[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_38 = 48'(($unsigned(48'($unsigned(mul_tree_12_36))) * $unsigned(48'($unsigned(mul_tree_12_37))))); // decl: <none>; prim: <none>
    assign mul_tree_12_39 = {mul_tree_12_38, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = __beopt_width_12[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = __beopt_width_13[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_42 = 48'(($unsigned(48'($unsigned(mul_tree_12_40))) * $unsigned(48'($unsigned(mul_tree_12_41))))); // decl: <none>; prim: <none>
    assign mul_tree_12_43 = {mul_tree_12_42, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = __beopt_width_12[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = __beopt_width_13[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_46 = 48'(($unsigned(48'($unsigned(mul_tree_12_44))) * $unsigned(48'($unsigned(mul_tree_12_45))))); // decl: <none>; prim: <none>
    assign mul_tree_12_47 = {mul_tree_12_46, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = __beopt_width_12[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = __beopt_width_13[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_50 = 48'(($unsigned(48'($unsigned(mul_tree_12_48))) * $unsigned(48'($unsigned(mul_tree_12_49))))); // decl: <none>; prim: <none>
    assign mul_tree_12_51 = {mul_tree_12_50, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = __beopt_width_12[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = __beopt_width_13[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_54 = 48'(($unsigned(48'($unsigned(mul_tree_12_52))) * $unsigned(48'($unsigned(mul_tree_12_53))))); // decl: <none>; prim: <none>
    assign mul_tree_12_55 = {mul_tree_12_54, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = __beopt_width_12[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = __beopt_width_13[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_58 = 48'(($unsigned(48'($unsigned(mul_tree_12_56))) * $unsigned(48'($unsigned(mul_tree_12_57))))); // decl: <none>; prim: <none>
    assign mul_tree_12_59 = {mul_tree_12_58, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = __beopt_width_12[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = __beopt_width_13[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_62 = 48'(($unsigned(48'($unsigned(mul_tree_12_60))) * $unsigned(48'($unsigned(mul_tree_12_61))))); // decl: <none>; prim: <none>
    assign mul_tree_12_63 = {mul_tree_12_62, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = __beopt_width_12[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = __beopt_width_13[47:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_66 = 48'(($unsigned(48'($unsigned(mul_tree_12_64))) * $unsigned(48'($unsigned(mul_tree_12_65))))); // decl: <none>; prim: <none>
    assign mul_tree_12_67 = {mul_tree_12_66, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = __beopt_width_12[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = __beopt_width_13[71:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_70 = 48'(($unsigned(48'($unsigned(mul_tree_12_68))) * $unsigned(48'($unsigned(mul_tree_12_69))))); // decl: <none>; prim: <none>
    assign mul_tree_12_71 = {mul_tree_12_70, 120'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = __beopt_width_12[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = __beopt_width_13[95:72]; // decl: <none>; prim: <none>
    assign mul_tree_12_74 = 48'(($unsigned(48'($unsigned(mul_tree_12_72))) * $unsigned(48'($unsigned(mul_tree_12_73))))); // decl: <none>; prim: <none>
    assign mul_tree_12_75 = {mul_tree_12_74, 144'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = ({25'h0, rtlzz_pipe_15_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_77 = ({1'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_78 = 73'((mul_tree_12_76 + mul_tree_12_77 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_79 = ({25'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_80 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_81 = 121'((mul_tree_12_79 + mul_tree_12_80 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_82 = ({25'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_83 = ({1'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_84 = 97'((mul_tree_12_82 + mul_tree_12_83 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_85 = ({25'h0, rtlzz_pipe_39_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_86 = ({1'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_87 = 145'((mul_tree_12_85 + mul_tree_12_86 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_88 = ({25'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_89 = ({1'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_90 = 121'((mul_tree_12_88 + mul_tree_12_89 + ({120'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_91 = ({25'h0, rtlzz_pipe_55_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_92 = ({1'h0, rtlzz_pipe_59_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_93 = 169'((mul_tree_12_91 + mul_tree_12_92 + ({168'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_94 = ({25'h0, rtlzz_pipe_63_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_95 = ({1'h0, rtlzz_pipe_67_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_96 = 145'((mul_tree_12_94 + mul_tree_12_95 + ({144'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_97 = ({25'h0, rtlzz_pipe_71_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_98 = ({1'h0, rtlzz_pipe_75_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_99 = 193'((mul_tree_12_97 + mul_tree_12_98 + ({192'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_100 = ({49'h0, mul_tree_12_78}); // decl: <none>; prim: <none>
    assign mul_tree_12_101 = ({1'h0, mul_tree_12_81}); // decl: <none>; prim: <none>
    assign mul_tree_12_102 = 122'((mul_tree_12_100 + mul_tree_12_101 + ({121'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_103 = ({49'h0, mul_tree_12_84}); // decl: <none>; prim: <none>
    assign mul_tree_12_104 = ({1'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    assign mul_tree_12_105 = 146'((mul_tree_12_103 + mul_tree_12_104 + ({145'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_106 = ({49'h0, mul_tree_12_90}); // decl: <none>; prim: <none>
    assign mul_tree_12_107 = ({1'h0, mul_tree_12_93}); // decl: <none>; prim: <none>
    assign mul_tree_12_108 = 170'((mul_tree_12_106 + mul_tree_12_107 + ({169'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_109 = ({49'h0, mul_tree_12_96}); // decl: <none>; prim: <none>
    assign mul_tree_12_110 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    assign mul_tree_12_111 = 194'((mul_tree_12_109 + mul_tree_12_110 + ({193'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_112 = ({25'h0, mul_tree_12_102}); // decl: <none>; prim: <none>
    assign mul_tree_12_113 = ({1'h0, mul_tree_12_105}); // decl: <none>; prim: <none>
    assign mul_tree_12_114 = 147'((mul_tree_12_112 + mul_tree_12_113 + ({146'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_115 = ({25'h0, mul_tree_12_108}); // decl: <none>; prim: <none>
    assign mul_tree_12_116 = ({1'h0, mul_tree_12_111}); // decl: <none>; prim: <none>
    assign mul_tree_12_117 = 195'((mul_tree_12_115 + mul_tree_12_116 + ({194'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_118 = ({49'h0, mul_tree_12_114}); // decl: <none>; prim: <none>
    assign mul_tree_12_119 = ({1'h0, mul_tree_12_117}); // decl: <none>; prim: <none>
    assign mul_tree_12_120 = 196'((mul_tree_12_118 + mul_tree_12_119 + ({195'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_tree_12_120[191:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 192'h800000000000000000000000000000020000000000000035;
            rtlzz_pipe_15_s1 <= 48'haf9;
            rtlzz_pipe_19_s1 <= 72'h0;
            rtlzz_pipe_23_s1 <= 96'h6a0000000000000000;
            rtlzz_pipe_27_s1 <= 120'h1a800000000000000000000000;
            rtlzz_pipe_31_s1 <= 72'h0;
            rtlzz_pipe_35_s1 <= 96'h0;
            rtlzz_pipe_39_s1 <= 120'h0;
            rtlzz_pipe_43_s1 <= 144'h0;
            rtlzz_pipe_47_s1 <= 96'h6a0000000000000000;
            rtlzz_pipe_51_s1 <= 120'h0;
            rtlzz_pipe_55_s1 <= 144'h400000000000000000000000000000000;
            rtlzz_pipe_59_s1 <= 168'h10000000000000000000000000000000000000000;
            rtlzz_pipe_63_s1 <= 120'h1a800000000000000000000000;
            rtlzz_pipe_67_s1 <= 144'h0;
            rtlzz_pipe_71_s1 <= 168'h10000000000000000000000000000000000000000;
            rtlzz_pipe_75_s1 <= 192'h400000000000000000000000000000000000000000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= c; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:11:1-11:11
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= mul_tree_12_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_12_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_12_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_12_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_12_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_12_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= mul_tree_12_39; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_12_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_12_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_12_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= mul_tree_12_55; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= mul_tree_12_59; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_63_s1 <= mul_tree_12_63; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= mul_tree_12_67; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_71_s1 <= mul_tree_12_71; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_75_s1 <= mul_tree_12_75; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_96_C.logic.cpp:4:1-4:8
        end
    end
endmodule
