`timescale 1ns/1ps

module H_D_128_C(
    input logic iv, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:7:1-7:11
    input logic [127:0] d, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:9:1-9:11
    input logic [127:0] e, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:11:1-11:11
    output logic [127:0] q, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:38:5-38:19
    output logic [127:0] r1, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:15:1-15:12; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:39:5-39:19
    output logic [127:0] r2, // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:17:1-17:12; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:40:5-40:20
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:29-22:43
    logic s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:30-25:44
    logic [127:0] s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:28:32-28:65; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
    logic [127:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:29:33-29:68; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
    logic [127:0] s8_norm_udivmod_12_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:30:31-30:49; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:30:31-30:49
    logic [127:0] s8_norm_udivmod_13_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:31:31-31:49; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:31:31-31:49
    logic [127:0] s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:32:27-32:73; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
    logic [127:0] s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62
    logic [127:0] s8_norm_udivmod_16_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:34:32-34:59; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:34:32-34:59
    logic [127:0] s8_norm_udivmod_17_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:35:32-35:59; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:35:32-35:59
    logic [127:0] s8_norm_mux_18_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:36:28-36:77; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
    logic [127:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:37:28-37:73; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:37:28-37:73
    logic [127:0] arith_original_20; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:30:31-30:49; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:30:31-30:49
    logic [127:0] arith_original_21; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:31:31-31:49; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:31:31-31:49
    logic [127:0] arith_original_22; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:34:32-34:59; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:34:32-34:59
    logic [127:0] arith_original_23; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:35:32-35:59; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:35:32-35:59
    logic [127:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:7:1-7:11
    logic rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:29-22:43
    logic rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:30-25:44
    logic rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:30-25:44
    logic [127:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:28:32-28:65; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
    logic [127:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:29:33-29:68; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
    logic [127:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:29:33-29:68; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
    logic [127:0] rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:32:27-32:73; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
    logic [127:0] rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_8_v0 = (d == 128'h0); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:29-22:43
    assign s8_norm_cmp_9_v0 = (e == 128'h0); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:30-25:44
    assign s8_norm_mux_10_v0 = (s8_norm_cmp_8_v0 ? 128'h1 : d); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:28:32-28:65; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
    assign s8_norm_mux_11_v0 = (s8_norm_cmp_9_v0 ? 128'h1 : e); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:29:33-29:68; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
    assign s8_norm_udivmod_12_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_13_v0 = arith_original_21; // decl: <none>; prim: <none>
    assign s8_norm_mux_14_v0 = (rtlzz_pipe_4_s1 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_12_v0); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:32:27-32:73; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
    assign s8_norm_mux_15_v0 = (rtlzz_pipe_4_s1 ? rtlzz_pipe_1_s1 : s8_norm_udivmod_13_v0); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62
    assign s8_norm_udivmod_16_v0 = arith_original_22; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_17_v0 = arith_original_23; // decl: <none>; prim: <none>
    assign s8_norm_mux_18_v0 = (rtlzz_pipe_5_s2 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_16_v0); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:36:28-36:77; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
    assign s8_norm_mux_19_v0 = (rtlzz_pipe_5_s2 ? rtlzz_pipe_10_s2 : s8_norm_udivmod_17_v0); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:37:28-37:73; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:37:28-37:73
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_18_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:38:5-38:19
    assign r1 = rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:15:1-15:12; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:39:5-39:19
    assign r2 = s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:17:1-17:12; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:40:5-40:20
    assign arith_original_20 = (rtlzz_pipe_1_s1 / rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:30:31-30:49; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:30:31-30:49
    assign arith_original_21 = (rtlzz_pipe_1_s1 % rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:31:31-31:49; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:31:31-31:49
    assign arith_original_22 = (rtlzz_pipe_10_s2 / rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:34:32-34:59; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:34:32-34:59
    assign arith_original_23 = (rtlzz_pipe_10_s2 % rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:35:32-35:59; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:35:32-35:59
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_pipe_4_s1 <= 1'h1;
            rtlzz_pipe_5_s1 <= 1'h1;
            rtlzz_pipe_5_s2 <= 1'h1;
            rtlzz_pipe_6_s1 <= 128'h1;
            rtlzz_pipe_7_s1 <= 128'h1;
            rtlzz_pipe_7_s2 <= 128'h1;
            rtlzz_pipe_10_s2 <= 128'hffffffffffffffffffffffffffffffff;
            rtlzz_pipe_11_s2 <= 128'h80000000000000020000000000000035;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:7:1-7:11
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:29-22:43
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:30-25:44
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:30-25:44
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:28:32-28:65; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:29:33-29:68; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:29:33-29:68; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:25:5-25:45
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:32:27-32:73; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:22:5-22:44
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:33:27-33:62
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_128_C.logic.cpp:4:1-4:8
        end
    end
endmodule
