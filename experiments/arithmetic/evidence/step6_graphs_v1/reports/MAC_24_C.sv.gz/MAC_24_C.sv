`timescale 1ns/1ps

module MAC_24_C(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:11
    input logic [23:0] a, // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:7:1-7:10
    input logic [23:0] b, // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:9:1-9:10
    input logic [47:0] c, // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:11:1-11:10
    output logic [47:0] y, // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:18:5-18:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [47:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:9:1-9:10
    logic [47:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:17:22-17:53
    logic [23:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:7:1-7:10
    logic [23:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:9:1-9:10
    logic [47:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [47:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [47:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:9:1-9:10
    logic [5:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [29:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [30:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [42:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [37:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [43:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [38:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [51:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:11:1-11:10
    logic [18:0] rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
    logic [30:0] rtlzz_pipe_81_s1; // decl: <none>; prim: <none>
    logic [24:0] rtlzz_pipe_84_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_87_s1; // decl: <none>; prim: <none>
    logic [30:0] rtlzz_pipe_90_s1; // decl: <none>; prim: <none>
    logic [42:0] rtlzz_pipe_93_s1; // decl: <none>; prim: <none>
    logic [36:0] rtlzz_pipe_96_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_99_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + rtlzz_pipe_3_s1); // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:17:22-17:53
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({24'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({24'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_121; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = __beopt_width_12[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = __beopt_width_13[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 12'(($unsigned(12'($unsigned(mul_tree_12_13))) * $unsigned(12'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = __beopt_width_12[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = __beopt_width_13[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 12'(($unsigned(12'($unsigned(mul_tree_12_16))) * $unsigned(12'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = __beopt_width_12[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = __beopt_width_13[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 12'(($unsigned(12'($unsigned(mul_tree_12_20))) * $unsigned(12'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = __beopt_width_12[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = __beopt_width_13[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 12'(($unsigned(12'($unsigned(mul_tree_12_24))) * $unsigned(12'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = __beopt_width_12[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = __beopt_width_13[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 12'(($unsigned(12'($unsigned(mul_tree_12_28))) * $unsigned(12'($unsigned(mul_tree_12_29))))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = {mul_tree_12_30, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = __beopt_width_12[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = __beopt_width_13[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_34 = 12'(($unsigned(12'($unsigned(mul_tree_12_32))) * $unsigned(12'($unsigned(mul_tree_12_33))))); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = {mul_tree_12_34, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = __beopt_width_12[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = __beopt_width_13[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_38 = 12'(($unsigned(12'($unsigned(mul_tree_12_36))) * $unsigned(12'($unsigned(mul_tree_12_37))))); // decl: <none>; prim: <none>
    assign mul_tree_12_39 = {mul_tree_12_38, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = __beopt_width_12[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = __beopt_width_13[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_42 = 12'(($unsigned(12'($unsigned(mul_tree_12_40))) * $unsigned(12'($unsigned(mul_tree_12_41))))); // decl: <none>; prim: <none>
    assign mul_tree_12_43 = {mul_tree_12_42, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = __beopt_width_12[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = __beopt_width_13[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_46 = 12'(($unsigned(12'($unsigned(mul_tree_12_44))) * $unsigned(12'($unsigned(mul_tree_12_45))))); // decl: <none>; prim: <none>
    assign mul_tree_12_47 = {mul_tree_12_46, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = __beopt_width_12[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = __beopt_width_13[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_50 = 12'(($unsigned(12'($unsigned(mul_tree_12_48))) * $unsigned(12'($unsigned(mul_tree_12_49))))); // decl: <none>; prim: <none>
    assign mul_tree_12_51 = {mul_tree_12_50, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = __beopt_width_12[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = __beopt_width_13[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_54 = 12'(($unsigned(12'($unsigned(mul_tree_12_52))) * $unsigned(12'($unsigned(mul_tree_12_53))))); // decl: <none>; prim: <none>
    assign mul_tree_12_55 = {mul_tree_12_54, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = __beopt_width_12[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = __beopt_width_13[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_58 = 12'(($unsigned(12'($unsigned(mul_tree_12_56))) * $unsigned(12'($unsigned(mul_tree_12_57))))); // decl: <none>; prim: <none>
    assign mul_tree_12_59 = {mul_tree_12_58, 30'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = __beopt_width_12[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = __beopt_width_13[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_62 = 12'(($unsigned(12'($unsigned(mul_tree_12_60))) * $unsigned(12'($unsigned(mul_tree_12_61))))); // decl: <none>; prim: <none>
    assign mul_tree_12_63 = {mul_tree_12_62, 18'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = __beopt_width_12[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = __beopt_width_13[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_66 = 12'(($unsigned(12'($unsigned(mul_tree_12_64))) * $unsigned(12'($unsigned(mul_tree_12_65))))); // decl: <none>; prim: <none>
    assign mul_tree_12_67 = {mul_tree_12_66, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = __beopt_width_12[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = __beopt_width_13[17:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_70 = 12'(($unsigned(12'($unsigned(mul_tree_12_68))) * $unsigned(12'($unsigned(mul_tree_12_69))))); // decl: <none>; prim: <none>
    assign mul_tree_12_71 = {mul_tree_12_70, 30'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = __beopt_width_12[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = __beopt_width_13[23:18]; // decl: <none>; prim: <none>
    assign mul_tree_12_74 = 12'(($unsigned(12'($unsigned(mul_tree_12_72))) * $unsigned(12'($unsigned(mul_tree_12_73))))); // decl: <none>; prim: <none>
    assign mul_tree_12_75 = {mul_tree_12_74, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = ({7'h0, mul_tree_12_15}); // decl: <none>; prim: <none>
    assign mul_tree_12_77 = ({1'h0, mul_tree_12_19}); // decl: <none>; prim: <none>
    assign mul_tree_12_78 = 19'((mul_tree_12_76 + mul_tree_12_77 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_79 = ({7'h0, mul_tree_12_23}); // decl: <none>; prim: <none>
    assign mul_tree_12_80 = ({1'h0, mul_tree_12_27}); // decl: <none>; prim: <none>
    assign mul_tree_12_81 = 31'((mul_tree_12_79 + mul_tree_12_80 + ({30'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_82 = ({7'h0, mul_tree_12_31}); // decl: <none>; prim: <none>
    assign mul_tree_12_83 = ({1'h0, mul_tree_12_35}); // decl: <none>; prim: <none>
    assign mul_tree_12_84 = 25'((mul_tree_12_82 + mul_tree_12_83 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_85 = ({7'h0, mul_tree_12_39}); // decl: <none>; prim: <none>
    assign mul_tree_12_86 = ({1'h0, mul_tree_12_43}); // decl: <none>; prim: <none>
    assign mul_tree_12_87 = 37'((mul_tree_12_85 + mul_tree_12_86 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_88 = ({7'h0, mul_tree_12_47}); // decl: <none>; prim: <none>
    assign mul_tree_12_89 = ({1'h0, mul_tree_12_51}); // decl: <none>; prim: <none>
    assign mul_tree_12_90 = 31'((mul_tree_12_88 + mul_tree_12_89 + ({30'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_91 = ({7'h0, mul_tree_12_55}); // decl: <none>; prim: <none>
    assign mul_tree_12_92 = ({1'h0, mul_tree_12_59}); // decl: <none>; prim: <none>
    assign mul_tree_12_93 = 43'((mul_tree_12_91 + mul_tree_12_92 + ({42'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_94 = ({7'h0, mul_tree_12_63}); // decl: <none>; prim: <none>
    assign mul_tree_12_95 = ({1'h0, mul_tree_12_67}); // decl: <none>; prim: <none>
    assign mul_tree_12_96 = 37'((mul_tree_12_94 + mul_tree_12_95 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_97 = ({7'h0, mul_tree_12_71}); // decl: <none>; prim: <none>
    assign mul_tree_12_98 = ({1'h0, mul_tree_12_75}); // decl: <none>; prim: <none>
    assign mul_tree_12_99 = 49'((mul_tree_12_97 + mul_tree_12_98 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_100 = ({13'h0, rtlzz_pipe_78_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_101 = ({1'h0, rtlzz_pipe_81_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_102 = 32'((mul_tree_12_100 + mul_tree_12_101 + ({31'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_103 = ({13'h0, rtlzz_pipe_84_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_104 = ({1'h0, rtlzz_pipe_87_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_105 = 38'((mul_tree_12_103 + mul_tree_12_104 + ({37'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_106 = ({13'h0, rtlzz_pipe_90_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_107 = ({1'h0, rtlzz_pipe_93_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_108 = 44'((mul_tree_12_106 + mul_tree_12_107 + ({43'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_109 = ({13'h0, rtlzz_pipe_96_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_110 = ({1'h0, rtlzz_pipe_99_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_111 = 50'((mul_tree_12_109 + mul_tree_12_110 + ({49'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_112 = ({7'h0, mul_tree_12_102}); // decl: <none>; prim: <none>
    assign mul_tree_12_113 = ({1'h0, mul_tree_12_105}); // decl: <none>; prim: <none>
    assign mul_tree_12_114 = 39'((mul_tree_12_112 + mul_tree_12_113 + ({38'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_115 = ({7'h0, mul_tree_12_108}); // decl: <none>; prim: <none>
    assign mul_tree_12_116 = ({1'h0, mul_tree_12_111}); // decl: <none>; prim: <none>
    assign mul_tree_12_117 = 51'((mul_tree_12_115 + mul_tree_12_116 + ({50'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_118 = ({13'h0, mul_tree_12_114}); // decl: <none>; prim: <none>
    assign mul_tree_12_119 = ({1'h0, mul_tree_12_117}); // decl: <none>; prim: <none>
    assign mul_tree_12_120 = 52'((mul_tree_12_118 + mul_tree_12_119 + ({51'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_tree_12_120[47:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 48'h800000000035;
            rtlzz_pipe_78_s1 <= 19'haf9;
            rtlzz_pipe_81_s1 <= 31'h1a800000;
            rtlzz_pipe_84_s1 <= 25'h0;
            rtlzz_pipe_87_s1 <= 37'h0;
            rtlzz_pipe_90_s1 <= 31'h0;
            rtlzz_pipe_93_s1 <= 43'h0;
            rtlzz_pipe_96_s1 <= 37'h1a800000;
            rtlzz_pipe_99_s1 <= 49'h400000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= c; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:11:1-11:10
        end
        if (iv) begin
        rtlzz_pipe_78_s1 <= mul_tree_12_78; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_81_s1 <= mul_tree_12_81; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_84_s1 <= mul_tree_12_84; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_87_s1 <= mul_tree_12_87; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_90_s1 <= mul_tree_12_90; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_93_s1 <= mul_tree_12_93; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_96_s1 <= mul_tree_12_96; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_99_s1 <= mul_tree_12_99; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_24_C.logic.cpp:4:1-4:8
        end
    end
endmodule
