`timescale 1ns/1ps

module MAC_12_C(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:11
    input logic [11:0] a, // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:7:1-7:10
    input logic [11:0] b, // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:9:1-9:10
    input logic [23:0] c, // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:11:1-11:10
    output logic [23:0] y, // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:18:5-18:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [23:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:9:1-9:10
    logic [23:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:17:22-17:53
    logic [11:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:7:1-7:10
    logic [11:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:9:1-9:10
    logic [23:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [23:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [23:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:9:1-9:10
    logic [5:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:11:1-11:10
    logic [11:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + rtlzz_pipe_3_s1); // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:17:22-17:53
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({12'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({12'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_37; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = __beopt_width_12[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = __beopt_width_13[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 12'(($unsigned(12'($unsigned(mul_tree_12_13))) * $unsigned(12'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = __beopt_width_12[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = __beopt_width_13[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 12'(($unsigned(12'($unsigned(mul_tree_12_16))) * $unsigned(12'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = __beopt_width_12[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = __beopt_width_13[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 12'(($unsigned(12'($unsigned(mul_tree_12_20))) * $unsigned(12'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = __beopt_width_12[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = __beopt_width_13[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 12'(($unsigned(12'($unsigned(mul_tree_12_24))) * $unsigned(12'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = ({7'h0, rtlzz_pipe_15_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_29 = ({1'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 19'((mul_tree_12_28 + mul_tree_12_29 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = ({7'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_32 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_33 = 25'((mul_tree_12_31 + mul_tree_12_32 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_34 = ({7'h0, mul_tree_12_30}); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = ({1'h0, mul_tree_12_33}); // decl: <none>; prim: <none>
    assign mul_tree_12_36 = 26'((mul_tree_12_34 + mul_tree_12_35 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_37 = mul_tree_12_36[23:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 24'h800035;
            rtlzz_pipe_15_s1 <= 12'haf9;
            rtlzz_pipe_19_s1 <= 18'h1a800;
            rtlzz_pipe_23_s1 <= 18'h1a800;
            rtlzz_pipe_27_s1 <= 24'h400000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= c; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:11:1-11:10
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= mul_tree_12_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_12_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_12_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_12_27; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_12_C.logic.cpp:4:1-4:8
        end
    end
endmodule
