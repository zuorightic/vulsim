`timescale 1ns/1ps

module UDR_32_A(
    input logic iv, // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:4:1-4:11
    input logic [31:0] a, // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:7:1-7:10
    input logic [31:0] d, // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:9:1-9:10
    output logic [31:0] q, // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:25:5-25:18
    output logic [31:0] r // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:26:5-26:18
);

    logic s8_norm_cmp_3_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:18:28-18:41
    logic [31:0] s8_norm_mux_4_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:20:31-20:64; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:18:5-18:42
    logic [31:0] s8_norm_udivmod_5_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:21:30-21:48; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:21:30-21:48
    logic [31:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:22:30-22:48; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:22:30-22:48
    logic [31:0] s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:23:26-23:72; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:18:5-18:42
    logic [31:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:24:26-24:61; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:24:26-24:61
    logic [31:0] arith_original_12; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:21:30-21:48; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:21:30-21:48
    logic [31:0] arith_original_13; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:22:30-22:48; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:22:30-22:48


    assign s8_norm_cmp_3_v0 = (d == 32'h0); // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:18:28-18:41
    assign s8_norm_mux_4_v0 = (s8_norm_cmp_3_v0 ? 32'h1 : d); // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:20:31-20:64; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:18:5-18:42
    assign s8_norm_udivmod_5_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_6_v0 = arith_original_13; // decl: <none>; prim: <none>
    assign s8_norm_mux_7_v0 = (s8_norm_cmp_3_v0 ? 32'hffffffff : s8_norm_udivmod_5_v0); // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:23:26-23:72; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:18:5-18:42
    assign s8_norm_mux_8_v0 = (s8_norm_cmp_3_v0 ? a : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:24:26-24:61; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:24:26-24:61
    assign ov = iv; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:25:5-25:18
    assign r = s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:26:5-26:18
    assign arith_original_12 = (a / s8_norm_mux_4_v0); // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:21:30-21:48; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:21:30-21:48
    assign arith_original_13 = (a % s8_norm_mux_4_v0); // decl: /home/zyrv/vulsim/UDR_32_A.logic.cpp:22:30-22:48; prim: /home/zyrv/vulsim/UDR_32_A.logic.cpp:22:30-22:48
endmodule
