`timescale 1ns/1ps

module single_mod_32_C(
    input logic iv, // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:11
    input logic [31:0] a, // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:7:1-7:10
    input logic [31:0] d, // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:9:1-9:10
    output logic [31:0] r, // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:56-14:80
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_0_v0; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24
    logic [31:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55
    logic [31:0] s8_norm_udivmod_2_v0; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:73-14:79; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:73-14:79
    logic [31:0] s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:58-14:80; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:58-14:80
    logic [31:0] arith_original_9; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:73-14:79; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:73-14:79
    logic [31:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:7:1-7:10
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24
    logic [31:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_0_v0 = (d == 32'h0); // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24
    assign s8_norm_mux_1_v0 = (s8_norm_cmp_0_v0 ? 32'h1 : d); // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55
    assign s8_norm_udivmod_2_v0 = arith_original_9; // decl: <none>; prim: <none>
    assign s8_norm_mux_3_v0 = (rtlzz_pipe_3_s1 ? rtlzz_pipe_1_s1 : s8_norm_udivmod_2_v0); // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:58-14:80; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:58-14:80
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign r = s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:56-14:80
    assign arith_original_9 = (rtlzz_pipe_1_s1 % rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:73-14:79; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:73-14:79
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 32'h80000035;
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_4_s1 <= 32'h1;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_0_v0; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:11-14:24
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:14:38-14:55
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_mod_32_C.logic.cpp:4:1-4:8
        end
    end
endmodule
