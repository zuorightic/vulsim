`timescale 1ns/1ps

module DIVSEL_128_C(
    input logic iv, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:7:1-7:11
    input logic [127:0] d, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:9:1-9:11
    input logic [127:0] bias, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:11:1-11:14; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:11:1-11:14
    input logic [127:0] bypass, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:13:1-13:16; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:13:1-13:16
    input logic sel, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:15:1-15:9
    output logic [127:0] y, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:33:5-33:17
    output logic [127:0] r, // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:19:1-19:11; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:34:5-34:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:24:29-24:43
    logic [127:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:26:32-26:65; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:24:5-24:44
    logic [127:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:27:31-27:49; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:27:31-27:49
    logic [127:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:28:31-28:49; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:28:31-28:49
    logic [127:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:29:27-29:73; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:24:5-24:44
    logic [127:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62
    logic [127:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:31:28-31:64; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:31:28-31:64
    logic [127:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51
    logic [127:0] arith_original_17; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:27:31-27:49; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:27:31-27:49
    logic [127:0] arith_original_18; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:28:31-28:49; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:28:31-28:49
    logic [127:0] rtlzz_pipe_13_s1; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51
    logic [127:0] rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_4_v0 = (d == 128'h0); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:24:29-24:43
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 128'h1 : d); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:26:32-26:65; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:24:5-24:44
    assign s8_norm_udivmod_6_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (s8_norm_cmp_4_v0 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:29:27-29:73; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:24:5-24:44
    assign s8_norm_mux_9_v0 = (s8_norm_cmp_4_v0 ? a : s8_norm_udivmod_7_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62
    assign s8_norm_add_10_v0 = (s8_norm_mux_8_v0 + bias); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:31:28-31:64; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:31:28-31:64
    assign s8_norm_mux_11_v0 = (sel ? s8_norm_add_10_v0 : bypass); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_13_s1; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:33:5-33:17
    assign r = rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:19:1-19:11; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:34:5-34:18
    assign arith_original_17 = (a / s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:27:31-27:49; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:27:31-27:49
    assign arith_original_18 = (a % s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:28:31-28:49; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:28:31-28:49
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 128'h80000000000000020000000000000034;
            rtlzz_pipe_11_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:32:26-32:51
        end
        if (iv) begin
        rtlzz_pipe_11_s1 <= s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:30:27-30:62
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_128_C.logic.cpp:4:1-4:8
        end
    end
endmodule
