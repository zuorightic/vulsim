`timescale 1ns/1ps

module DOT2_64_A(
    input logic iv, // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:7:1-7:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:9:1-9:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:11:1-11:10
    input logic [63:0] d, // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:13:1-13:10
    output logic [128:0] y // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:23:5-23:14
);

    logic [127:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:18:27-18:32; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:9:1-9:10
    logic [127:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:19:28-19:33; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:13:1-13:10
    logic [128:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:22:23-22:62; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:20:25-20:44
    logic [127:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [127:0] arith_original_14; // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:18:27-18:32; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:9:1-9:10
    logic [127:0] arith_original_15; // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:19:28-19:33; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:13:1-13:10


    assign s8_norm_mul_0_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_0_v0 + s8_norm_mul_1_v0); // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:22:23-22:62; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:20:25-20:44
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:23:5-23:14
    assign __beopt_width_14 = ({64'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({64'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({64'h0, c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({64'h0, d}); // decl: <none>; prim: <none>
    assign arith_original_14 = 128'(($unsigned(128'($unsigned(__beopt_width_14))) * $unsigned(128'($unsigned(__beopt_width_15))))); // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:18:27-18:32; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:9:1-9:10
    assign arith_original_15 = 128'(($unsigned(128'($unsigned(__beopt_width_16))) * $unsigned(128'($unsigned(__beopt_width_17))))); // decl: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:19:28-19:33; prim: /home/zyrv/vulsim/DOT2_64_A.logic.cpp:13:1-13:10
endmodule
