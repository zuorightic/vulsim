`timescale 1ns/1ps

module DOT2_16_A(
    input logic iv, // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:4:1-4:11
    input logic [15:0] a, // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:7:1-7:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:9:1-9:10
    input logic [15:0] c, // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:11:1-11:10
    input logic [15:0] d, // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:13:1-13:10
    output logic [32:0] y // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:23:5-23:14
);

    logic [31:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:9:1-9:10
    logic [31:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:13:1-13:10
    logic [32:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:20:24-20:42
    logic [31:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [31:0] arith_original_14; // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:9:1-9:10
    logic [31:0] arith_original_15; // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:13:1-13:10


    assign s8_norm_mul_0_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_0_v0 + s8_norm_mul_1_v0); // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:20:24-20:42
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:23:5-23:14
    assign __beopt_width_14 = ({16'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({16'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({16'h0, c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({16'h0, d}); // decl: <none>; prim: <none>
    assign arith_original_14 = 32'(($unsigned(32'($unsigned(__beopt_width_14))) * $unsigned(32'($unsigned(__beopt_width_15))))); // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:9:1-9:10
    assign arith_original_15 = 32'(($unsigned(32'($unsigned(__beopt_width_16))) * $unsigned(32'($unsigned(__beopt_width_17))))); // decl: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_16_A.logic.cpp:13:1-13:10
endmodule
