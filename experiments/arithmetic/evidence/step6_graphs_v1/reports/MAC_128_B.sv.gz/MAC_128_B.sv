`timescale 1ns/1ps

module MAC_128_B(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:7:1-7:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:9:1-9:11
    input logic [255:0] c, // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:11:1-11:11
    output logic [255:0] y, // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:18:5-18:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:9:1-9:11
    logic [255:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56
    logic [127:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:7:1-7:11
    logic [127:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:9:1-9:11
    logic [255:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [255:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:9:1-9:11
    logic [255:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + c); // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:7:1-7:11
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:9:1-9:11
    assign __beopt_width_12 = ({128'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({128'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = 256'(($unsigned(256'($unsigned(__beopt_width_12))) * $unsigned(256'($unsigned(__beopt_width_13))))); // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:9:1-9:11
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 256'hc000000000000002000000000000003900000000000000d60000000000000b2e;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:17:23-17:56
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_128_B.logic.cpp:4:1-4:8
        end
    end
endmodule
