`timescale 1ns/1ps

module UDR_128_A(
    input logic iv, // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:7:1-7:11
    input logic [127:0] d, // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:9:1-9:11
    output logic [127:0] q, // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:25:5-25:18
    output logic [127:0] r // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:26:5-26:18
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:18:29-18:43
    logic [127:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:20:32-20:65; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:18:5-18:44
    logic [127:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:21:31-21:49; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:21:31-21:49
    logic [127:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:22:31-22:49; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:22:31-22:49
    logic [127:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:23:27-23:73; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:18:5-18:44
    logic [127:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:24:27-24:62; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:24:27-24:62
    logic [127:0] arith_original_12; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:21:31-21:49; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:21:31-21:49
    logic [127:0] arith_original_13; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:22:31-22:49; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:22:31-22:49


    assign s8_norm_cmp_4_v0 = (d == 128'h0); // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:18:29-18:43
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 128'h1 : d); // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:20:32-20:65; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:18:5-18:44
    assign s8_norm_udivmod_6_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_13; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (s8_norm_cmp_4_v0 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:23:27-23:73; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:18:5-18:44
    assign s8_norm_mux_9_v0 = (s8_norm_cmp_4_v0 ? a : s8_norm_udivmod_7_v0); // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:24:27-24:62; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:24:27-24:62
    assign ov = iv; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:25:5-25:18
    assign r = s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:26:5-26:18
    assign arith_original_12 = (a / s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:21:31-21:49; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:21:31-21:49
    assign arith_original_13 = (a % s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/UDR_128_A.logic.cpp:22:31-22:49; prim: /home/zyrv/vulsim/UDR_128_A.logic.cpp:22:31-22:49
endmodule
