`timescale 1ns/1ps

module DIVSEL_8_A(
    input logic iv, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:7:1-7:9
    input logic [7:0] d, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:9:1-9:9
    input logic [7:0] bias, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:11:1-11:12; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:11:1-11:12
    input logic [7:0] bypass, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:13:1-13:14; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:13:1-13:14
    input logic sel, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:15:1-15:9
    output logic [7:0] y, // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:17:1-17:9; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:33:5-33:17
    output logic [7:0] r // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:19:1-19:9; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:34:5-34:18
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:24:27-24:39
    logic [7:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:26:30-26:63; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:24:5-24:40
    logic [7:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:27:29-27:47
    logic [7:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:28:29-28:47
    logic [7:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:29:25-29:71; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:24:5-24:40
    logic [7:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:30:25-30:60; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:30:25-30:60
    logic [7:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:31:26-31:58; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:31:26-31:58
    logic [7:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:32:24-32:49; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:32:24-32:49
    logic [7:0] arith_original_17; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:27:29-27:47
    logic [7:0] arith_original_18; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:28:29-28:47


    assign s8_norm_cmp_4_v0 = (d == 8'h0); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:24:27-24:39
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 8'h1 : d); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:26:30-26:63; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:24:5-24:40
    assign s8_norm_udivmod_6_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (s8_norm_cmp_4_v0 ? 8'hff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:29:25-29:71; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:24:5-24:40
    assign s8_norm_mux_9_v0 = (s8_norm_cmp_4_v0 ? a : s8_norm_udivmod_7_v0); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:30:25-30:60; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:30:25-30:60
    assign s8_norm_add_10_v0 = (s8_norm_mux_8_v0 + bias); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:31:26-31:58; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:31:26-31:58
    assign s8_norm_mux_11_v0 = (sel ? s8_norm_add_10_v0 : bypass); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:32:24-32:49; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:32:24-32:49
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:17:1-17:9; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:33:5-33:17
    assign r = s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:19:1-19:9; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:34:5-34:18
    assign arith_original_17 = (a / s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:27:29-27:47; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:27:29-27:47
    assign arith_original_18 = (a % s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:28:29-28:47; prim: /home/zyrv/vulsim/DIVSEL_8_A.logic.cpp:28:29-28:47
endmodule
