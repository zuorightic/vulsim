`timescale 1ns/1ps

module H_D_64_C(
    input logic iv, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:7:1-7:10
    input logic [63:0] d, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:9:1-9:10
    input logic [63:0] e, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:11:1-11:10
    output logic [63:0] q, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:38:5-38:19
    output logic [63:0] r1, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:39:5-39:19
    output logic [63:0] r2, // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:40:5-40:20
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46
    logic s8_norm_cmp_5_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48
    logic [63:0] s8_norm_mux_6_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64
    logic [63:0] s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67
    logic [63:0] s8_norm_udivmod_8_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:30:30-30:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:30:30-30:48
    logic [63:0] s8_norm_udivmod_9_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:31:30-31:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:31:30-31:48
    logic [63:0] s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:32:26-32:72; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:22:5-22:42
    logic [63:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61
    logic [63:0] s8_norm_udivmod_12_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:34:31-34:58; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:34:31-34:58
    logic [63:0] s8_norm_udivmod_13_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:35:31-35:58; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:35:31-35:58
    logic [63:0] s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:36:27-36:76; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:25:5-25:43
    logic [63:0] s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:37:27-37:72; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:37:27-37:72
    logic [63:0] arith_original_20; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:30:30-30:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:30:30-30:48
    logic [63:0] arith_original_21; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:31:30-31:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:31:30-31:48
    logic [63:0] arith_original_22; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:34:31-34:58; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:34:31-34:58
    logic [63:0] arith_original_23; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:35:31-35:58; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:35:31-35:58
    logic [63:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:7:1-7:10
    logic rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46
    logic rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48
    logic rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48
    logic [63:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64
    logic [63:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67
    logic [63:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67
    logic [63:0] rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:32:26-32:72; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:22:5-22:42
    logic [63:0] rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_4_v0 = (d == 64'h0); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46
    assign s8_norm_cmp_5_v0 = (e == 64'h0); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48
    assign s8_norm_mux_6_v0 = (s8_norm_cmp_4_v0 ? 64'h1 : d); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64
    assign s8_norm_mux_7_v0 = (s8_norm_cmp_5_v0 ? 64'h1 : e); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67
    assign s8_norm_udivmod_8_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_9_v0 = arith_original_21; // decl: <none>; prim: <none>
    assign s8_norm_mux_10_v0 = (rtlzz_pipe_4_s1 ? 64'hffffffffffffffff : s8_norm_udivmod_8_v0); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:32:26-32:72; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:22:5-22:42
    assign s8_norm_mux_11_v0 = (rtlzz_pipe_4_s1 ? rtlzz_pipe_1_s1 : s8_norm_udivmod_9_v0); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61
    assign s8_norm_udivmod_12_v0 = arith_original_22; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_13_v0 = arith_original_23; // decl: <none>; prim: <none>
    assign s8_norm_mux_14_v0 = (rtlzz_pipe_5_s2 ? 64'hffffffffffffffff : s8_norm_udivmod_12_v0); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:36:27-36:76; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:25:5-25:43
    assign s8_norm_mux_15_v0 = (rtlzz_pipe_5_s2 ? rtlzz_pipe_10_s2 : s8_norm_udivmod_13_v0); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:37:27-37:72; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:37:27-37:72
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:38:5-38:19
    assign r1 = rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:39:5-39:19
    assign r2 = s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:40:5-40:20
    assign arith_original_20 = (rtlzz_pipe_1_s1 / rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:30:30-30:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:30:30-30:48
    assign arith_original_21 = (rtlzz_pipe_1_s1 % rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:31:30-31:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:31:30-31:48
    assign arith_original_22 = (rtlzz_pipe_10_s2 / rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:34:31-34:58; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:34:31-34:58
    assign arith_original_23 = (rtlzz_pipe_10_s2 % rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:35:31-35:58; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:35:31-35:58
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 64'h8000000000000035;
            rtlzz_pipe_4_s1 <= 1'h1;
            rtlzz_pipe_5_s1 <= 1'h1;
            rtlzz_pipe_5_s2 <= 1'h1;
            rtlzz_pipe_6_s1 <= 64'h1;
            rtlzz_pipe_7_s1 <= 64'h1;
            rtlzz_pipe_7_s2 <= 64'h1;
            rtlzz_pipe_10_s2 <= 64'hffffffffffffffff;
            rtlzz_pipe_11_s2 <= 64'h8000000000000035;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:26:29-26:46
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_cmp_5_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:27:30-27:48
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_mux_6_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:28:31-28:64
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:29:32-29:67
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:32:26-32:72; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:22:5-22:42
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:33:26-33:61
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_64_C.logic.cpp:4:1-4:8
        end
    end
endmodule
