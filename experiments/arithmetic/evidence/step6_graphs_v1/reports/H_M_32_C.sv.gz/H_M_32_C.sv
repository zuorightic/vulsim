`timescale 1ns/1ps

module H_M_32_C(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:11
    input logic [31:0] a, // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:7:1-7:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:9:1-9:10
    input logic [31:0] c, // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:11:1-11:10
    input logic sel, // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:13:1-13:9
    output logic [31:0] y, // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:22:5-22:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [31:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:18:22-18:35
    logic [31:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:20:26-20:31
    logic [31:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:21:22-21:62
    logic [31:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:20:26-20:31
    logic [7:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [39:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [55:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [40:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [56:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [41:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [49:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [57:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [65:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [50:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [66:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [67:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:18:22-18:35
    logic [24:0] rtlzz_pipe_76_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_79_s1; // decl: <none>; prim: <none>
    logic [32:0] rtlzz_pipe_82_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_85_s1; // decl: <none>; prim: <none>
    logic [40:0] rtlzz_pipe_88_s1; // decl: <none>; prim: <none>
    logic [56:0] rtlzz_pipe_91_s1; // decl: <none>; prim: <none>
    logic [48:0] rtlzz_pipe_94_s1; // decl: <none>; prim: <none>
    logic [64:0] rtlzz_pipe_97_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:8


    assign s8_norm_mux_1_v0 = (sel ? c : 32'h0); // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:18:22-18:35
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + rtlzz_pipe_5_s1); // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:21:22-21:62
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:22:5-22:14
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 16'(($unsigned(16'($unsigned(mul_tree_10_11))) * $unsigned(16'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 16'(($unsigned(16'($unsigned(mul_tree_10_14))) * $unsigned(16'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = b[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 16'(($unsigned(16'($unsigned(mul_tree_10_18))) * $unsigned(16'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = b[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 16'(($unsigned(16'($unsigned(mul_tree_10_22))) * $unsigned(16'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 16'(($unsigned(16'($unsigned(mul_tree_10_26))) * $unsigned(16'($unsigned(mul_tree_10_27))))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = {mul_tree_10_28, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_32 = 16'(($unsigned(16'($unsigned(mul_tree_10_30))) * $unsigned(16'($unsigned(mul_tree_10_31))))); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = {mul_tree_10_32, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = b[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = 16'(($unsigned(16'($unsigned(mul_tree_10_34))) * $unsigned(16'($unsigned(mul_tree_10_35))))); // decl: <none>; prim: <none>
    assign mul_tree_10_37 = {mul_tree_10_36, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = b[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = 16'(($unsigned(16'($unsigned(mul_tree_10_38))) * $unsigned(16'($unsigned(mul_tree_10_39))))); // decl: <none>; prim: <none>
    assign mul_tree_10_41 = {mul_tree_10_40, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = a[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = 16'(($unsigned(16'($unsigned(mul_tree_10_42))) * $unsigned(16'($unsigned(mul_tree_10_43))))); // decl: <none>; prim: <none>
    assign mul_tree_10_45 = {mul_tree_10_44, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = a[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = 16'(($unsigned(16'($unsigned(mul_tree_10_46))) * $unsigned(16'($unsigned(mul_tree_10_47))))); // decl: <none>; prim: <none>
    assign mul_tree_10_49 = {mul_tree_10_48, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = a[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = b[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_52 = 16'(($unsigned(16'($unsigned(mul_tree_10_50))) * $unsigned(16'($unsigned(mul_tree_10_51))))); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = {mul_tree_10_52, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = a[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = b[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 16'(($unsigned(16'($unsigned(mul_tree_10_54))) * $unsigned(16'($unsigned(mul_tree_10_55))))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = {mul_tree_10_56, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = a[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_60 = 16'(($unsigned(16'($unsigned(mul_tree_10_58))) * $unsigned(16'($unsigned(mul_tree_10_59))))); // decl: <none>; prim: <none>
    assign mul_tree_10_61 = {mul_tree_10_60, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = a[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_64 = 16'(($unsigned(16'($unsigned(mul_tree_10_62))) * $unsigned(16'($unsigned(mul_tree_10_63))))); // decl: <none>; prim: <none>
    assign mul_tree_10_65 = {mul_tree_10_64, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = a[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = b[23:16]; // decl: <none>; prim: <none>
    assign mul_tree_10_68 = 16'(($unsigned(16'($unsigned(mul_tree_10_66))) * $unsigned(16'($unsigned(mul_tree_10_67))))); // decl: <none>; prim: <none>
    assign mul_tree_10_69 = {mul_tree_10_68, 40'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = a[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = b[31:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = 16'(($unsigned(16'($unsigned(mul_tree_10_70))) * $unsigned(16'($unsigned(mul_tree_10_71))))); // decl: <none>; prim: <none>
    assign mul_tree_10_73 = {mul_tree_10_72, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({9'h0, mul_tree_10_13}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, mul_tree_10_17}); // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 25'((mul_tree_10_74 + mul_tree_10_75 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = ({9'h0, mul_tree_10_21}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, mul_tree_10_25}); // decl: <none>; prim: <none>
    assign mul_tree_10_79 = 41'((mul_tree_10_77 + mul_tree_10_78 + ({40'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_80 = ({9'h0, mul_tree_10_29}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, mul_tree_10_33}); // decl: <none>; prim: <none>
    assign mul_tree_10_82 = 33'((mul_tree_10_80 + mul_tree_10_81 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_83 = ({9'h0, mul_tree_10_37}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, mul_tree_10_41}); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = 49'((mul_tree_10_83 + mul_tree_10_84 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_86 = ({9'h0, mul_tree_10_45}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, mul_tree_10_49}); // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 41'((mul_tree_10_86 + mul_tree_10_87 + ({40'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = ({9'h0, mul_tree_10_53}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, mul_tree_10_57}); // decl: <none>; prim: <none>
    assign mul_tree_10_91 = 57'((mul_tree_10_89 + mul_tree_10_90 + ({56'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_92 = ({9'h0, mul_tree_10_61}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, mul_tree_10_65}); // decl: <none>; prim: <none>
    assign mul_tree_10_94 = 49'((mul_tree_10_92 + mul_tree_10_93 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_95 = ({9'h0, mul_tree_10_69}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, mul_tree_10_73}); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = 65'((mul_tree_10_95 + mul_tree_10_96 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_98 = ({17'h0, rtlzz_pipe_76_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, rtlzz_pipe_79_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 42'((mul_tree_10_98 + mul_tree_10_99 + ({41'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({17'h0, rtlzz_pipe_82_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, rtlzz_pipe_85_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_103 = 50'((mul_tree_10_101 + mul_tree_10_102 + ({49'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({17'h0, rtlzz_pipe_88_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, rtlzz_pipe_91_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_106 = 58'((mul_tree_10_104 + mul_tree_10_105 + ({57'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({17'h0, rtlzz_pipe_94_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, rtlzz_pipe_97_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = 66'((mul_tree_10_107 + mul_tree_10_108 + ({65'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({9'h0, mul_tree_10_100}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, mul_tree_10_103}); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = 51'((mul_tree_10_110 + mul_tree_10_111 + ({50'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({9'h0, mul_tree_10_106}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = 67'((mul_tree_10_113 + mul_tree_10_114 + ({66'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({17'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = 68'((mul_tree_10_116 + mul_tree_10_117 + ({67'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_tree_10_118[31:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 32'h80000035;
            rtlzz_pipe_76_s1 <= 25'haf9;
            rtlzz_pipe_79_s1 <= 41'h1a80000000;
            rtlzz_pipe_82_s1 <= 33'h0;
            rtlzz_pipe_85_s1 <= 49'h0;
            rtlzz_pipe_88_s1 <= 41'h0;
            rtlzz_pipe_91_s1 <= 57'h0;
            rtlzz_pipe_94_s1 <= 49'h1a80000000;
            rtlzz_pipe_97_s1 <= 65'h4000000000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:18:22-18:35
        end
        if (iv) begin
        rtlzz_pipe_76_s1 <= mul_tree_10_76; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_79_s1 <= mul_tree_10_79; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_82_s1 <= mul_tree_10_82; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_85_s1 <= mul_tree_10_85; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_88_s1 <= mul_tree_10_88; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_91_s1 <= mul_tree_10_91; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_94_s1 <= mul_tree_10_94; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_97_s1 <= mul_tree_10_97; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_32_C.logic.cpp:4:1-4:8
        end
    end
endmodule
