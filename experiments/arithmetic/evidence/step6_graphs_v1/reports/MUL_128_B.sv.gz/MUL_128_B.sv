`timescale 1ns/1ps

module MUL_128_B(
    input logic iv, // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:7:1-7:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
    output logic [255:0] y, // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:15:5-15:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [255:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:14:27-14:32; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
    logic [127:0] __beopt_width_8; // decl: <none>; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:7:1-7:11
    logic [127:0] __beopt_width_9; // decl: <none>; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
    logic [255:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [255:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [255:0] arith_original_10; // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:14:27-14:32; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
    logic [255:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:14:27-14:32; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:15:5-15:18
    assign __beopt_width_8 = a; // decl: <none>; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:7:1-7:11
    assign __beopt_width_9 = b; // decl: <none>; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
    assign __beopt_width_10 = ({128'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({128'h0, __beopt_width_9}); // decl: <none>; prim: <none>
    assign arith_original_10 = 256'(($unsigned(256'($unsigned(__beopt_width_10))) * $unsigned(256'($unsigned(__beopt_width_11))))); // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:14:27-14:32; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 256'h4000000000000002000000000000003900000000000000d40000000000000af9;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:14:27-14:32; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:9:1-9:11
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_128_B.logic.cpp:4:1-4:8
        end
    end
endmodule
