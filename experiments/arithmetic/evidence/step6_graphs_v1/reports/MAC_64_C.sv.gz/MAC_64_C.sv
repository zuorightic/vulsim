`timescale 1ns/1ps

module MAC_64_C(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:7:1-7:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:9:1-9:10
    input logic [127:0] c, // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:11:1-11:11
    output logic [127:0] y, // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:18:5-18:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [127:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:9:1-9:10
    logic [127:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:17:23-17:56
    logic [63:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:7:1-7:10
    logic [63:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:9:1-9:10
    logic [127:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [127:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:9:1-9:10
    logic [15:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [63:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [79:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [111:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [64:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [80:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [112:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [128:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [81:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [113:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [129:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [130:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [131:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [127:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:11:1-11:11
    logic [31:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [63:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [79:0] rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [111:0] rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
    logic [127:0] rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + rtlzz_pipe_3_s1); // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:17:23-17:56
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({64'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({64'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_121; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = __beopt_width_12[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = __beopt_width_13[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 32'(($unsigned(32'($unsigned(mul_tree_12_13))) * $unsigned(32'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = __beopt_width_12[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = __beopt_width_13[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 32'(($unsigned(32'($unsigned(mul_tree_12_16))) * $unsigned(32'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = __beopt_width_12[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = __beopt_width_13[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 32'(($unsigned(32'($unsigned(mul_tree_12_20))) * $unsigned(32'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = __beopt_width_12[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = __beopt_width_13[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 32'(($unsigned(32'($unsigned(mul_tree_12_24))) * $unsigned(32'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = __beopt_width_12[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = __beopt_width_13[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 32'(($unsigned(32'($unsigned(mul_tree_12_28))) * $unsigned(32'($unsigned(mul_tree_12_29))))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = {mul_tree_12_30, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = __beopt_width_12[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = __beopt_width_13[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_34 = 32'(($unsigned(32'($unsigned(mul_tree_12_32))) * $unsigned(32'($unsigned(mul_tree_12_33))))); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = {mul_tree_12_34, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = __beopt_width_12[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = __beopt_width_13[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_38 = 32'(($unsigned(32'($unsigned(mul_tree_12_36))) * $unsigned(32'($unsigned(mul_tree_12_37))))); // decl: <none>; prim: <none>
    assign mul_tree_12_39 = {mul_tree_12_38, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = __beopt_width_12[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = __beopt_width_13[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_42 = 32'(($unsigned(32'($unsigned(mul_tree_12_40))) * $unsigned(32'($unsigned(mul_tree_12_41))))); // decl: <none>; prim: <none>
    assign mul_tree_12_43 = {mul_tree_12_42, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = __beopt_width_12[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = __beopt_width_13[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_46 = 32'(($unsigned(32'($unsigned(mul_tree_12_44))) * $unsigned(32'($unsigned(mul_tree_12_45))))); // decl: <none>; prim: <none>
    assign mul_tree_12_47 = {mul_tree_12_46, 32'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = __beopt_width_12[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = __beopt_width_13[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_50 = 32'(($unsigned(32'($unsigned(mul_tree_12_48))) * $unsigned(32'($unsigned(mul_tree_12_49))))); // decl: <none>; prim: <none>
    assign mul_tree_12_51 = {mul_tree_12_50, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = __beopt_width_12[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = __beopt_width_13[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_54 = 32'(($unsigned(32'($unsigned(mul_tree_12_52))) * $unsigned(32'($unsigned(mul_tree_12_53))))); // decl: <none>; prim: <none>
    assign mul_tree_12_55 = {mul_tree_12_54, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = __beopt_width_12[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = __beopt_width_13[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_58 = 32'(($unsigned(32'($unsigned(mul_tree_12_56))) * $unsigned(32'($unsigned(mul_tree_12_57))))); // decl: <none>; prim: <none>
    assign mul_tree_12_59 = {mul_tree_12_58, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = __beopt_width_12[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = __beopt_width_13[15:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_62 = 32'(($unsigned(32'($unsigned(mul_tree_12_60))) * $unsigned(32'($unsigned(mul_tree_12_61))))); // decl: <none>; prim: <none>
    assign mul_tree_12_63 = {mul_tree_12_62, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = __beopt_width_12[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = __beopt_width_13[31:16]; // decl: <none>; prim: <none>
    assign mul_tree_12_66 = 32'(($unsigned(32'($unsigned(mul_tree_12_64))) * $unsigned(32'($unsigned(mul_tree_12_65))))); // decl: <none>; prim: <none>
    assign mul_tree_12_67 = {mul_tree_12_66, 64'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = __beopt_width_12[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = __beopt_width_13[47:32]; // decl: <none>; prim: <none>
    assign mul_tree_12_70 = 32'(($unsigned(32'($unsigned(mul_tree_12_68))) * $unsigned(32'($unsigned(mul_tree_12_69))))); // decl: <none>; prim: <none>
    assign mul_tree_12_71 = {mul_tree_12_70, 80'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = __beopt_width_12[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = __beopt_width_13[63:48]; // decl: <none>; prim: <none>
    assign mul_tree_12_74 = 32'(($unsigned(32'($unsigned(mul_tree_12_72))) * $unsigned(32'($unsigned(mul_tree_12_73))))); // decl: <none>; prim: <none>
    assign mul_tree_12_75 = {mul_tree_12_74, 96'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = ({17'h0, rtlzz_pipe_15_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_77 = ({1'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_78 = 49'((mul_tree_12_76 + mul_tree_12_77 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_79 = ({17'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_80 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_81 = 81'((mul_tree_12_79 + mul_tree_12_80 + ({80'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_82 = ({17'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_83 = ({1'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_84 = 65'((mul_tree_12_82 + mul_tree_12_83 + ({64'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_85 = ({17'h0, rtlzz_pipe_39_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_86 = ({1'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_87 = 97'((mul_tree_12_85 + mul_tree_12_86 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_88 = ({17'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_89 = ({1'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_90 = 81'((mul_tree_12_88 + mul_tree_12_89 + ({80'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_91 = ({17'h0, rtlzz_pipe_55_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_92 = ({1'h0, rtlzz_pipe_59_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_93 = 113'((mul_tree_12_91 + mul_tree_12_92 + ({112'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_94 = ({17'h0, rtlzz_pipe_63_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_95 = ({1'h0, rtlzz_pipe_67_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_96 = 97'((mul_tree_12_94 + mul_tree_12_95 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_97 = ({17'h0, rtlzz_pipe_71_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_98 = ({1'h0, rtlzz_pipe_75_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_99 = 129'((mul_tree_12_97 + mul_tree_12_98 + ({128'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_100 = ({33'h0, mul_tree_12_78}); // decl: <none>; prim: <none>
    assign mul_tree_12_101 = ({1'h0, mul_tree_12_81}); // decl: <none>; prim: <none>
    assign mul_tree_12_102 = 82'((mul_tree_12_100 + mul_tree_12_101 + ({81'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_103 = ({33'h0, mul_tree_12_84}); // decl: <none>; prim: <none>
    assign mul_tree_12_104 = ({1'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    assign mul_tree_12_105 = 98'((mul_tree_12_103 + mul_tree_12_104 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_106 = ({33'h0, mul_tree_12_90}); // decl: <none>; prim: <none>
    assign mul_tree_12_107 = ({1'h0, mul_tree_12_93}); // decl: <none>; prim: <none>
    assign mul_tree_12_108 = 114'((mul_tree_12_106 + mul_tree_12_107 + ({113'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_109 = ({33'h0, mul_tree_12_96}); // decl: <none>; prim: <none>
    assign mul_tree_12_110 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    assign mul_tree_12_111 = 130'((mul_tree_12_109 + mul_tree_12_110 + ({129'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_112 = ({17'h0, mul_tree_12_102}); // decl: <none>; prim: <none>
    assign mul_tree_12_113 = ({1'h0, mul_tree_12_105}); // decl: <none>; prim: <none>
    assign mul_tree_12_114 = 99'((mul_tree_12_112 + mul_tree_12_113 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_115 = ({17'h0, mul_tree_12_108}); // decl: <none>; prim: <none>
    assign mul_tree_12_116 = ({1'h0, mul_tree_12_111}); // decl: <none>; prim: <none>
    assign mul_tree_12_117 = 131'((mul_tree_12_115 + mul_tree_12_116 + ({130'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_118 = ({33'h0, mul_tree_12_114}); // decl: <none>; prim: <none>
    assign mul_tree_12_119 = ({1'h0, mul_tree_12_117}); // decl: <none>; prim: <none>
    assign mul_tree_12_120 = 132'((mul_tree_12_118 + mul_tree_12_119 + ({131'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_tree_12_120[127:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 128'h80000000000000020000000000000035;
            rtlzz_pipe_15_s1 <= 32'haf9;
            rtlzz_pipe_19_s1 <= 48'h0;
            rtlzz_pipe_23_s1 <= 64'h0;
            rtlzz_pipe_27_s1 <= 80'h1a8000000000000000;
            rtlzz_pipe_31_s1 <= 48'h0;
            rtlzz_pipe_35_s1 <= 64'h0;
            rtlzz_pipe_39_s1 <= 80'h0;
            rtlzz_pipe_43_s1 <= 96'h0;
            rtlzz_pipe_47_s1 <= 64'h0;
            rtlzz_pipe_51_s1 <= 80'h0;
            rtlzz_pipe_55_s1 <= 96'h0;
            rtlzz_pipe_59_s1 <= 112'h0;
            rtlzz_pipe_63_s1 <= 80'h1a8000000000000000;
            rtlzz_pipe_67_s1 <= 96'h0;
            rtlzz_pipe_71_s1 <= 112'h0;
            rtlzz_pipe_75_s1 <= 128'h40000000000000000000000000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= c; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:11:1-11:11
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= mul_tree_12_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_12_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_12_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_12_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_12_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_12_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= mul_tree_12_39; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_12_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_12_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_12_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= mul_tree_12_55; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= mul_tree_12_59; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_63_s1 <= mul_tree_12_63; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= mul_tree_12_67; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_71_s1 <= mul_tree_12_71; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_75_s1 <= mul_tree_12_75; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_64_C.logic.cpp:4:1-4:8
        end
    end
endmodule
