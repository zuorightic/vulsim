`timescale 1ns/1ps

module DOT2_12_C(
    input logic iv, // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:11
    input logic [11:0] a, // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:7:1-7:10
    input logic [11:0] b, // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:9:1-9:10
    input logic [11:0] c, // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:11:1-11:10
    input logic [11:0] d, // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:13:1-13:10
    output logic [24:0] y, // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:23:5-23:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [23:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:9:1-9:10
    logic [23:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:13:1-13:10
    logic [24:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:20:24-20:42
    logic [23:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [23:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [23:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [23:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [23:0] arith_original_14; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:9:1-9:10
    logic [23:0] arith_original_15; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:13:1-13:10
    logic [5:0] mul_tree_14_16; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_14_17; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_18; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_14_19; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_14_20; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_21; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_14_22; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_14_23; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_14_24; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_25; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_14_26; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_14_27; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_14_28; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_29; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_30; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_14_31; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_14_32; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_14_33; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_14_34; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_14_35; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_14_36; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_14_37; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_14_38; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_14_39; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_40; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_41; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_42; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_43; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_44; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_45; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_46; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_47; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_48; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_49; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_50; // decl: <none>; prim: <none>
    logic [17:0] mul_tree_15_51; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_52; // decl: <none>; prim: <none>
    logic [5:0] mul_tree_15_53; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_54; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_55; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_56; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_57; // decl: <none>; prim: <none>
    logic [18:0] mul_tree_15_58; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_59; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_60; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_15_61; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_62; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_63; // decl: <none>; prim: <none>
    logic [25:0] mul_tree_15_64; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_65; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [11:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [17:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_0_v0 + s8_norm_mul_1_v0); // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:20:24-20:42
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:23:5-23:14
    assign __beopt_width_14 = ({12'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({12'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({12'h0, c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({12'h0, d}); // decl: <none>; prim: <none>
    assign arith_original_14 = mul_tree_14_40; // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_65; // decl: <none>; prim: <none>
    assign mul_tree_14_16 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_17 = __beopt_width_15[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_18 = 12'(($unsigned(12'($unsigned(mul_tree_14_16))) * $unsigned(12'($unsigned(mul_tree_14_17))))); // decl: <none>; prim: <none>
    assign mul_tree_14_19 = __beopt_width_14[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_20 = __beopt_width_15[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_14_21 = 12'(($unsigned(12'($unsigned(mul_tree_14_19))) * $unsigned(12'($unsigned(mul_tree_14_20))))); // decl: <none>; prim: <none>
    assign mul_tree_14_22 = {mul_tree_14_21, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_23 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_14_24 = __beopt_width_15[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_25 = 12'(($unsigned(12'($unsigned(mul_tree_14_23))) * $unsigned(12'($unsigned(mul_tree_14_24))))); // decl: <none>; prim: <none>
    assign mul_tree_14_26 = {mul_tree_14_25, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_27 = __beopt_width_14[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_14_28 = __beopt_width_15[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_14_29 = 12'(($unsigned(12'($unsigned(mul_tree_14_27))) * $unsigned(12'($unsigned(mul_tree_14_28))))); // decl: <none>; prim: <none>
    assign mul_tree_14_30 = {mul_tree_14_29, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_31 = ({7'h0, rtlzz_pipe_18_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_32 = ({1'h0, rtlzz_pipe_22_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_33 = 19'((mul_tree_14_31 + mul_tree_14_32 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_34 = ({7'h0, rtlzz_pipe_26_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_35 = ({1'h0, rtlzz_pipe_30_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_36 = 25'((mul_tree_14_34 + mul_tree_14_35 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_37 = ({7'h0, mul_tree_14_33}); // decl: <none>; prim: <none>
    assign mul_tree_14_38 = ({1'h0, mul_tree_14_36}); // decl: <none>; prim: <none>
    assign mul_tree_14_39 = 26'((mul_tree_14_37 + mul_tree_14_38 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_40 = mul_tree_14_39[23:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_41 = __beopt_width_16[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_42 = __beopt_width_17[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_43 = 12'(($unsigned(12'($unsigned(mul_tree_15_41))) * $unsigned(12'($unsigned(mul_tree_15_42))))); // decl: <none>; prim: <none>
    assign mul_tree_15_44 = __beopt_width_16[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_45 = __beopt_width_17[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_46 = 12'(($unsigned(12'($unsigned(mul_tree_15_44))) * $unsigned(12'($unsigned(mul_tree_15_45))))); // decl: <none>; prim: <none>
    assign mul_tree_15_47 = {mul_tree_15_46, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_48 = __beopt_width_16[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_49 = __beopt_width_17[5:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_50 = 12'(($unsigned(12'($unsigned(mul_tree_15_48))) * $unsigned(12'($unsigned(mul_tree_15_49))))); // decl: <none>; prim: <none>
    assign mul_tree_15_51 = {mul_tree_15_50, 6'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_52 = __beopt_width_16[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_53 = __beopt_width_17[11:6]; // decl: <none>; prim: <none>
    assign mul_tree_15_54 = 12'(($unsigned(12'($unsigned(mul_tree_15_52))) * $unsigned(12'($unsigned(mul_tree_15_53))))); // decl: <none>; prim: <none>
    assign mul_tree_15_55 = {mul_tree_15_54, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_56 = ({7'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_57 = ({1'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_58 = 19'((mul_tree_15_56 + mul_tree_15_57 + ({18'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_59 = ({7'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_60 = ({1'h0, rtlzz_pipe_55_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_61 = 25'((mul_tree_15_59 + mul_tree_15_60 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_62 = ({7'h0, mul_tree_15_58}); // decl: <none>; prim: <none>
    assign mul_tree_15_63 = ({1'h0, mul_tree_15_61}); // decl: <none>; prim: <none>
    assign mul_tree_15_64 = 26'((mul_tree_15_62 + mul_tree_15_63 + ({25'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_65 = mul_tree_15_64[23:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_18_s1 <= 12'haf9;
            rtlzz_pipe_22_s1 <= 18'h1a800;
            rtlzz_pipe_26_s1 <= 18'h1a800;
            rtlzz_pipe_30_s1 <= 24'h400000;
            rtlzz_pipe_43_s1 <= 12'h0;
            rtlzz_pipe_47_s1 <= 18'h0;
            rtlzz_pipe_51_s1 <= 18'h0;
            rtlzz_pipe_55_s1 <= 24'h0;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_18_s1 <= mul_tree_14_18; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= mul_tree_14_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= mul_tree_14_26; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_30_s1 <= mul_tree_14_30; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_15_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_15_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_15_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= mul_tree_15_55; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_12_C.logic.cpp:4:1-4:8
        end
    end
endmodule
