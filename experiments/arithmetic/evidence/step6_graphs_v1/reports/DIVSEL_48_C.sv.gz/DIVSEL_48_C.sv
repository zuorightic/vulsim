`timescale 1ns/1ps

module DIVSEL_48_C(
    input logic iv, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:11
    input logic [47:0] a, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:7:1-7:10
    input logic [47:0] d, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:9:1-9:10
    input logic [47:0] bias, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:11:1-11:13; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:11:1-11:13
    input logic [47:0] bypass, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:13:1-13:15; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:13:1-13:15
    input logic sel, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:15:1-15:9
    output logic [47:0] y, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:33:5-33:17
    output logic [47:0] r, // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:34:5-34:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:24:28-24:41
    logic [47:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:26:31-26:64; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:24:5-24:42
    logic [47:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:27:30-27:48
    logic [47:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:28:30-28:48; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:28:30-28:48
    logic [47:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:29:26-29:72; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:24:5-24:42
    logic [47:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61
    logic [47:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:31:27-31:61; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:31:27-31:61
    logic [47:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50
    logic [47:0] arith_original_17; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:27:30-27:48
    logic [47:0] arith_original_18; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:28:30-28:48; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:28:30-28:48
    logic [47:0] rtlzz_pipe_13_s1; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50
    logic [47:0] rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_4_v0 = (d == 48'h0); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:24:28-24:41
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 48'h1 : d); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:26:31-26:64; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:24:5-24:42
    assign s8_norm_udivmod_6_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (s8_norm_cmp_4_v0 ? 48'hffffffffffff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:29:26-29:72; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:24:5-24:42
    assign s8_norm_mux_9_v0 = (s8_norm_cmp_4_v0 ? a : s8_norm_udivmod_7_v0); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61
    assign s8_norm_add_10_v0 = (s8_norm_mux_8_v0 + bias); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:31:27-31:61; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:31:27-31:61
    assign s8_norm_mux_11_v0 = (sel ? s8_norm_add_10_v0 : bypass); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_13_s1; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:33:5-33:17
    assign r = rtlzz_pipe_11_s1; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:34:5-34:18
    assign arith_original_17 = (a / s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:27:30-27:48
    assign arith_original_18 = (a % s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:28:30-28:48; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:28:30-28:48
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 48'h800000000034;
            rtlzz_pipe_11_s1 <= 48'h800000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:32:25-32:50
        end
        if (iv) begin
        rtlzz_pipe_11_s1 <= s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:30:26-30:61
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_48_C.logic.cpp:4:1-4:8
        end
    end
endmodule
