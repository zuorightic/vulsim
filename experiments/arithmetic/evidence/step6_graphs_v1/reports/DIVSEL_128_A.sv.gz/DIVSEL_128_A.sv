`timescale 1ns/1ps

module DIVSEL_128_A(
    input logic iv, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:7:1-7:11
    input logic [127:0] d, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:9:1-9:11
    input logic [127:0] bias, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:11:1-11:14; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:11:1-11:14
    input logic [127:0] bypass, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:13:1-13:16; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:13:1-13:16
    input logic sel, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:15:1-15:9
    output logic [127:0] y, // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:33:5-33:17
    output logic [127:0] r // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:19:1-19:11; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:34:5-34:18
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:24:29-24:43
    logic [127:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:26:32-26:65; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:24:5-24:44
    logic [127:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:27:31-27:49; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:27:31-27:49
    logic [127:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:28:31-28:49; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:28:31-28:49
    logic [127:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:29:27-29:73; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:24:5-24:44
    logic [127:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:30:27-30:62; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:30:27-30:62
    logic [127:0] s8_norm_add_10_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:31:28-31:64; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:31:28-31:64
    logic [127:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:32:26-32:51; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:32:26-32:51
    logic [127:0] arith_original_17; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:27:31-27:49; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:27:31-27:49
    logic [127:0] arith_original_18; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:28:31-28:49; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:28:31-28:49


    assign s8_norm_cmp_4_v0 = (d == 128'h0); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:25:29-25:46; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:24:29-24:43
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 128'h1 : d); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:26:32-26:65; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:24:5-24:44
    assign s8_norm_udivmod_6_v0 = arith_original_17; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_18; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (s8_norm_cmp_4_v0 ? 128'hffffffffffffffffffffffffffffffff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:29:27-29:73; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:24:5-24:44
    assign s8_norm_mux_9_v0 = (s8_norm_cmp_4_v0 ? a : s8_norm_udivmod_7_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:30:27-30:62; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:30:27-30:62
    assign s8_norm_add_10_v0 = (s8_norm_mux_8_v0 + bias); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:31:28-31:64; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:31:28-31:64
    assign s8_norm_mux_11_v0 = (sel ? s8_norm_add_10_v0 : bypass); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:32:26-32:51; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:32:26-32:51
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:17:1-17:11; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:33:5-33:17
    assign r = s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:19:1-19:11; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:34:5-34:18
    assign arith_original_17 = (a / s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:27:31-27:49; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:27:31-27:49
    assign arith_original_18 = (a % s8_norm_mux_5_v0); // decl: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:28:31-28:49; prim: /home/zyrv/vulsim/DIVSEL_128_A.logic.cpp:28:31-28:49
endmodule
