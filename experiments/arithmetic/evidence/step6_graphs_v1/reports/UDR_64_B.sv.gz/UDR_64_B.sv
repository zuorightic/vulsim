`timescale 1ns/1ps

module UDR_64_B(
    input logic iv, // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:7:1-7:10
    input logic [63:0] d, // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:9:1-9:10
    output logic [63:0] q, // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:25:5-25:18
    output logic [63:0] r, // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:26:5-26:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_2_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46
    logic [63:0] s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64
    logic [63:0] s8_norm_udivmod_4_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:21:30-21:48; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:21:30-21:48
    logic [63:0] s8_norm_udivmod_5_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:22:30-22:48; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:22:30-22:48
    logic [63:0] s8_norm_mux_6_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:23:26-23:72; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:18:5-18:42
    logic [63:0] s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:24:26-24:61; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:24:26-24:61
    logic [63:0] arith_original_12; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:21:30-21:48; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:21:30-21:48
    logic [63:0] arith_original_13; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:22:30-22:48; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:22:30-22:48
    logic [63:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:7:1-7:10
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46
    logic [63:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:8


    assign s8_norm_cmp_2_v0 = (d == 64'h0); // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46
    assign s8_norm_mux_3_v0 = (s8_norm_cmp_2_v0 ? 64'h1 : d); // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64
    assign s8_norm_udivmod_4_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_5_v0 = arith_original_13; // decl: <none>; prim: <none>
    assign s8_norm_mux_6_v0 = (rtlzz_pipe_3_s1 ? 64'hffffffffffffffff : s8_norm_udivmod_4_v0); // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:23:26-23:72; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:18:5-18:42
    assign s8_norm_mux_7_v0 = (rtlzz_pipe_3_s1 ? rtlzz_pipe_1_s1 : s8_norm_udivmod_5_v0); // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:24:26-24:61; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:24:26-24:61
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_6_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:25:5-25:18
    assign r = s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:26:5-26:18
    assign arith_original_12 = (rtlzz_pipe_1_s1 / rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:21:30-21:48; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:21:30-21:48
    assign arith_original_13 = (rtlzz_pipe_1_s1 % rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:22:30-22:48; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:22:30-22:48
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 64'h8000000000000035;
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_4_s1 <= 64'h1;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:7:1-7:10
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_2_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:19:29-19:46
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:20:31-20:64
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_64_B.logic.cpp:4:1-4:8
        end
    end
endmodule
