`timescale 1ns/1ps

module DOT2_48_C(
    input logic iv, // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:11
    input logic [47:0] a, // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:7:1-7:10
    input logic [47:0] b, // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:9:1-9:10
    input logic [47:0] c, // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:11:1-11:10
    input logic [47:0] d, // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:13:1-13:10
    output logic [96:0] y, // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:23:5-23:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [95:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:9:1-9:10
    logic [95:0] s8_norm_mul_1_v0; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:13:1-13:10
    logic [96:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:20:24-20:42
    logic [95:0] __beopt_width_14; // decl: <none>; prim: <none>
    logic [95:0] __beopt_width_15; // decl: <none>; prim: <none>
    logic [95:0] __beopt_width_16; // decl: <none>; prim: <none>
    logic [95:0] __beopt_width_17; // decl: <none>; prim: <none>
    logic [95:0] arith_original_14; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:18:26-18:31; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:9:1-9:10
    logic [95:0] arith_original_15; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:19:27-19:32; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:13:1-13:10
    logic [11:0] mul_tree_14_16; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_17; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_18; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_19; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_20; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_21; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_14_22; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_23; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_24; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_25; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_14_26; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_27; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_28; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_29; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_14_30; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_31; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_32; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_33; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_14_34; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_35; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_36; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_37; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_14_38; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_39; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_40; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_41; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_14_42; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_43; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_44; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_45; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_14_46; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_47; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_48; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_49; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_14_50; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_51; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_52; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_53; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_14_54; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_55; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_56; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_57; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_14_58; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_59; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_60; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_61; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_14_62; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_63; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_64; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_65; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_14_66; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_67; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_68; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_69; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_14_70; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_71; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_72; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_73; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_14_74; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_75; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_14_76; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_14_77; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_14_78; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_14_79; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_14_80; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_14_81; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_14_82; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_14_83; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_14_84; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_14_85; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_14_86; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_14_87; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_14_88; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_14_89; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_14_90; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_14_91; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_14_92; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_14_93; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_14_94; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_14_95; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_14_96; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_14_97; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_14_98; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_14_99; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_100; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_101; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_14_102; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_14_103; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_14_104; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_14_105; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_14_106; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_14_107; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_14_108; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_14_109; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_14_110; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_14_111; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_14_112; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_14_113; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_14_114; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_14_115; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_14_116; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_14_117; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_14_118; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_14_119; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_14_120; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_14_121; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_14_122; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_14_123; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_14_124; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_125; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_126; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_127; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_128; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_129; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_130; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_131; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_132; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_133; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_134; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_135; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_136; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_137; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_138; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_15_139; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_140; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_141; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_142; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_15_143; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_144; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_145; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_146; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_147; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_148; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_149; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_150; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_15_151; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_152; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_153; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_154; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_15_155; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_156; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_157; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_158; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_15_159; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_160; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_161; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_162; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_15_163; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_164; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_165; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_166; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_15_167; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_168; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_169; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_170; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_15_171; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_172; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_173; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_174; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_15_175; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_176; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_177; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_178; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_15_179; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_180; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_181; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_182; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_15_183; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_184; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_15_185; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_15_186; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_187; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_15_188; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_15_189; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_15_190; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_15_191; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_15_192; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_15_193; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_15_194; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_15_195; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_15_196; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_197; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_198; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_199; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_15_200; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_15_201; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_15_202; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_15_203; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_15_204; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_15_205; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_206; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_207; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_15_208; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_209; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_210; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_15_211; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_15_212; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_15_213; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_15_214; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_15_215; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_15_216; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_15_217; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_15_218; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_15_219; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_15_220; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_15_221; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_15_222; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_15_223; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_15_224; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_15_225; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_15_226; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_15_227; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_15_228; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_15_229; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_15_230; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_15_231; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_15_232; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_15_233; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_18_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_22_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_26_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_30_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_34_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_38_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_42_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_46_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_50_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_54_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_58_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_62_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_66_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_70_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_74_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_78_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_127_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_131_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_135_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_139_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_143_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_147_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_151_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_155_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_159_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_163_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_167_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_171_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_175_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_179_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_183_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_187_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_14; // decl: <none>; prim: <none>
    assign s8_norm_mul_1_v0 = arith_original_15; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_0_v0 + s8_norm_mul_1_v0); // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:22:22-22:59; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:20:24-20:42
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:23:5-23:14
    assign __beopt_width_14 = ({48'h0, a}); // decl: <none>; prim: <none>
    assign __beopt_width_15 = ({48'h0, b}); // decl: <none>; prim: <none>
    assign __beopt_width_16 = ({48'h0, c}); // decl: <none>; prim: <none>
    assign __beopt_width_17 = ({48'h0, d}); // decl: <none>; prim: <none>
    assign arith_original_14 = mul_tree_14_124; // decl: <none>; prim: <none>
    assign arith_original_15 = mul_tree_15_233; // decl: <none>; prim: <none>
    assign mul_tree_14_16 = __beopt_width_14[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_17 = __beopt_width_15[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_18 = 24'(($unsigned(24'($unsigned(mul_tree_14_16))) * $unsigned(24'($unsigned(mul_tree_14_17))))); // decl: <none>; prim: <none>
    assign mul_tree_14_19 = __beopt_width_14[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_20 = __beopt_width_15[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_21 = 24'(($unsigned(24'($unsigned(mul_tree_14_19))) * $unsigned(24'($unsigned(mul_tree_14_20))))); // decl: <none>; prim: <none>
    assign mul_tree_14_22 = {mul_tree_14_21, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_23 = __beopt_width_14[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_24 = __beopt_width_15[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_25 = 24'(($unsigned(24'($unsigned(mul_tree_14_23))) * $unsigned(24'($unsigned(mul_tree_14_24))))); // decl: <none>; prim: <none>
    assign mul_tree_14_26 = {mul_tree_14_25, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_27 = __beopt_width_14[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_28 = __beopt_width_15[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_29 = 24'(($unsigned(24'($unsigned(mul_tree_14_27))) * $unsigned(24'($unsigned(mul_tree_14_28))))); // decl: <none>; prim: <none>
    assign mul_tree_14_30 = {mul_tree_14_29, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_31 = __beopt_width_14[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_32 = __beopt_width_15[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_33 = 24'(($unsigned(24'($unsigned(mul_tree_14_31))) * $unsigned(24'($unsigned(mul_tree_14_32))))); // decl: <none>; prim: <none>
    assign mul_tree_14_34 = {mul_tree_14_33, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_35 = __beopt_width_14[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_36 = __beopt_width_15[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_37 = 24'(($unsigned(24'($unsigned(mul_tree_14_35))) * $unsigned(24'($unsigned(mul_tree_14_36))))); // decl: <none>; prim: <none>
    assign mul_tree_14_38 = {mul_tree_14_37, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_39 = __beopt_width_14[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_40 = __beopt_width_15[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_41 = 24'(($unsigned(24'($unsigned(mul_tree_14_39))) * $unsigned(24'($unsigned(mul_tree_14_40))))); // decl: <none>; prim: <none>
    assign mul_tree_14_42 = {mul_tree_14_41, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_43 = __beopt_width_14[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_44 = __beopt_width_15[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_45 = 24'(($unsigned(24'($unsigned(mul_tree_14_43))) * $unsigned(24'($unsigned(mul_tree_14_44))))); // decl: <none>; prim: <none>
    assign mul_tree_14_46 = {mul_tree_14_45, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_47 = __beopt_width_14[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_48 = __beopt_width_15[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_49 = 24'(($unsigned(24'($unsigned(mul_tree_14_47))) * $unsigned(24'($unsigned(mul_tree_14_48))))); // decl: <none>; prim: <none>
    assign mul_tree_14_50 = {mul_tree_14_49, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_51 = __beopt_width_14[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_52 = __beopt_width_15[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_53 = 24'(($unsigned(24'($unsigned(mul_tree_14_51))) * $unsigned(24'($unsigned(mul_tree_14_52))))); // decl: <none>; prim: <none>
    assign mul_tree_14_54 = {mul_tree_14_53, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_55 = __beopt_width_14[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_56 = __beopt_width_15[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_57 = 24'(($unsigned(24'($unsigned(mul_tree_14_55))) * $unsigned(24'($unsigned(mul_tree_14_56))))); // decl: <none>; prim: <none>
    assign mul_tree_14_58 = {mul_tree_14_57, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_59 = __beopt_width_14[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_60 = __beopt_width_15[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_61 = 24'(($unsigned(24'($unsigned(mul_tree_14_59))) * $unsigned(24'($unsigned(mul_tree_14_60))))); // decl: <none>; prim: <none>
    assign mul_tree_14_62 = {mul_tree_14_61, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_63 = __beopt_width_14[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_64 = __beopt_width_15[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_14_65 = 24'(($unsigned(24'($unsigned(mul_tree_14_63))) * $unsigned(24'($unsigned(mul_tree_14_64))))); // decl: <none>; prim: <none>
    assign mul_tree_14_66 = {mul_tree_14_65, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_67 = __beopt_width_14[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_68 = __beopt_width_15[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_14_69 = 24'(($unsigned(24'($unsigned(mul_tree_14_67))) * $unsigned(24'($unsigned(mul_tree_14_68))))); // decl: <none>; prim: <none>
    assign mul_tree_14_70 = {mul_tree_14_69, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_71 = __beopt_width_14[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_72 = __beopt_width_15[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_14_73 = 24'(($unsigned(24'($unsigned(mul_tree_14_71))) * $unsigned(24'($unsigned(mul_tree_14_72))))); // decl: <none>; prim: <none>
    assign mul_tree_14_74 = {mul_tree_14_73, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_75 = __beopt_width_14[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_76 = __beopt_width_15[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_14_77 = 24'(($unsigned(24'($unsigned(mul_tree_14_75))) * $unsigned(24'($unsigned(mul_tree_14_76))))); // decl: <none>; prim: <none>
    assign mul_tree_14_78 = {mul_tree_14_77, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_14_79 = ({13'h0, rtlzz_pipe_18_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_80 = ({1'h0, rtlzz_pipe_22_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_81 = 37'((mul_tree_14_79 + mul_tree_14_80 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_82 = ({13'h0, rtlzz_pipe_26_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_83 = ({1'h0, rtlzz_pipe_30_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_84 = 61'((mul_tree_14_82 + mul_tree_14_83 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_85 = ({13'h0, rtlzz_pipe_34_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_86 = ({1'h0, rtlzz_pipe_38_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_87 = 49'((mul_tree_14_85 + mul_tree_14_86 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_88 = ({13'h0, rtlzz_pipe_42_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_89 = ({1'h0, rtlzz_pipe_46_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_90 = 73'((mul_tree_14_88 + mul_tree_14_89 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_91 = ({13'h0, rtlzz_pipe_50_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_92 = ({1'h0, rtlzz_pipe_54_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_93 = 61'((mul_tree_14_91 + mul_tree_14_92 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_94 = ({13'h0, rtlzz_pipe_58_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_95 = ({1'h0, rtlzz_pipe_62_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_96 = 85'((mul_tree_14_94 + mul_tree_14_95 + ({84'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_97 = ({13'h0, rtlzz_pipe_66_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_98 = ({1'h0, rtlzz_pipe_70_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_99 = 73'((mul_tree_14_97 + mul_tree_14_98 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_100 = ({13'h0, rtlzz_pipe_74_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_101 = ({1'h0, rtlzz_pipe_78_s1}); // decl: <none>; prim: <none>
    assign mul_tree_14_102 = 97'((mul_tree_14_100 + mul_tree_14_101 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_103 = ({25'h0, mul_tree_14_81}); // decl: <none>; prim: <none>
    assign mul_tree_14_104 = ({1'h0, mul_tree_14_84}); // decl: <none>; prim: <none>
    assign mul_tree_14_105 = 62'((mul_tree_14_103 + mul_tree_14_104 + ({61'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_106 = ({25'h0, mul_tree_14_87}); // decl: <none>; prim: <none>
    assign mul_tree_14_107 = ({1'h0, mul_tree_14_90}); // decl: <none>; prim: <none>
    assign mul_tree_14_108 = 74'((mul_tree_14_106 + mul_tree_14_107 + ({73'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_109 = ({25'h0, mul_tree_14_93}); // decl: <none>; prim: <none>
    assign mul_tree_14_110 = ({1'h0, mul_tree_14_96}); // decl: <none>; prim: <none>
    assign mul_tree_14_111 = 86'((mul_tree_14_109 + mul_tree_14_110 + ({85'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_112 = ({25'h0, mul_tree_14_99}); // decl: <none>; prim: <none>
    assign mul_tree_14_113 = ({1'h0, mul_tree_14_102}); // decl: <none>; prim: <none>
    assign mul_tree_14_114 = 98'((mul_tree_14_112 + mul_tree_14_113 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_115 = ({13'h0, mul_tree_14_105}); // decl: <none>; prim: <none>
    assign mul_tree_14_116 = ({1'h0, mul_tree_14_108}); // decl: <none>; prim: <none>
    assign mul_tree_14_117 = 75'((mul_tree_14_115 + mul_tree_14_116 + ({74'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_118 = ({13'h0, mul_tree_14_111}); // decl: <none>; prim: <none>
    assign mul_tree_14_119 = ({1'h0, mul_tree_14_114}); // decl: <none>; prim: <none>
    assign mul_tree_14_120 = 99'((mul_tree_14_118 + mul_tree_14_119 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_121 = ({25'h0, mul_tree_14_117}); // decl: <none>; prim: <none>
    assign mul_tree_14_122 = ({1'h0, mul_tree_14_120}); // decl: <none>; prim: <none>
    assign mul_tree_14_123 = 100'((mul_tree_14_121 + mul_tree_14_122 + ({99'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_14_124 = mul_tree_14_123[95:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_125 = __beopt_width_16[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_126 = __beopt_width_17[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_127 = 24'(($unsigned(24'($unsigned(mul_tree_15_125))) * $unsigned(24'($unsigned(mul_tree_15_126))))); // decl: <none>; prim: <none>
    assign mul_tree_15_128 = __beopt_width_16[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_129 = __beopt_width_17[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_130 = 24'(($unsigned(24'($unsigned(mul_tree_15_128))) * $unsigned(24'($unsigned(mul_tree_15_129))))); // decl: <none>; prim: <none>
    assign mul_tree_15_131 = {mul_tree_15_130, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_132 = __beopt_width_16[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_133 = __beopt_width_17[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_134 = 24'(($unsigned(24'($unsigned(mul_tree_15_132))) * $unsigned(24'($unsigned(mul_tree_15_133))))); // decl: <none>; prim: <none>
    assign mul_tree_15_135 = {mul_tree_15_134, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_136 = __beopt_width_16[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_137 = __beopt_width_17[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_138 = 24'(($unsigned(24'($unsigned(mul_tree_15_136))) * $unsigned(24'($unsigned(mul_tree_15_137))))); // decl: <none>; prim: <none>
    assign mul_tree_15_139 = {mul_tree_15_138, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_140 = __beopt_width_16[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_141 = __beopt_width_17[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_142 = 24'(($unsigned(24'($unsigned(mul_tree_15_140))) * $unsigned(24'($unsigned(mul_tree_15_141))))); // decl: <none>; prim: <none>
    assign mul_tree_15_143 = {mul_tree_15_142, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_144 = __beopt_width_16[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_145 = __beopt_width_17[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_146 = 24'(($unsigned(24'($unsigned(mul_tree_15_144))) * $unsigned(24'($unsigned(mul_tree_15_145))))); // decl: <none>; prim: <none>
    assign mul_tree_15_147 = {mul_tree_15_146, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_148 = __beopt_width_16[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_149 = __beopt_width_17[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_150 = 24'(($unsigned(24'($unsigned(mul_tree_15_148))) * $unsigned(24'($unsigned(mul_tree_15_149))))); // decl: <none>; prim: <none>
    assign mul_tree_15_151 = {mul_tree_15_150, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_152 = __beopt_width_16[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_153 = __beopt_width_17[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_154 = 24'(($unsigned(24'($unsigned(mul_tree_15_152))) * $unsigned(24'($unsigned(mul_tree_15_153))))); // decl: <none>; prim: <none>
    assign mul_tree_15_155 = {mul_tree_15_154, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_156 = __beopt_width_16[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_157 = __beopt_width_17[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_158 = 24'(($unsigned(24'($unsigned(mul_tree_15_156))) * $unsigned(24'($unsigned(mul_tree_15_157))))); // decl: <none>; prim: <none>
    assign mul_tree_15_159 = {mul_tree_15_158, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_160 = __beopt_width_16[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_161 = __beopt_width_17[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_162 = 24'(($unsigned(24'($unsigned(mul_tree_15_160))) * $unsigned(24'($unsigned(mul_tree_15_161))))); // decl: <none>; prim: <none>
    assign mul_tree_15_163 = {mul_tree_15_162, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_164 = __beopt_width_16[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_165 = __beopt_width_17[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_166 = 24'(($unsigned(24'($unsigned(mul_tree_15_164))) * $unsigned(24'($unsigned(mul_tree_15_165))))); // decl: <none>; prim: <none>
    assign mul_tree_15_167 = {mul_tree_15_166, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_168 = __beopt_width_16[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_169 = __beopt_width_17[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_170 = 24'(($unsigned(24'($unsigned(mul_tree_15_168))) * $unsigned(24'($unsigned(mul_tree_15_169))))); // decl: <none>; prim: <none>
    assign mul_tree_15_171 = {mul_tree_15_170, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_172 = __beopt_width_16[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_173 = __beopt_width_17[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_15_174 = 24'(($unsigned(24'($unsigned(mul_tree_15_172))) * $unsigned(24'($unsigned(mul_tree_15_173))))); // decl: <none>; prim: <none>
    assign mul_tree_15_175 = {mul_tree_15_174, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_176 = __beopt_width_16[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_177 = __beopt_width_17[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_15_178 = 24'(($unsigned(24'($unsigned(mul_tree_15_176))) * $unsigned(24'($unsigned(mul_tree_15_177))))); // decl: <none>; prim: <none>
    assign mul_tree_15_179 = {mul_tree_15_178, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_180 = __beopt_width_16[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_181 = __beopt_width_17[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_15_182 = 24'(($unsigned(24'($unsigned(mul_tree_15_180))) * $unsigned(24'($unsigned(mul_tree_15_181))))); // decl: <none>; prim: <none>
    assign mul_tree_15_183 = {mul_tree_15_182, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_184 = __beopt_width_16[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_185 = __beopt_width_17[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_15_186 = 24'(($unsigned(24'($unsigned(mul_tree_15_184))) * $unsigned(24'($unsigned(mul_tree_15_185))))); // decl: <none>; prim: <none>
    assign mul_tree_15_187 = {mul_tree_15_186, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_15_188 = ({13'h0, rtlzz_pipe_127_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_189 = ({1'h0, rtlzz_pipe_131_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_190 = 37'((mul_tree_15_188 + mul_tree_15_189 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_191 = ({13'h0, rtlzz_pipe_135_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_192 = ({1'h0, rtlzz_pipe_139_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_193 = 61'((mul_tree_15_191 + mul_tree_15_192 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_194 = ({13'h0, rtlzz_pipe_143_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_195 = ({1'h0, rtlzz_pipe_147_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_196 = 49'((mul_tree_15_194 + mul_tree_15_195 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_197 = ({13'h0, rtlzz_pipe_151_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_198 = ({1'h0, rtlzz_pipe_155_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_199 = 73'((mul_tree_15_197 + mul_tree_15_198 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_200 = ({13'h0, rtlzz_pipe_159_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_201 = ({1'h0, rtlzz_pipe_163_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_202 = 61'((mul_tree_15_200 + mul_tree_15_201 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_203 = ({13'h0, rtlzz_pipe_167_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_204 = ({1'h0, rtlzz_pipe_171_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_205 = 85'((mul_tree_15_203 + mul_tree_15_204 + ({84'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_206 = ({13'h0, rtlzz_pipe_175_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_207 = ({1'h0, rtlzz_pipe_179_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_208 = 73'((mul_tree_15_206 + mul_tree_15_207 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_209 = ({13'h0, rtlzz_pipe_183_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_210 = ({1'h0, rtlzz_pipe_187_s1}); // decl: <none>; prim: <none>
    assign mul_tree_15_211 = 97'((mul_tree_15_209 + mul_tree_15_210 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_212 = ({25'h0, mul_tree_15_190}); // decl: <none>; prim: <none>
    assign mul_tree_15_213 = ({1'h0, mul_tree_15_193}); // decl: <none>; prim: <none>
    assign mul_tree_15_214 = 62'((mul_tree_15_212 + mul_tree_15_213 + ({61'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_215 = ({25'h0, mul_tree_15_196}); // decl: <none>; prim: <none>
    assign mul_tree_15_216 = ({1'h0, mul_tree_15_199}); // decl: <none>; prim: <none>
    assign mul_tree_15_217 = 74'((mul_tree_15_215 + mul_tree_15_216 + ({73'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_218 = ({25'h0, mul_tree_15_202}); // decl: <none>; prim: <none>
    assign mul_tree_15_219 = ({1'h0, mul_tree_15_205}); // decl: <none>; prim: <none>
    assign mul_tree_15_220 = 86'((mul_tree_15_218 + mul_tree_15_219 + ({85'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_221 = ({25'h0, mul_tree_15_208}); // decl: <none>; prim: <none>
    assign mul_tree_15_222 = ({1'h0, mul_tree_15_211}); // decl: <none>; prim: <none>
    assign mul_tree_15_223 = 98'((mul_tree_15_221 + mul_tree_15_222 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_224 = ({13'h0, mul_tree_15_214}); // decl: <none>; prim: <none>
    assign mul_tree_15_225 = ({1'h0, mul_tree_15_217}); // decl: <none>; prim: <none>
    assign mul_tree_15_226 = 75'((mul_tree_15_224 + mul_tree_15_225 + ({74'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_227 = ({13'h0, mul_tree_15_220}); // decl: <none>; prim: <none>
    assign mul_tree_15_228 = ({1'h0, mul_tree_15_223}); // decl: <none>; prim: <none>
    assign mul_tree_15_229 = 99'((mul_tree_15_227 + mul_tree_15_228 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_230 = ({25'h0, mul_tree_15_226}); // decl: <none>; prim: <none>
    assign mul_tree_15_231 = ({1'h0, mul_tree_15_229}); // decl: <none>; prim: <none>
    assign mul_tree_15_232 = 100'((mul_tree_15_230 + mul_tree_15_231 + ({99'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_15_233 = mul_tree_15_232[95:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_18_s1 <= 24'haf9;
            rtlzz_pipe_22_s1 <= 36'h0;
            rtlzz_pipe_26_s1 <= 48'h0;
            rtlzz_pipe_30_s1 <= 60'h1a800000000000;
            rtlzz_pipe_34_s1 <= 36'h0;
            rtlzz_pipe_38_s1 <= 48'h0;
            rtlzz_pipe_42_s1 <= 60'h0;
            rtlzz_pipe_46_s1 <= 72'h0;
            rtlzz_pipe_50_s1 <= 48'h0;
            rtlzz_pipe_54_s1 <= 60'h0;
            rtlzz_pipe_58_s1 <= 72'h0;
            rtlzz_pipe_62_s1 <= 84'h0;
            rtlzz_pipe_66_s1 <= 60'h1a800000000000;
            rtlzz_pipe_70_s1 <= 72'h0;
            rtlzz_pipe_74_s1 <= 84'h0;
            rtlzz_pipe_78_s1 <= 96'h400000000000000000000000;
            rtlzz_pipe_127_s1 <= 24'h0;
            rtlzz_pipe_131_s1 <= 36'h0;
            rtlzz_pipe_135_s1 <= 48'h0;
            rtlzz_pipe_139_s1 <= 60'h0;
            rtlzz_pipe_143_s1 <= 36'h0;
            rtlzz_pipe_147_s1 <= 48'h0;
            rtlzz_pipe_151_s1 <= 60'h0;
            rtlzz_pipe_155_s1 <= 72'h0;
            rtlzz_pipe_159_s1 <= 48'h0;
            rtlzz_pipe_163_s1 <= 60'h0;
            rtlzz_pipe_167_s1 <= 72'h0;
            rtlzz_pipe_171_s1 <= 84'h0;
            rtlzz_pipe_175_s1 <= 60'h0;
            rtlzz_pipe_179_s1 <= 72'h0;
            rtlzz_pipe_183_s1 <= 84'h0;
            rtlzz_pipe_187_s1 <= 96'h0;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_18_s1 <= mul_tree_14_18; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= mul_tree_14_22; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_26_s1 <= mul_tree_14_26; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_30_s1 <= mul_tree_14_30; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_34_s1 <= mul_tree_14_34; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_38_s1 <= mul_tree_14_38; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_42_s1 <= mul_tree_14_42; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_46_s1 <= mul_tree_14_46; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_50_s1 <= mul_tree_14_50; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_54_s1 <= mul_tree_14_54; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_58_s1 <= mul_tree_14_58; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_62_s1 <= mul_tree_14_62; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_66_s1 <= mul_tree_14_66; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_70_s1 <= mul_tree_14_70; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_74_s1 <= mul_tree_14_74; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_78_s1 <= mul_tree_14_78; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_127_s1 <= mul_tree_15_127; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_131_s1 <= mul_tree_15_131; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_135_s1 <= mul_tree_15_135; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_139_s1 <= mul_tree_15_139; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_143_s1 <= mul_tree_15_143; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_147_s1 <= mul_tree_15_147; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_151_s1 <= mul_tree_15_151; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_155_s1 <= mul_tree_15_155; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_159_s1 <= mul_tree_15_159; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_163_s1 <= mul_tree_15_163; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_167_s1 <= mul_tree_15_167; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_171_s1 <= mul_tree_15_171; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_175_s1 <= mul_tree_15_175; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_179_s1 <= mul_tree_15_179; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_183_s1 <= mul_tree_15_183; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_187_s1 <= mul_tree_15_187; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/DOT2_48_C.logic.cpp:4:1-4:8
        end
    end
endmodule
