`timescale 1ns/1ps

module MAC_48_C(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:11
    input logic [47:0] a, // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:7:1-7:10
    input logic [47:0] b, // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:9:1-9:10
    input logic [95:0] c, // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:11:1-11:10
    output logic [95:0] y, // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:18:5-18:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [95:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:9:1-9:10
    logic [95:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:17:22-17:53
    logic [47:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:7:1-7:10
    logic [47:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:9:1-9:10
    logic [95:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [95:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [95:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:9:1-9:10
    logic [11:0] mul_tree_12_13; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_14; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_15; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_16; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_17; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_18; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_19; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_20; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_21; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_22; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_23; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_24; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_25; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_26; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_27; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_28; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_29; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_30; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_12_31; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_32; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_33; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_34; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_35; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_36; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_37; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_38; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_39; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_40; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_41; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_42; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_12_43; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_44; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_45; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_46; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_12_47; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_48; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_49; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_50; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_51; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_52; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_53; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_54; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_12_55; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_56; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_57; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_58; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_12_59; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_60; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_61; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_62; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_12_63; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_64; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_65; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_66; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_12_67; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_68; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_69; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_70; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_12_71; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_72; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_12_73; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_12_74; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_75; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_76; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_77; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_12_78; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_79; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_80; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_81; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_82; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_83; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_12_84; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_85; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_86; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_87; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_88; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_89; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_12_90; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_12_91; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_12_92; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_12_93; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_94; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_95; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_12_96; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_97; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_98; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_12_99; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_100; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_101; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_12_102; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_12_103; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_12_104; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_12_105; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_12_106; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_12_107; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_12_108; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_12_109; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_12_110; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_12_111; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_12_112; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_12_113; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_12_114; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_12_115; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_12_116; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_12_117; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_12_118; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_12_119; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_12_120; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_12_121; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:11:1-11:10
    logic [23:0] rtlzz_pipe_15_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_19_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_23_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_27_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_31_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_35_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_39_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_43_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_47_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_51_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_55_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_59_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_63_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_67_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_71_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_75_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + rtlzz_pipe_3_s1); // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:17:22-17:53
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({48'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({48'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = mul_tree_12_121; // decl: <none>; prim: <none>
    assign mul_tree_12_13 = __beopt_width_12[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_14 = __beopt_width_13[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_15 = 24'(($unsigned(24'($unsigned(mul_tree_12_13))) * $unsigned(24'($unsigned(mul_tree_12_14))))); // decl: <none>; prim: <none>
    assign mul_tree_12_16 = __beopt_width_12[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_17 = __beopt_width_13[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_18 = 24'(($unsigned(24'($unsigned(mul_tree_12_16))) * $unsigned(24'($unsigned(mul_tree_12_17))))); // decl: <none>; prim: <none>
    assign mul_tree_12_19 = {mul_tree_12_18, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_20 = __beopt_width_12[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_21 = __beopt_width_13[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_22 = 24'(($unsigned(24'($unsigned(mul_tree_12_20))) * $unsigned(24'($unsigned(mul_tree_12_21))))); // decl: <none>; prim: <none>
    assign mul_tree_12_23 = {mul_tree_12_22, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_24 = __beopt_width_12[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_25 = __beopt_width_13[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_26 = 24'(($unsigned(24'($unsigned(mul_tree_12_24))) * $unsigned(24'($unsigned(mul_tree_12_25))))); // decl: <none>; prim: <none>
    assign mul_tree_12_27 = {mul_tree_12_26, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_28 = __beopt_width_12[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_29 = __beopt_width_13[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_30 = 24'(($unsigned(24'($unsigned(mul_tree_12_28))) * $unsigned(24'($unsigned(mul_tree_12_29))))); // decl: <none>; prim: <none>
    assign mul_tree_12_31 = {mul_tree_12_30, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_32 = __beopt_width_12[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_33 = __beopt_width_13[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_34 = 24'(($unsigned(24'($unsigned(mul_tree_12_32))) * $unsigned(24'($unsigned(mul_tree_12_33))))); // decl: <none>; prim: <none>
    assign mul_tree_12_35 = {mul_tree_12_34, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_36 = __beopt_width_12[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_37 = __beopt_width_13[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_38 = 24'(($unsigned(24'($unsigned(mul_tree_12_36))) * $unsigned(24'($unsigned(mul_tree_12_37))))); // decl: <none>; prim: <none>
    assign mul_tree_12_39 = {mul_tree_12_38, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_40 = __beopt_width_12[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_41 = __beopt_width_13[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_42 = 24'(($unsigned(24'($unsigned(mul_tree_12_40))) * $unsigned(24'($unsigned(mul_tree_12_41))))); // decl: <none>; prim: <none>
    assign mul_tree_12_43 = {mul_tree_12_42, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_44 = __beopt_width_12[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_45 = __beopt_width_13[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_46 = 24'(($unsigned(24'($unsigned(mul_tree_12_44))) * $unsigned(24'($unsigned(mul_tree_12_45))))); // decl: <none>; prim: <none>
    assign mul_tree_12_47 = {mul_tree_12_46, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_48 = __beopt_width_12[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_49 = __beopt_width_13[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_50 = 24'(($unsigned(24'($unsigned(mul_tree_12_48))) * $unsigned(24'($unsigned(mul_tree_12_49))))); // decl: <none>; prim: <none>
    assign mul_tree_12_51 = {mul_tree_12_50, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_52 = __beopt_width_12[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_53 = __beopt_width_13[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_54 = 24'(($unsigned(24'($unsigned(mul_tree_12_52))) * $unsigned(24'($unsigned(mul_tree_12_53))))); // decl: <none>; prim: <none>
    assign mul_tree_12_55 = {mul_tree_12_54, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_56 = __beopt_width_12[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_57 = __beopt_width_13[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_58 = 24'(($unsigned(24'($unsigned(mul_tree_12_56))) * $unsigned(24'($unsigned(mul_tree_12_57))))); // decl: <none>; prim: <none>
    assign mul_tree_12_59 = {mul_tree_12_58, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_60 = __beopt_width_12[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_61 = __beopt_width_13[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_12_62 = 24'(($unsigned(24'($unsigned(mul_tree_12_60))) * $unsigned(24'($unsigned(mul_tree_12_61))))); // decl: <none>; prim: <none>
    assign mul_tree_12_63 = {mul_tree_12_62, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_64 = __beopt_width_12[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_65 = __beopt_width_13[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_12_66 = 24'(($unsigned(24'($unsigned(mul_tree_12_64))) * $unsigned(24'($unsigned(mul_tree_12_65))))); // decl: <none>; prim: <none>
    assign mul_tree_12_67 = {mul_tree_12_66, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_68 = __beopt_width_12[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_69 = __beopt_width_13[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_12_70 = 24'(($unsigned(24'($unsigned(mul_tree_12_68))) * $unsigned(24'($unsigned(mul_tree_12_69))))); // decl: <none>; prim: <none>
    assign mul_tree_12_71 = {mul_tree_12_70, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_72 = __beopt_width_12[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_73 = __beopt_width_13[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_12_74 = 24'(($unsigned(24'($unsigned(mul_tree_12_72))) * $unsigned(24'($unsigned(mul_tree_12_73))))); // decl: <none>; prim: <none>
    assign mul_tree_12_75 = {mul_tree_12_74, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_12_76 = ({13'h0, rtlzz_pipe_15_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_77 = ({1'h0, rtlzz_pipe_19_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_78 = 37'((mul_tree_12_76 + mul_tree_12_77 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_79 = ({13'h0, rtlzz_pipe_23_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_80 = ({1'h0, rtlzz_pipe_27_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_81 = 61'((mul_tree_12_79 + mul_tree_12_80 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_82 = ({13'h0, rtlzz_pipe_31_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_83 = ({1'h0, rtlzz_pipe_35_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_84 = 49'((mul_tree_12_82 + mul_tree_12_83 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_85 = ({13'h0, rtlzz_pipe_39_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_86 = ({1'h0, rtlzz_pipe_43_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_87 = 73'((mul_tree_12_85 + mul_tree_12_86 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_88 = ({13'h0, rtlzz_pipe_47_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_89 = ({1'h0, rtlzz_pipe_51_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_90 = 61'((mul_tree_12_88 + mul_tree_12_89 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_91 = ({13'h0, rtlzz_pipe_55_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_92 = ({1'h0, rtlzz_pipe_59_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_93 = 85'((mul_tree_12_91 + mul_tree_12_92 + ({84'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_94 = ({13'h0, rtlzz_pipe_63_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_95 = ({1'h0, rtlzz_pipe_67_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_96 = 73'((mul_tree_12_94 + mul_tree_12_95 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_97 = ({13'h0, rtlzz_pipe_71_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_98 = ({1'h0, rtlzz_pipe_75_s1}); // decl: <none>; prim: <none>
    assign mul_tree_12_99 = 97'((mul_tree_12_97 + mul_tree_12_98 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_100 = ({25'h0, mul_tree_12_78}); // decl: <none>; prim: <none>
    assign mul_tree_12_101 = ({1'h0, mul_tree_12_81}); // decl: <none>; prim: <none>
    assign mul_tree_12_102 = 62'((mul_tree_12_100 + mul_tree_12_101 + ({61'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_103 = ({25'h0, mul_tree_12_84}); // decl: <none>; prim: <none>
    assign mul_tree_12_104 = ({1'h0, mul_tree_12_87}); // decl: <none>; prim: <none>
    assign mul_tree_12_105 = 74'((mul_tree_12_103 + mul_tree_12_104 + ({73'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_106 = ({25'h0, mul_tree_12_90}); // decl: <none>; prim: <none>
    assign mul_tree_12_107 = ({1'h0, mul_tree_12_93}); // decl: <none>; prim: <none>
    assign mul_tree_12_108 = 86'((mul_tree_12_106 + mul_tree_12_107 + ({85'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_109 = ({25'h0, mul_tree_12_96}); // decl: <none>; prim: <none>
    assign mul_tree_12_110 = ({1'h0, mul_tree_12_99}); // decl: <none>; prim: <none>
    assign mul_tree_12_111 = 98'((mul_tree_12_109 + mul_tree_12_110 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_112 = ({13'h0, mul_tree_12_102}); // decl: <none>; prim: <none>
    assign mul_tree_12_113 = ({1'h0, mul_tree_12_105}); // decl: <none>; prim: <none>
    assign mul_tree_12_114 = 75'((mul_tree_12_112 + mul_tree_12_113 + ({74'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_115 = ({13'h0, mul_tree_12_108}); // decl: <none>; prim: <none>
    assign mul_tree_12_116 = ({1'h0, mul_tree_12_111}); // decl: <none>; prim: <none>
    assign mul_tree_12_117 = 99'((mul_tree_12_115 + mul_tree_12_116 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_118 = ({25'h0, mul_tree_12_114}); // decl: <none>; prim: <none>
    assign mul_tree_12_119 = ({1'h0, mul_tree_12_117}); // decl: <none>; prim: <none>
    assign mul_tree_12_120 = 100'((mul_tree_12_118 + mul_tree_12_119 + ({99'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_12_121 = mul_tree_12_120[95:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 96'h800000020000000000000035;
            rtlzz_pipe_15_s1 <= 24'haf9;
            rtlzz_pipe_19_s1 <= 36'h0;
            rtlzz_pipe_23_s1 <= 48'h0;
            rtlzz_pipe_27_s1 <= 60'h1a800000000000;
            rtlzz_pipe_31_s1 <= 36'h0;
            rtlzz_pipe_35_s1 <= 48'h0;
            rtlzz_pipe_39_s1 <= 60'h0;
            rtlzz_pipe_43_s1 <= 72'h0;
            rtlzz_pipe_47_s1 <= 48'h0;
            rtlzz_pipe_51_s1 <= 60'h0;
            rtlzz_pipe_55_s1 <= 72'h0;
            rtlzz_pipe_59_s1 <= 84'h0;
            rtlzz_pipe_63_s1 <= 60'h1a800000000000;
            rtlzz_pipe_67_s1 <= 72'h0;
            rtlzz_pipe_71_s1 <= 84'h0;
            rtlzz_pipe_75_s1 <= 96'h400000000000000000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= c; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:11:1-11:10
        end
        if (iv) begin
        rtlzz_pipe_15_s1 <= mul_tree_12_15; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_19_s1 <= mul_tree_12_19; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_23_s1 <= mul_tree_12_23; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_27_s1 <= mul_tree_12_27; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_31_s1 <= mul_tree_12_31; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_35_s1 <= mul_tree_12_35; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_39_s1 <= mul_tree_12_39; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_43_s1 <= mul_tree_12_43; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_47_s1 <= mul_tree_12_47; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_51_s1 <= mul_tree_12_51; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_55_s1 <= mul_tree_12_55; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_59_s1 <= mul_tree_12_59; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_63_s1 <= mul_tree_12_63; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_67_s1 <= mul_tree_12_67; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_71_s1 <= mul_tree_12_71; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_75_s1 <= mul_tree_12_75; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_48_C.logic.cpp:4:1-4:8
        end
    end
endmodule
