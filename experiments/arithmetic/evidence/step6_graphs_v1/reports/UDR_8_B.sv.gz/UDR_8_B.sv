`timescale 1ns/1ps

module UDR_8_B(
    input logic iv, // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:7:1-7:9
    input logic [7:0] d, // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:9:1-9:9
    output logic [7:0] q, // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:25:5-25:18
    output logic [7:0] r, // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:26:5-26:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:27-18:39
    logic [7:0] s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:20:30-20:63; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:5-18:40
    logic [7:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:21:29-21:47; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:21:29-21:47
    logic [7:0] s8_norm_udivmod_7_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:22:29-22:47; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:22:29-22:47
    logic [7:0] s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:23:25-23:71; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:5-18:40
    logic [7:0] s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:24:25-24:60; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:24:25-24:60
    logic [7:0] arith_original_12; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:21:29-21:47; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:21:29-21:47
    logic [7:0] arith_original_13; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:22:29-22:47; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:22:29-22:47
    logic [7:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:7:1-7:9
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:27-18:39
    logic [7:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:20:30-20:63; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:5-18:40
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:8


    assign s8_norm_cmp_4_v0 = (d == 8'h0); // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:27-18:39
    assign s8_norm_mux_5_v0 = (s8_norm_cmp_4_v0 ? 8'h1 : d); // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:20:30-20:63; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:5-18:40
    assign s8_norm_udivmod_6_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_7_v0 = arith_original_13; // decl: <none>; prim: <none>
    assign s8_norm_mux_8_v0 = (rtlzz_pipe_3_s1 ? 8'hff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:23:25-23:71; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:5-18:40
    assign s8_norm_mux_9_v0 = (rtlzz_pipe_3_s1 ? rtlzz_pipe_1_s1 : s8_norm_udivmod_7_v0); // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:24:25-24:60; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:24:25-24:60
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_8_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:25:5-25:18
    assign r = s8_norm_mux_9_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:26:5-26:18
    assign arith_original_12 = (rtlzz_pipe_1_s1 / rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:21:29-21:47; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:21:29-21:47
    assign arith_original_13 = (rtlzz_pipe_1_s1 % rtlzz_pipe_4_s1); // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:22:29-22:47; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:22:29-22:47
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 8'hb5;
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_4_s1 <= 8'h1;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:7:1-7:9
        end
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_4_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:19:29-19:46; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:27-18:39
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mux_5_v0; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:20:30-20:63; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:18:5-18:40
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/UDR_8_B.logic.cpp:4:1-4:8
        end
    end
endmodule
