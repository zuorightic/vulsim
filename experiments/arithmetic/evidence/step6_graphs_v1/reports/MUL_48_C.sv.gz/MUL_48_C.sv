`timescale 1ns/1ps

module MUL_48_C(
    input logic iv, // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:11
    input logic [47:0] a, // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:7:1-7:10
    input logic [47:0] b, // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:9:1-9:10
    output logic [95:0] y, // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:15:5-15:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [95:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:9:1-9:10
    logic [47:0] __beopt_width_8; // decl: <none>; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:7:1-7:10
    logic [47:0] __beopt_width_9; // decl: <none>; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:9:1-9:10
    logic [95:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [95:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [95:0] arith_original_10; // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:9:1-9:10
    logic [11:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [35:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_36; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_10_37; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_38; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_39; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_40; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_10_41; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_42; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_43; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_44; // decl: <none>; prim: <none>
    logic [47:0] mul_tree_10_45; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_46; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_47; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_48; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_10_49; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_50; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_51; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_52; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_10_53; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_54; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_55; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_56; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_10_57; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_58; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_59; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_60; // decl: <none>; prim: <none>
    logic [59:0] mul_tree_10_61; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_62; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_63; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_64; // decl: <none>; prim: <none>
    logic [71:0] mul_tree_10_65; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_66; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_67; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_68; // decl: <none>; prim: <none>
    logic [83:0] mul_tree_10_69; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_70; // decl: <none>; prim: <none>
    logic [11:0] mul_tree_10_71; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_72; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_73; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_74; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_75; // decl: <none>; prim: <none>
    logic [36:0] mul_tree_10_76; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_10_77; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_10_78; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_10_79; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_80; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_81; // decl: <none>; prim: <none>
    logic [48:0] mul_tree_10_82; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_83; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_84; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_85; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_10_86; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_10_87; // decl: <none>; prim: <none>
    logic [60:0] mul_tree_10_88; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_10_89; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_10_90; // decl: <none>; prim: <none>
    logic [84:0] mul_tree_10_91; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_92; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_93; // decl: <none>; prim: <none>
    logic [72:0] mul_tree_10_94; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_95; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_96; // decl: <none>; prim: <none>
    logic [96:0] mul_tree_10_97; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_10_98; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_10_99; // decl: <none>; prim: <none>
    logic [61:0] mul_tree_10_100; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_10_101; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_10_102; // decl: <none>; prim: <none>
    logic [73:0] mul_tree_10_103; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_10_104; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_10_105; // decl: <none>; prim: <none>
    logic [85:0] mul_tree_10_106; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_107; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_108; // decl: <none>; prim: <none>
    logic [97:0] mul_tree_10_109; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_10_110; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_10_111; // decl: <none>; prim: <none>
    logic [74:0] mul_tree_10_112; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_10_113; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_10_114; // decl: <none>; prim: <none>
    logic [98:0] mul_tree_10_115; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_10_116; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_10_117; // decl: <none>; prim: <none>
    logic [99:0] mul_tree_10_118; // decl: <none>; prim: <none>
    logic [95:0] mul_tree_10_119; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic [35:0] rtlzz_pipe_29_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_33_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_37_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_41_s1; // decl: <none>; prim: <none>
    logic [47:0] rtlzz_pipe_45_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_49_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_53_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_57_s1; // decl: <none>; prim: <none>
    logic [59:0] rtlzz_pipe_61_s1; // decl: <none>; prim: <none>
    logic [71:0] rtlzz_pipe_65_s1; // decl: <none>; prim: <none>
    logic [83:0] rtlzz_pipe_69_s1; // decl: <none>; prim: <none>
    logic [95:0] rtlzz_pipe_73_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:15:5-15:18
    assign __beopt_width_8 = a; // decl: <none>; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:7:1-7:10
    assign __beopt_width_9 = b; // decl: <none>; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:9:1-9:10
    assign __beopt_width_10 = ({48'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({48'h0, __beopt_width_9}); // decl: <none>; prim: <none>
    assign arith_original_10 = mul_tree_10_119; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = __beopt_width_10[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = __beopt_width_11[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 24'(($unsigned(24'($unsigned(mul_tree_10_11))) * $unsigned(24'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = __beopt_width_10[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = __beopt_width_11[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 24'(($unsigned(24'($unsigned(mul_tree_10_14))) * $unsigned(24'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = __beopt_width_10[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = __beopt_width_11[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 24'(($unsigned(24'($unsigned(mul_tree_10_18))) * $unsigned(24'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = __beopt_width_10[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = __beopt_width_11[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 24'(($unsigned(24'($unsigned(mul_tree_10_22))) * $unsigned(24'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = __beopt_width_10[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_27 = __beopt_width_11[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 24'(($unsigned(24'($unsigned(mul_tree_10_26))) * $unsigned(24'($unsigned(mul_tree_10_27))))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = {mul_tree_10_28, 12'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_30 = __beopt_width_10[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_31 = __beopt_width_11[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_32 = 24'(($unsigned(24'($unsigned(mul_tree_10_30))) * $unsigned(24'($unsigned(mul_tree_10_31))))); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = {mul_tree_10_32, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_34 = __beopt_width_10[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_35 = __beopt_width_11[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_36 = 24'(($unsigned(24'($unsigned(mul_tree_10_34))) * $unsigned(24'($unsigned(mul_tree_10_35))))); // decl: <none>; prim: <none>
    assign mul_tree_10_37 = {mul_tree_10_36, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_38 = __beopt_width_10[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_39 = __beopt_width_11[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_40 = 24'(($unsigned(24'($unsigned(mul_tree_10_38))) * $unsigned(24'($unsigned(mul_tree_10_39))))); // decl: <none>; prim: <none>
    assign mul_tree_10_41 = {mul_tree_10_40, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_42 = __beopt_width_10[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_43 = __beopt_width_11[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_44 = 24'(($unsigned(24'($unsigned(mul_tree_10_42))) * $unsigned(24'($unsigned(mul_tree_10_43))))); // decl: <none>; prim: <none>
    assign mul_tree_10_45 = {mul_tree_10_44, 24'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_46 = __beopt_width_10[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_47 = __beopt_width_11[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_48 = 24'(($unsigned(24'($unsigned(mul_tree_10_46))) * $unsigned(24'($unsigned(mul_tree_10_47))))); // decl: <none>; prim: <none>
    assign mul_tree_10_49 = {mul_tree_10_48, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_50 = __beopt_width_10[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_51 = __beopt_width_11[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_52 = 24'(($unsigned(24'($unsigned(mul_tree_10_50))) * $unsigned(24'($unsigned(mul_tree_10_51))))); // decl: <none>; prim: <none>
    assign mul_tree_10_53 = {mul_tree_10_52, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_54 = __beopt_width_10[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_55 = __beopt_width_11[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_56 = 24'(($unsigned(24'($unsigned(mul_tree_10_54))) * $unsigned(24'($unsigned(mul_tree_10_55))))); // decl: <none>; prim: <none>
    assign mul_tree_10_57 = {mul_tree_10_56, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_58 = __beopt_width_10[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_59 = __beopt_width_11[11:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_60 = 24'(($unsigned(24'($unsigned(mul_tree_10_58))) * $unsigned(24'($unsigned(mul_tree_10_59))))); // decl: <none>; prim: <none>
    assign mul_tree_10_61 = {mul_tree_10_60, 36'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_62 = __beopt_width_10[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_63 = __beopt_width_11[23:12]; // decl: <none>; prim: <none>
    assign mul_tree_10_64 = 24'(($unsigned(24'($unsigned(mul_tree_10_62))) * $unsigned(24'($unsigned(mul_tree_10_63))))); // decl: <none>; prim: <none>
    assign mul_tree_10_65 = {mul_tree_10_64, 48'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_66 = __beopt_width_10[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_67 = __beopt_width_11[35:24]; // decl: <none>; prim: <none>
    assign mul_tree_10_68 = 24'(($unsigned(24'($unsigned(mul_tree_10_66))) * $unsigned(24'($unsigned(mul_tree_10_67))))); // decl: <none>; prim: <none>
    assign mul_tree_10_69 = {mul_tree_10_68, 60'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_70 = __beopt_width_10[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_71 = __beopt_width_11[47:36]; // decl: <none>; prim: <none>
    assign mul_tree_10_72 = 24'(($unsigned(24'($unsigned(mul_tree_10_70))) * $unsigned(24'($unsigned(mul_tree_10_71))))); // decl: <none>; prim: <none>
    assign mul_tree_10_73 = {mul_tree_10_72, 72'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_74 = ({13'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_75 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_76 = 37'((mul_tree_10_74 + mul_tree_10_75 + ({36'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_77 = ({13'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_78 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_79 = 61'((mul_tree_10_77 + mul_tree_10_78 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_80 = ({13'h0, rtlzz_pipe_29_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_81 = ({1'h0, rtlzz_pipe_33_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_82 = 49'((mul_tree_10_80 + mul_tree_10_81 + ({48'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_83 = ({13'h0, rtlzz_pipe_37_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_84 = ({1'h0, rtlzz_pipe_41_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_85 = 73'((mul_tree_10_83 + mul_tree_10_84 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_86 = ({13'h0, rtlzz_pipe_45_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_87 = ({1'h0, rtlzz_pipe_49_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_88 = 61'((mul_tree_10_86 + mul_tree_10_87 + ({60'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_89 = ({13'h0, rtlzz_pipe_53_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_90 = ({1'h0, rtlzz_pipe_57_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_91 = 85'((mul_tree_10_89 + mul_tree_10_90 + ({84'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_92 = ({13'h0, rtlzz_pipe_61_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_93 = ({1'h0, rtlzz_pipe_65_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_94 = 73'((mul_tree_10_92 + mul_tree_10_93 + ({72'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_95 = ({13'h0, rtlzz_pipe_69_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_96 = ({1'h0, rtlzz_pipe_73_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_97 = 97'((mul_tree_10_95 + mul_tree_10_96 + ({96'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_98 = ({25'h0, mul_tree_10_76}); // decl: <none>; prim: <none>
    assign mul_tree_10_99 = ({1'h0, mul_tree_10_79}); // decl: <none>; prim: <none>
    assign mul_tree_10_100 = 62'((mul_tree_10_98 + mul_tree_10_99 + ({61'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_101 = ({25'h0, mul_tree_10_82}); // decl: <none>; prim: <none>
    assign mul_tree_10_102 = ({1'h0, mul_tree_10_85}); // decl: <none>; prim: <none>
    assign mul_tree_10_103 = 74'((mul_tree_10_101 + mul_tree_10_102 + ({73'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_104 = ({25'h0, mul_tree_10_88}); // decl: <none>; prim: <none>
    assign mul_tree_10_105 = ({1'h0, mul_tree_10_91}); // decl: <none>; prim: <none>
    assign mul_tree_10_106 = 86'((mul_tree_10_104 + mul_tree_10_105 + ({85'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_107 = ({25'h0, mul_tree_10_94}); // decl: <none>; prim: <none>
    assign mul_tree_10_108 = ({1'h0, mul_tree_10_97}); // decl: <none>; prim: <none>
    assign mul_tree_10_109 = 98'((mul_tree_10_107 + mul_tree_10_108 + ({97'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_110 = ({13'h0, mul_tree_10_100}); // decl: <none>; prim: <none>
    assign mul_tree_10_111 = ({1'h0, mul_tree_10_103}); // decl: <none>; prim: <none>
    assign mul_tree_10_112 = 75'((mul_tree_10_110 + mul_tree_10_111 + ({74'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_113 = ({13'h0, mul_tree_10_106}); // decl: <none>; prim: <none>
    assign mul_tree_10_114 = ({1'h0, mul_tree_10_109}); // decl: <none>; prim: <none>
    assign mul_tree_10_115 = 99'((mul_tree_10_113 + mul_tree_10_114 + ({98'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_116 = ({25'h0, mul_tree_10_112}); // decl: <none>; prim: <none>
    assign mul_tree_10_117 = ({1'h0, mul_tree_10_115}); // decl: <none>; prim: <none>
    assign mul_tree_10_118 = 100'((mul_tree_10_116 + mul_tree_10_117 + ({99'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_119 = mul_tree_10_118[95:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_13_s1 <= 24'haf9;
            rtlzz_pipe_17_s1 <= 36'h0;
            rtlzz_pipe_21_s1 <= 48'h0;
            rtlzz_pipe_25_s1 <= 60'h1a800000000000;
            rtlzz_pipe_29_s1 <= 36'h0;
            rtlzz_pipe_33_s1 <= 48'h0;
            rtlzz_pipe_37_s1 <= 60'h0;
            rtlzz_pipe_41_s1 <= 72'h0;
            rtlzz_pipe_45_s1 <= 48'h0;
            rtlzz_pipe_49_s1 <= 60'h0;
            rtlzz_pipe_53_s1 <= 72'h0;
            rtlzz_pipe_57_s1 <= 84'h0;
            rtlzz_pipe_61_s1 <= 60'h1a800000000000;
            rtlzz_pipe_65_s1 <= 72'h0;
            rtlzz_pipe_69_s1 <= 84'h0;
            rtlzz_pipe_73_s1 <= 96'h400000000000000000000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_29_s1 <= mul_tree_10_29; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_33_s1 <= mul_tree_10_33; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_37_s1 <= mul_tree_10_37; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_41_s1 <= mul_tree_10_41; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_45_s1 <= mul_tree_10_45; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_49_s1 <= mul_tree_10_49; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_53_s1 <= mul_tree_10_53; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_57_s1 <= mul_tree_10_57; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_61_s1 <= mul_tree_10_61; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_65_s1 <= mul_tree_10_65; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_69_s1 <= mul_tree_10_69; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_73_s1 <= mul_tree_10_73; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_48_C.logic.cpp:4:1-4:8
        end
    end
endmodule
