`timescale 1ns/1ps

module MIX_48_C(
    input logic iv, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:11
    input logic [47:0] a, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:7:1-7:10
    input logic [47:0] b, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:9:1-9:10
    input logic [47:0] mask, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:11:1-11:13; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:11:1-11:13
    input logic [47:0] d, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:13:1-13:10
    input logic [6:0] s, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:15:1-15:9
    output logic [47:0] y, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:46:5-46:17
    output logic less, // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:47:5-47:18
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_7_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:22:22-22:35
    logic [47:0] s8_norm_bitnot_8_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:29:30-29:35; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:29:30-29:35
    logic s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25
    logic s8_norm_cmp_10_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:25:26-25:39
    logic [47:0] s8_norm_add_11_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:32:20-32:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:32:20-32:43
    logic [47:0] s8_norm_sub_12_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:33:20-33:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:33:20-33:43
    logic [47:0] s8_norm_mux_13_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:34:29-34:58; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:25:5-25:40
    logic [47:0] s8_norm_udivmod_15_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:36:28-36:44; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:36:28-36:44
    logic [47:0] s8_norm_shift_17_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:37:24-37:54; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:32:20-32:30
    logic [47:0] s8_norm_shift_19_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:38:24-38:54; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:33:20-33:30
    logic [47:0] s8_norm_mux_20_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:39:23-39:52; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:22:5-22:36
    logic [47:0] s8_norm_mux_21_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:40:24-40:55; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:40:24-40:55
    logic [47:0] s8_norm_mux_22_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:41:24-41:53; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:22:5-22:36
    logic [47:0] s8_norm_bitop_23_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:42:27-42:40; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:42:27-42:40
    logic [47:0] s8_norm_bitop_24_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:43:27-43:51; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:43:27-43:51
    logic [47:0] s8_norm_bitop_25_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:44:25-44:48; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:44:25-44:48
    logic [47:0] s8_norm_bitop_26_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43
    logic [47:0] arith_original_26; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:36:28-36:44; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:36:28-36:44
    logic rtlzz_pipe_8_s1; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25
    logic [47:0] rtlzz_pipe_22_s1; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_7_v0 = (s < 7'h30); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:28:24-28:35; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:22:22-22:35
    assign s8_norm_bitnot_8_v0 = (~mask); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:29:30-29:35; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:29:30-29:35
    assign s8_norm_cmp_9_v0 = (a < b); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25
    assign s8_norm_cmp_10_v0 = (d == 48'h0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:31:27-31:42; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:25:26-25:39
    assign s8_norm_add_11_v0 = (a + b); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:32:20-32:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:32:20-32:43
    assign s8_norm_sub_12_v0 = (a - b); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:33:20-33:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:33:20-33:43
    assign s8_norm_mux_13_v0 = (s8_norm_cmp_10_v0 ? 48'h1 : d); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:34:29-34:58; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:25:5-25:40
    assign s8_norm_udivmod_15_v0 = arith_original_26; // decl: <none>; prim: <none>
    assign s8_norm_shift_17_v0 = (s >= 7'd48 ? 48'h0 : (s8_norm_add_11_v0 << s)); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:37:24-37:54; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:32:20-32:30
    assign s8_norm_shift_19_v0 = (s >= 7'd48 ? 48'h0 : (s8_norm_sub_12_v0 >> s)); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:38:24-38:54; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:33:20-33:30
    assign s8_norm_mux_20_v0 = (s8_norm_cmp_7_v0 ? s8_norm_shift_17_v0 : 48'h0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:39:23-39:52; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:22:5-22:36
    assign s8_norm_mux_21_v0 = (s8_norm_cmp_10_v0 ? a : s8_norm_udivmod_15_v0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:40:24-40:55; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:40:24-40:55
    assign s8_norm_mux_22_v0 = (s8_norm_cmp_7_v0 ? s8_norm_shift_19_v0 : 48'h0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:41:24-41:53; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:22:5-22:36
    assign s8_norm_bitop_23_v0 = (s8_norm_mux_20_v0 & mask); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:42:27-42:40; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:42:27-42:40
    assign s8_norm_bitop_24_v0 = (s8_norm_mux_22_v0 & s8_norm_bitnot_8_v0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:43:27-43:51; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:43:27-43:51
    assign s8_norm_bitop_25_v0 = (s8_norm_bitop_23_v0 | s8_norm_bitop_24_v0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:44:25-44:48; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:44:25-44:48
    assign s8_norm_bitop_26_v0 = (s8_norm_bitop_25_v0 ^ s8_norm_mux_21_v0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = rtlzz_pipe_22_s1; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:46:5-46:17
    assign less = rtlzz_pipe_8_s1; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:19:1-19:10; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:47:5-47:18
    assign arith_original_26 = (a % s8_norm_mux_13_v0); // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:36:28-36:44; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:36:28-36:44
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_8_s1 <= 1'h0;
            rtlzz_pipe_22_s1 <= 48'h800000000035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_8_s1 <= s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:30:20-30:25
        end
        if (iv) begin
        rtlzz_pipe_22_s1 <= s8_norm_bitop_26_v0; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:45:25-45:43
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MIX_48_C.logic.cpp:4:1-4:8
        end
    end
endmodule
