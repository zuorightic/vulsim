`timescale 1ns/1ps

module MAC_32_B(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:11
    input logic [31:0] a, // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:7:1-7:10
    input logic [31:0] b, // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
    input logic [63:0] c, // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:11:1-11:10
    output logic [63:0] y, // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:18:5-18:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [63:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
    logic [63:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:17:22-17:53
    logic [31:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:7:1-7:10
    logic [31:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
    logic [63:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [63:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [63:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
    logic [63:0] rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:11:1-11:10
    logic [63:0] rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:8


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (rtlzz_pipe_4_s1 + rtlzz_pipe_3_s1); // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:17:22-17:53; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:17:22-17:53
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:13:1-13:10; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({32'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({32'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = 64'(($unsigned(64'($unsigned(__beopt_width_12))) * $unsigned(64'($unsigned(__beopt_width_13))))); // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 64'h8000000000000035;
            rtlzz_pipe_4_s1 <= 64'h4000003500000af9;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= c; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:11:1-11:10
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:16:26-16:31; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:9:1-9:10
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_32_B.logic.cpp:4:1-4:8
        end
    end
endmodule
