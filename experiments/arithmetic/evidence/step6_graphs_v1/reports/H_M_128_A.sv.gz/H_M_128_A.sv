`timescale 1ns/1ps

module H_M_128_A(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:4:1-4:11
    input logic [127:0] a, // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:7:1-7:11; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:7:1-7:11
    input logic [127:0] b, // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:9:1-9:11; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:9:1-9:11
    input logic [127:0] c, // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:11:1-11:11
    input logic sel, // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:13:1-13:9
    output logic [127:0] y // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:22:5-22:14
);

    logic [127:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:19:28-19:44; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:18:23-18:37
    logic [127:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:20:27-20:32
    logic [127:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:21:23-21:65; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:21:23-21:65
    logic [127:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:20:27-20:32


    assign s8_norm_mux_1_v0 = (sel ? c : 128'h0); // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:19:28-19:44; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:18:23-18:37
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + s8_norm_mux_1_v0); // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:21:23-21:65; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:21:23-21:65
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_128_A.logic.cpp:15:1-15:11; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:22:5-22:14
    assign arith_original_10 = 128'(($unsigned(128'($unsigned(a))) * $unsigned(128'($unsigned(b))))); // decl: <none>; prim: /home/zyrv/vulsim/H_M_128_A.logic.cpp:20:27-20:32
endmodule
