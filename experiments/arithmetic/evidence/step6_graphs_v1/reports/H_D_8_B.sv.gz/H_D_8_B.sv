`timescale 1ns/1ps

module H_D_8_B(
    input logic iv, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:7:1-7:9
    input logic [7:0] d, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:9:1-9:9
    input logic [7:0] e, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:11:1-11:9
    output logic [7:0] q, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:38:5-38:19
    output logic [7:0] r1, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:39:5-39:19
    output logic [7:0] r2, // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:40:5-40:20
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:27-22:39
    logic s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:28-25:40
    logic [7:0] s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:28:30-28:63; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
    logic [7:0] s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
    logic [7:0] s8_norm_udivmod_12_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:30:29-30:47; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:30:29-30:47
    logic [7:0] s8_norm_udivmod_13_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:31:29-31:47; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:31:29-31:47
    logic [7:0] s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:32:25-32:71; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
    logic [7:0] s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60
    logic [7:0] s8_norm_udivmod_16_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:34:30-34:57; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:34:30-34:57
    logic [7:0] s8_norm_udivmod_17_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:35:30-35:57; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:35:30-35:57
    logic [7:0] s8_norm_mux_18_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:36:26-36:75; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
    logic [7:0] s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:37:26-37:71; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:37:26-37:71
    logic [7:0] arith_original_20; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:30:29-30:47; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:30:29-30:47
    logic [7:0] arith_original_21; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:31:29-31:47; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:31:29-31:47
    logic [7:0] arith_original_22; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:34:30-34:57; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:34:30-34:57
    logic [7:0] arith_original_23; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:35:30-35:57; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:35:30-35:57
    logic [7:0] rtlzz_pipe_1_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:7:1-7:9
    logic rtlzz_pipe_4_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:27-22:39
    logic rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:28-25:40
    logic rtlzz_pipe_5_s2; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:28-25:40
    logic [7:0] rtlzz_pipe_6_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:28:30-28:63; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
    logic [7:0] rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
    logic [7:0] rtlzz_pipe_7_s2; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
    logic [7:0] rtlzz_pipe_10_s2; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:32:25-32:71; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
    logic [7:0] rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8
    logic rtlzz_valid_s2; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8


    assign s8_norm_cmp_8_v0 = (d == 8'h0); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:27-22:39
    assign s8_norm_cmp_9_v0 = (e == 8'h0); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:28-25:40
    assign s8_norm_mux_10_v0 = (s8_norm_cmp_8_v0 ? 8'h1 : d); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:28:30-28:63; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
    assign s8_norm_mux_11_v0 = (s8_norm_cmp_9_v0 ? 8'h1 : e); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
    assign s8_norm_udivmod_12_v0 = arith_original_20; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_13_v0 = arith_original_21; // decl: <none>; prim: <none>
    assign s8_norm_mux_14_v0 = (rtlzz_pipe_4_s1 ? 8'hff : s8_norm_udivmod_12_v0); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:32:25-32:71; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
    assign s8_norm_mux_15_v0 = (rtlzz_pipe_4_s1 ? rtlzz_pipe_1_s1 : s8_norm_udivmod_13_v0); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60
    assign s8_norm_udivmod_16_v0 = arith_original_22; // decl: <none>; prim: <none>
    assign s8_norm_udivmod_17_v0 = arith_original_23; // decl: <none>; prim: <none>
    assign s8_norm_mux_18_v0 = (rtlzz_pipe_5_s2 ? 8'hff : s8_norm_udivmod_16_v0); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:36:26-36:75; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
    assign s8_norm_mux_19_v0 = (rtlzz_pipe_5_s2 ? rtlzz_pipe_10_s2 : s8_norm_udivmod_17_v0); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:37:26-37:71; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:37:26-37:71
    assign ov = rtlzz_valid_s2; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_18_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:38:5-38:19
    assign r1 = rtlzz_pipe_11_s2; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:39:5-39:19
    assign r2 = s8_norm_mux_19_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:17:1-17:10; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:40:5-40:20
    assign arith_original_20 = (rtlzz_pipe_1_s1 / rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:30:29-30:47; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:30:29-30:47
    assign arith_original_21 = (rtlzz_pipe_1_s1 % rtlzz_pipe_6_s1); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:31:29-31:47; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:31:29-31:47
    assign arith_original_22 = (rtlzz_pipe_10_s2 / rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:34:30-34:57; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:34:30-34:57
    assign arith_original_23 = (rtlzz_pipe_10_s2 % rtlzz_pipe_7_s2); // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:35:30-35:57; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:35:30-35:57
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_1_s1 <= 8'hb5;
            rtlzz_pipe_4_s1 <= 1'h1;
            rtlzz_pipe_5_s1 <= 1'h1;
            rtlzz_pipe_5_s2 <= 1'h1;
            rtlzz_pipe_6_s1 <= 8'h1;
            rtlzz_pipe_7_s1 <= 8'h1;
            rtlzz_pipe_7_s2 <= 8'h1;
            rtlzz_pipe_10_s2 <= 8'hff;
            rtlzz_pipe_11_s2 <= 8'hb5;
            rtlzz_valid_s1 <= 1'h0;
            rtlzz_valid_s2 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_1_s1 <= a; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:7:1-7:9
        end
        if (iv) begin
        rtlzz_pipe_4_s1 <= s8_norm_cmp_8_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:26:29-26:46; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:27-22:39
        end
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_cmp_9_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:28-25:40
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_5_s2 <= rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:27:30-27:48; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:28-25:40
        end
        if (iv) begin
        rtlzz_pipe_6_s1 <= s8_norm_mux_10_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:28:30-28:63; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
        end
        if (iv) begin
        rtlzz_pipe_7_s1 <= s8_norm_mux_11_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_7_s2 <= rtlzz_pipe_7_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:29:31-29:66; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:25:5-25:41
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_10_s2 <= s8_norm_mux_14_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:32:25-32:71; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:22:5-22:40
        end
        if (rtlzz_valid_s1) begin
        rtlzz_pipe_11_s2 <= s8_norm_mux_15_v0; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:33:25-33:60
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8
        rtlzz_valid_s2 <= rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_D_8_B.logic.cpp:4:1-4:8
        end
    end
endmodule
