`timescale 1ns/1ps

module H_M_8_A(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:4:1-4:11
    input logic [7:0] a, // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:7:1-7:9; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:7:1-7:9
    input logic [7:0] b, // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:9:1-9:9; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:9:1-9:9
    input logic [7:0] c, // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:11:1-11:9; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:11:1-11:9
    input logic sel, // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:13:1-13:9
    output logic [7:0] y // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:22:5-22:14
);

    logic [7:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:19:26-19:42; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:18:21-18:33
    logic [7:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:20:25-20:30
    logic [7:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:21:21-21:59; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:21:21-21:59
    logic [7:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:20:25-20:30


    assign s8_norm_mux_1_v0 = (sel ? c : 8'h0); // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:19:26-19:42; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:18:21-18:33
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + s8_norm_mux_1_v0); // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:21:21-21:59; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:21:21-21:59
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_8_A.logic.cpp:15:1-15:9; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:22:5-22:14
    assign arith_original_10 = 8'(($unsigned(8'($unsigned(a))) * $unsigned(8'($unsigned(b))))); // decl: <none>; prim: /home/zyrv/vulsim/H_M_8_A.logic.cpp:20:25-20:30
endmodule
