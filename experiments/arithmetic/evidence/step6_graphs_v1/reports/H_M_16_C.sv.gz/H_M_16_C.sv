`timescale 1ns/1ps

module H_M_16_C(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:11
    input logic [15:0] a, // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:7:1-7:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:9:1-9:10
    input logic [15:0] c, // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:11:1-11:10
    input logic sel, // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:13:1-13:9
    output logic [15:0] y, // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:22:5-22:14
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic [15:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:18:22-18:35
    logic [15:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:20:26-20:31
    logic [15:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:21:22-21:62
    logic [15:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:20:26-20:31
    logic [7:0] mul_tree_10_11; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_12; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_13; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_14; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_15; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_16; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_17; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_18; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_19; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_20; // decl: <none>; prim: <none>
    logic [23:0] mul_tree_10_21; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_22; // decl: <none>; prim: <none>
    logic [7:0] mul_tree_10_23; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_24; // decl: <none>; prim: <none>
    logic [31:0] mul_tree_10_25; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_26; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_27; // decl: <none>; prim: <none>
    logic [24:0] mul_tree_10_28; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_29; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_30; // decl: <none>; prim: <none>
    logic [32:0] mul_tree_10_31; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_32; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_33; // decl: <none>; prim: <none>
    logic [33:0] mul_tree_10_34; // decl: <none>; prim: <none>
    logic [15:0] mul_tree_10_35; // decl: <none>; prim: <none>
    logic [15:0] rtlzz_pipe_5_s1; // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:18:22-18:35
    logic [15:0] rtlzz_pipe_13_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_17_s1; // decl: <none>; prim: <none>
    logic [23:0] rtlzz_pipe_21_s1; // decl: <none>; prim: <none>
    logic [31:0] rtlzz_pipe_25_s1; // decl: <none>; prim: <none>
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:8


    assign s8_norm_mux_1_v0 = (sel ? c : 16'h0); // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:18:22-18:35
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + rtlzz_pipe_5_s1); // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:21:22-21:62
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:22:5-22:14
    assign arith_original_10 = mul_tree_10_35; // decl: <none>; prim: <none>
    assign mul_tree_10_11 = a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_12 = b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_13 = 16'(($unsigned(16'($unsigned(mul_tree_10_11))) * $unsigned(16'($unsigned(mul_tree_10_12))))); // decl: <none>; prim: <none>
    assign mul_tree_10_14 = a[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_15 = b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_16 = 16'(($unsigned(16'($unsigned(mul_tree_10_14))) * $unsigned(16'($unsigned(mul_tree_10_15))))); // decl: <none>; prim: <none>
    assign mul_tree_10_17 = {mul_tree_10_16, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_18 = a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_19 = b[7:0]; // decl: <none>; prim: <none>
    assign mul_tree_10_20 = 16'(($unsigned(16'($unsigned(mul_tree_10_18))) * $unsigned(16'($unsigned(mul_tree_10_19))))); // decl: <none>; prim: <none>
    assign mul_tree_10_21 = {mul_tree_10_20, 8'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_22 = a[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_23 = b[15:8]; // decl: <none>; prim: <none>
    assign mul_tree_10_24 = 16'(($unsigned(16'($unsigned(mul_tree_10_22))) * $unsigned(16'($unsigned(mul_tree_10_23))))); // decl: <none>; prim: <none>
    assign mul_tree_10_25 = {mul_tree_10_24, 16'h0}; // decl: <none>; prim: <none>
    assign mul_tree_10_26 = ({9'h0, rtlzz_pipe_13_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_27 = ({1'h0, rtlzz_pipe_17_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_28 = 25'((mul_tree_10_26 + mul_tree_10_27 + ({24'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_29 = ({9'h0, rtlzz_pipe_21_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_30 = ({1'h0, rtlzz_pipe_25_s1}); // decl: <none>; prim: <none>
    assign mul_tree_10_31 = 33'((mul_tree_10_29 + mul_tree_10_30 + ({32'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_32 = ({9'h0, mul_tree_10_28}); // decl: <none>; prim: <none>
    assign mul_tree_10_33 = ({1'h0, mul_tree_10_31}); // decl: <none>; prim: <none>
    assign mul_tree_10_34 = 34'((mul_tree_10_32 + mul_tree_10_33 + ({33'h0, 1'h0}))); // decl: <none>; prim: <none>
    assign mul_tree_10_35 = mul_tree_10_34[15:0]; // decl: <none>; prim: <none>
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_5_s1 <= 16'h8035;
            rtlzz_pipe_13_s1 <= 16'haf9;
            rtlzz_pipe_17_s1 <= 24'h1a8000;
            rtlzz_pipe_21_s1 <= 24'h1a8000;
            rtlzz_pipe_25_s1 <= 32'h40000000;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_5_s1 <= s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:18:22-18:35
        end
        if (iv) begin
        rtlzz_pipe_13_s1 <= mul_tree_10_13; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_17_s1 <= mul_tree_10_17; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_21_s1 <= mul_tree_10_21; // decl: <none>; prim: <none>
        end
        if (iv) begin
        rtlzz_pipe_25_s1 <= mul_tree_10_25; // decl: <none>; prim: <none>
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_16_C.logic.cpp:4:1-4:8
        end
    end
endmodule
