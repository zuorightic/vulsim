`timescale 1ns/1ps

module H_M_16_A(
    input logic iv, // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:4:1-4:11
    input logic [15:0] a, // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:7:1-7:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:9:1-9:10
    input logic [15:0] c, // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:11:1-11:10
    input logic sel, // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:13:1-13:9; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:13:1-13:9
    output logic [15:0] y // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:22:5-22:14
);

    logic [15:0] s8_norm_mux_1_v0; // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:18:22-18:35
    logic [15:0] s8_norm_mul_2_v0; // decl: <none>; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:20:26-20:31
    logic [15:0] s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:21:22-21:62
    logic [15:0] arith_original_10; // decl: <none>; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:20:26-20:31


    assign s8_norm_mux_1_v0 = (sel ? c : 16'h0); // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:19:27-19:43; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:18:22-18:35
    assign s8_norm_mul_2_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign s8_norm_add_4_v0 = (s8_norm_mul_2_v0 + s8_norm_mux_1_v0); // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:21:22-21:62; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:21:22-21:62
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_4_v0; // decl: /home/zyrv/vulsim/H_M_16_A.logic.cpp:15:1-15:10; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:22:5-22:14
    assign arith_original_10 = 16'(($unsigned(16'($unsigned(a))) * $unsigned(16'($unsigned(b))))); // decl: <none>; prim: /home/zyrv/vulsim/H_M_16_A.logic.cpp:20:26-20:31
endmodule
