`timescale 1ns/1ps

module MUL_16_A(
    input logic iv, // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:4:1-4:11
    input logic [15:0] a, // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:7:1-7:10
    input logic [15:0] b, // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:9:1-9:10
    output logic [31:0] y // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:15:5-15:18
);

    logic [31:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:9:1-9:10
    logic [15:0] __beopt_width_8; // decl: <none>; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:7:1-7:10
    logic [15:0] __beopt_width_9; // decl: <none>; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:9:1-9:10
    logic [31:0] __beopt_width_10; // decl: <none>; prim: <none>
    logic [31:0] __beopt_width_11; // decl: <none>; prim: <none>
    logic [31:0] arith_original_10; // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:9:1-9:10


    assign s8_norm_mul_0_v0 = arith_original_10; // decl: <none>; prim: <none>
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:15:5-15:18
    assign __beopt_width_8 = a; // decl: <none>; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:7:1-7:10
    assign __beopt_width_9 = b; // decl: <none>; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:9:1-9:10
    assign __beopt_width_10 = ({16'h0, __beopt_width_8}); // decl: <none>; prim: <none>
    assign __beopt_width_11 = ({16'h0, __beopt_width_9}); // decl: <none>; prim: <none>
    assign arith_original_10 = 32'(($unsigned(32'($unsigned(__beopt_width_10))) * $unsigned(32'($unsigned(__beopt_width_11))))); // decl: /home/zyrv/vulsim/MUL_16_A.logic.cpp:14:26-14:31; prim: /home/zyrv/vulsim/MUL_16_A.logic.cpp:9:1-9:10
endmodule
