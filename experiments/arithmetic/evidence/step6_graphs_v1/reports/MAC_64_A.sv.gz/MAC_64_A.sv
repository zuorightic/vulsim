`timescale 1ns/1ps

module MAC_64_A(
    input logic iv, // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:4:1-4:11
    input logic [63:0] a, // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:7:1-7:10
    input logic [63:0] b, // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:9:1-9:10
    input logic [127:0] c, // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:11:1-11:11; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:11:1-11:11
    output logic [127:0] y // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:18:5-18:14
);

    logic [127:0] s8_norm_mul_0_v0; // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:9:1-9:10
    logic [127:0] s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:17:23-17:56
    logic [63:0] __beopt_width_10; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:7:1-7:10
    logic [63:0] __beopt_width_11; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:9:1-9:10
    logic [127:0] __beopt_width_12; // decl: <none>; prim: <none>
    logic [127:0] __beopt_width_13; // decl: <none>; prim: <none>
    logic [127:0] arith_original_12; // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:9:1-9:10


    assign s8_norm_mul_0_v0 = arith_original_12; // decl: <none>; prim: <none>
    assign s8_norm_add_1_v0 = (s8_norm_mul_0_v0 + c); // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:17:23-17:56; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:17:23-17:56
    assign ov = iv; // decl: <none>; prim: <none>
    assign y = s8_norm_add_1_v0; // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:13:1-13:11; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:18:5-18:14
    assign __beopt_width_10 = a; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:7:1-7:10
    assign __beopt_width_11 = b; // decl: <none>; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:9:1-9:10
    assign __beopt_width_12 = ({64'h0, __beopt_width_10}); // decl: <none>; prim: <none>
    assign __beopt_width_13 = ({64'h0, __beopt_width_11}); // decl: <none>; prim: <none>
    assign arith_original_12 = 128'(($unsigned(128'($unsigned(__beopt_width_12))) * $unsigned(128'($unsigned(__beopt_width_13))))); // decl: /home/zyrv/vulsim/MAC_64_A.logic.cpp:16:27-16:32; prim: /home/zyrv/vulsim/MAC_64_A.logic.cpp:9:1-9:10
endmodule
