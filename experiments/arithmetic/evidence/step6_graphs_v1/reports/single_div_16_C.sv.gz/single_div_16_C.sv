`timescale 1ns/1ps

module single_div_16_C(
    input logic iv, // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:8
    output logic ov, // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:11; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:11
    input logic [15:0] a, // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:7:1-7:10; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:7:1-7:10
    input logic [15:0] d, // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:9:1-9:10; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:9:1-9:10
    output logic [15:0] q, // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:56-14:90
    input logic rstn, // decl: <none>; prim: <none>
    input logic clk // decl: <none>; prim: <none>
);

    logic s8_norm_cmp_1_v0; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
    logic [15:0] s8_norm_mux_3_v0; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:38-14:55; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
    logic [15:0] s8_norm_udivmod_6_v0; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89
    logic [15:0] s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:58-14:90; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
    logic [15:0] arith_original_9; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89
    logic rtlzz_pipe_3_s1; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
    logic [15:0] rtlzz_pipe_9_s1; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89
    logic rtlzz_valid_s1; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:8


    assign s8_norm_cmp_1_v0 = (d == 16'h0); // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
    assign s8_norm_mux_3_v0 = (s8_norm_cmp_1_v0 ? 16'h1 : d); // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:38-14:55; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
    assign s8_norm_udivmod_6_v0 = rtlzz_pipe_9_s1; // decl: <none>; prim: <none>
    assign s8_norm_mux_7_v0 = (rtlzz_pipe_3_s1 ? 16'hffff : s8_norm_udivmod_6_v0); // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:58-14:90; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
    assign ov = rtlzz_valid_s1; // decl: <none>; prim: <none>
    assign q = s8_norm_mux_7_v0; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:11:1-11:10; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:56-14:90
    assign arith_original_9 = (a / s8_norm_mux_3_v0); // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89
    always_ff @(posedge clk) begin
        if (!rstn) begin
            rtlzz_pipe_3_s1 <= 1'h1;
            rtlzz_pipe_9_s1 <= 16'h8035;
            rtlzz_valid_s1 <= 1'h0;
        end else begin
        if (iv) begin
        rtlzz_pipe_3_s1 <= s8_norm_cmp_1_v0; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:11-14:24; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:14-14:24
        end
        if (iv) begin
        rtlzz_pipe_9_s1 <= arith_original_9; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:14:83-14:89
        end
        rtlzz_valid_s1 <= iv; // decl: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:8; prim: /home/zyrv/vulsim/single_div_16_C.logic.cpp:4:1-4:8
        end
    end
endmodule
